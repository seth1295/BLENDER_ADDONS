bl_info = {
    "name": "Town Builder",
    "author": "OpenAI",
    "version": (0, 4, 4),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > Town Builder",
    "description": "Procedural town construction tools",
    "category": "Add Mesh",
}

if "bpy" in locals():
    import importlib
    if "terrain_math" in locals():
        importlib.reload(terrain_math)
    if "terrain" in locals():
        importlib.reload(terrain)
    if "chunk_core" in locals():
        importlib.reload(chunk_core)
    if "chunks" in locals():
        importlib.reload(chunks)
    if "town_layout_blender" in locals():
        importlib.reload(town_layout_blender)
else:
    from . import terrain_math, terrain, chunk_core, chunks, town_layout_blender

import bpy

classes = (
    terrain.TB_TerrainSettings,
    terrain.TB_OT_create_basic_terrain,
    terrain.TB_OT_set_four_km_preset,
    terrain.TB_PT_terrain_panel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.tb_terrain_settings = bpy.props.PointerProperty(type=terrain.TB_TerrainSettings)
    bpy.types.VIEW3D_MT_mesh_add.append(terrain.terrain_add_menu)
    chunks.register()
    town_layout_blender.register()

def unregister():
    town_layout_blender.unregister()
    chunks.unregister()
    bpy.types.VIEW3D_MT_mesh_add.remove(terrain.terrain_add_menu)
    del bpy.types.Scene.tb_terrain_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
