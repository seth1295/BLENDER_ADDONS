# Town Builder Rules

## Rule #1
Procedural generation on everything but hero assets.

Explicitly accepted non-procedural exceptions:
- Cars
- People
- Handheld objects

Everything else is subject to procedural generation by default.

## Rule #2
ambientCG is the primary source of PBR materials and textures.
