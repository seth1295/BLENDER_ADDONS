"""Run outside Blender: python tests/validate_chunks.py

No pip packages required. Verifies v0.4.3 chunk mesh and landform equations. The Blender bpy integration is not runtime-tested here.
"""
import importlib
import sys
import time
import types
import json
import math
from pathlib import Path

PACKAGE_ROOT=Path(__file__).resolve().parents[1]
package=types.ModuleType('_town_builder_test_package')
package.__path__=[str(PACKAGE_ROOT)]
sys.modules[package.__name__]=package
maths=importlib.import_module(package.__name__+'.terrain_math')
cc=importlib.import_module(package.__name__+'.chunk_core')


def config():
    return types.SimpleNamespace(width=4000.0,length=4000.0,
        resolution_x=240,resolution_y=240,elevation=38.0,base_height=18.0,
        river_width=150.0,river_depth=24.0,bank_width=2.0,bank_rise=7.0,
        rolling_relief=11.0,border_hill_height=82.0,border_hill_band=850.0,
        valley_width=220.0,water_level=0.0,water_drop=4.0,
        focus_size=1000.0,focus_density=3.0,world_space=True,seed=1)


def expect(condition,message):
    if not condition:
        raise AssertionError(message)


def _area_xy(vertices,face):
    p=[vertices[k] for k in face]
    x0,y0,_=p[0]
    return .5*sum((p[i][0]-x0)*(p[i+1][1]-y0)-
                  (p[i+1][0]-x0)*(p[i][1]-y0) for i in range(1,len(p)-1))


def verify_mesh(mesh,s):
    tile=mesh.tile
    expected_area=tile.size**2
    area=sum(_area_xy(mesh.vertices,f) for f in mesh.faces)
    expect(abs(area-expected_area)<1.e-4,
           f'{tile.key}: terrain area coverage {area} != {expected_area}')
    expect(all(0<=idx<len(mesh.vertices) for f in mesh.faces for idx in f),
           'Terrain index out of bounds')
    expect(all(_area_xy(mesh.vertices,f)>1.e-10 for f in mesh.faces),
           'Degenerate or wrong-winding terrain polygon')
    expect(all(_area_xy(mesh.water_vertices,f)>1.e-10 for f in mesh.water_faces),
           'Degenerate or wrong-winding water polygon')
    terrain_xyz={(round(x,9),round(y,9)):(x,y,z) for x,y,z in mesh.vertices}
    water_verts={(round(x,9),round(y,9)):(x,y,z) for x,y,z in mesh.water_vertices}
    # Geometric shoreline vertices have exactly equal terrain/water Z.
    for x,y,z in mesh.water_vertices:
        low,high=cc._river_limits(x,s)
        if min(abs(y-low),abs(y-high))<1.e-6:
            land=terrain_xyz.get((round(x,9),round(y,9)))
            expect(land is not None,'Water shoreline does not share terrain vertex')
            expect(abs(z-land[2])<1.e-7,'Water/terrain shoreline vertical mismatch')
    expect(len(mesh.water_faces)==0 or len(mesh.water_vertices)>0,'Invalid water mesh')
    return {'terrain_verts':len(mesh.vertices),'terrain_faces':len(mesh.faces),
            'water_verts':len(mesh.water_vertices),'water_faces':len(mesh.water_faces),
            'covered_area_m2':area,'shoreline_verts':mesh.shoreline_vertices}


def test_region(s):
    leaves,targets=cc.build_plan()
    expect(len(leaves)==256 and len(targets)==9,'Unexpected 3 x 3 plan')
    levels=sorted({t.lod for t in targets})
    expect(levels==[0,1,2],'Mixed LOD 0/1/2 absent')
    built={t.key:cc.generate_tile(t,leaves,s) for t in targets}
    counts={}
    for t in targets:
        counts[t.key]=verify_mesh(built[t.key],s)
    seams=[]
    for t in targets:
        for side in 'ENSW':
            for nb in cc.adjacent_tiles(t,side,targets):
                if t.key < nb.key:
                    e=cc.seam_error(built[t.key],built[nb.key],side)
                    expect(e is not None and e < 1.e-6,f'Terrain crack {t.key} {nb.key}: {e}')
                    w=cc.seam_error(built[t.key],built[nb.key],side,True)
                    if w is not None:
                        expect(w < 1.e-6,f'Water crack {t.key} {nb.key}: {w}')
                    seams.append((t.key,nb.key,e,w))
    # Existing chunk's mesh must not change when neighbour LOD planning changes.
    focus=cc.Tile(0,8,8,2)
    single=cc.generate_tile(focus,[focus],s)
    expect(single.vertices==built[focus.key].vertices and
           single.faces==built[focus.key].faces,
           'Independent regeneration changed geometry')
    return {'lods':levels,'target_tiles':len(targets),
            'tested_terrain_seams':len(seams),
            'tested_water_seams':sum(w is not None for *_,w in seams),
            'max_terrain_seam_m':max(e for *_,e,w in seams),
            'max_water_seam_m':max((w for *_,e,w in seams if w is not None),default=0),
            'meshes':counts}


def test_quadtree(s,depth):
    leaves,targets=cc.build_plan(focus_depth=depth,focus_lod=0,neighbor_lod=0)
    expect(len(targets)==8+4**depth,'Quadtree target count mismatch')
    active=[t for t in targets if t.root_xy==(8,8)]
    built={t.key:cc.generate_tile(t,leaves,s) for t in active}
    for mesh in built.values():
        verify_mesh(mesh,s)
    test_count=0
    for t in active:
        for side in 'ENSW':
            for nb in cc.adjacent_tiles(t,side,active):
                if t.key<nb.key:
                    e=cc.seam_error(built[t.key],built[nb.key],side)
                    expect(e is not None and e<1.e-6,'Quadtree internal seam mismatch')
                    test_count+=1
    total_area=sum(t.size**2 for t in active)
    expect(abs(total_area-250.**2)<1.e-8,'Quadtree area is not 250 m squared')
    return {'depth':depth,'children':len(active),
            'area_m2':total_area,'internal_seams':test_count}


def test_world_math(s):
    assert maths.validate_corridor(s) is None
    for x in (-1999.,-1250.,-250.,0.,1250.,1999.):
        cy=maths.river_center_y(x,s)
        z0=maths.terrain_height(x,cy,s)
        zw=maths.river_water_z(x,s)
        expect(abs((zw-z0)-24.0)<1.e-9,'Riverbed depth regression')
        bank=cy+maths.river_half_y(x,s)
        expect(abs(maths.terrain_height(x,bank,s)-zw)<1.e-8,
               'Legacy shoreline regression')
    # Elliptical U channel, steep 7m banks and genuine in-mesh station sampling.
    expect(s.river_width == 150.0 and s.river_depth == 24.0, 'Wide river dimensions differ')
    expect(s.bank_width == 2.0, 'Bank face should be only 2m wide')
    for frac in (0.0,0.22,0.45,0.65,0.8,0.9,0.96,0.99,1.0):
        x=0.0
        cy=maths.river_center_y(x,s)
        y=cy+frac*maths.river_half_y(x,s)
        expected=maths.river_water_z(x,s)-s.river_depth*math.sqrt(max(0.,1.-frac**2))
        expect(abs(maths.terrain_height(x,y,s)-expected)<2.e-6,
               f'Rounded cross-section mismatch at station {frac}')
    x=0.0
    cy=maths.river_center_y(x,s)
    crest=cy+(s.river_width*.5+s.bank_width)*maths.river_cross_scale(x,s)
    expect(abs(maths.terrain_height(x,crest,s)-maths.river_water_z(x,s)-7.)<2.e-7,
           '7m bank crest is missing')
    # Extending bounds must not move a world-space point.
    sample_before=maths.terrain_height(122.5,255.3,s)
    s.width=s.length=5000.0
    sample_after=maths.terrain_height(122.5,255.3,s)
    s.width=s.length=4000.0
    expect(sample_before==sample_after,'World anchor changed with terrain extent')
    plan=cc.whole_map_plan()
    expect(len(plan)==256 and len({t.key for t in plan})==256,
           'Incorrect world tile ownership')
    expect(sum(t.size*t.size for t in plan)==16_000_000.,'Incorrect world area')
    return {'terrain_math_updated':True,'river_depth_m':24.,'river_width_m':150.,
            'map_area_m2':16_000_000.,'root_tiles':256}


def run(report_path=None):
    start=time.perf_counter()
    s=config()
    report={'version':'0.4.3','map_width_m':4000,'map_length_m':4000,
            'chunk_size_m':250,'lod_pitch_m':{str(i):250/(64*2**i) for i in range(5)},
            'world_math':test_world_math(s),
            'mixed_3x3':test_region(s),
            'quadtree_d1':test_quadtree(s,1),
            'quadtree_d2':test_quadtree(s,2)}
    report['elapsed_s']=round(time.perf_counter()-start,3)
    report['status']='PASS'
    report['blender_runtime']='NOT TESTED - bpy not installed'
    if report_path:
        Path(report_path).write_text(json.dumps(report,indent=2))
    print(json.dumps({k:v for k,v in report.items() if k!='mixed_3x3'},indent=2))
    print('MIXED REGION', {k:v for k,v in report['mixed_3x3'].items() if k!='meshes'})
    return report


if __name__=='__main__':
    run(str(PACKAGE_ROOT/'validation_report.json'))
