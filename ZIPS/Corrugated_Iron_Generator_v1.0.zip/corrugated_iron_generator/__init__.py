"""Corrugated Iron Generator for Blender: editable sheets and ambientCG PBR.

Shift+A > Mesh > Corrugated Iron Sheet; edit using the viewport and N-sidebar.
"""
bl_info = {
    'name': 'Corrugated Iron Generator',
    'author': 'Seth McLaughlin',
    'version': (1, 0, 0),
    'blender': (4, 2, 0),
    'location': '3D View > Shift+A > Mesh > Corrugated Iron Sheet; N > Corrugated Iron',
    'description': 'Low-poly corrugated sheets; six ambientCG PBR materials; editable rust and render relief',
    'category': 'Add Mesh',
    'license': 'MIT',
}

import os
from pathlib import Path
import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty, StringProperty
from bpy.types import AddonPreferences, Operator, Panel, PropertyGroup
from bpy_extras.io_utils import ImportHelper

from .assets import ASSETS, ASSET_IDS, asset_from_archive_name, download_and_install, install_archive, installed_maps
from .geometry import rebuild_mesh, update_modifiers
from .materials import rebuild_material


ASSET_ITEMS = [(asset_id, label, 'ambientCG CC0 texture: ' + asset_id, n)
               for n, (asset_id, label) in enumerate(ASSETS)]


def cache_root(context=None):
    context = context or bpy.context
    addon = context.preferences.addons.get(__package__)
    if addon and addon.preferences.cache_directory.strip():
        return str(Path(bpy.path.abspath(addon.preferences.cache_directory)).expanduser())
    return bpy.utils.user_resource('DATAFILES', path='corrugated_iron_generator/ambientCG', create=True)


def _obj(props):
    owner = props.id_data
    if isinstance(owner, bpy.types.Object) and owner.type == 'MESH' and owner.ci_iron.is_sheet:
        return owner
    return None


def _on_geometry(self, context):
    obj = _obj(self)
    if obj:
        rebuild_mesh(obj)
        rebuild_material(obj, cache_root(context))


def _on_modifiers(self, context):
    obj = _obj(self)
    if obj:
        update_modifiers(obj)
        rebuild_material(obj, cache_root(context))


def _on_material(self, context):
    obj = _obj(self)
    if obj:
        rebuild_material(obj, cache_root(context))


class CI_AddonPreferences(AddonPreferences):
    bl_idname = __package__
    cache_directory: StringProperty(
        name='Texture cache folder', subtype='DIR_PATH', default='',
        description='Optional custom folder for ambientCG PBR maps; empty uses Blender user data')

    def draw(self, context):
        layout = self.layout
        layout.prop(self, 'cache_directory')
        layout.label(text='Only selected maps are extracted; downloads are CC0 from ambientCG.')


class CI_SheetProperties(PropertyGroup):
    is_sheet: BoolProperty(default=False, options={'HIDDEN'})

    width: FloatProperty(name='Width', description='Sheet width across corrugations',
                         default=0.90, min=0.05, max=30.0, subtype='DISTANCE', unit='LENGTH', update=_on_geometry)
    length: FloatProperty(name='Length', description='Sheet length along the corrugations',
                          default=2.40, min=0.05, max=100.0, subtype='DISTANCE', unit='LENGTH', update=_on_geometry)
    pitch: FloatProperty(name='Corrugation pitch', description='Valley-to-valley distance',
                         default=0.076, min=0.01, max=1.0, subtype='DISTANCE', unit='LENGTH', update=_on_geometry)
    depth: FloatProperty(name='Corrugation depth', description='Trough-to-crest height',
                         default=0.018, min=0.0, max=0.4, subtype='DISTANCE', unit='LENGTH', update=_on_geometry)
    thickness: FloatProperty(name='Steel thickness', description='Thickness via Solidify, not duplicate polygons',
                             default=0.0007, min=0.0, max=0.03, precision=4,
                             subtype='DISTANCE', unit='LENGTH', update=_on_modifiers)
    profile_style: EnumProperty(name='Profile', items=[
        ('ROUND', 'Round wave', 'Sinusoidal corrugation'),
        ('TRAPEZOID', 'Trapezoid', 'Flat crests and valleys with sharp bends'),
    ], default='ROUND', update=_on_geometry)
    phase: FloatProperty(name='Profile offset', description='Shift the wave under the cut edges',
                         default=0.0, min=-1.0, max=1.0, precision=3, update=_on_geometry)
    samples_per_wave: IntProperty(name='Segments / wave', default=8, min=4, max=32,
                                  description='Mesh silhouette quality; no lengthwise subdivisions', update=_on_geometry)

    base_asset: EnumProperty(name='Base texture', items=ASSET_ITEMS, default='Metal050C', update=_on_material)
    rust_asset: EnumProperty(name='Corrosion texture', items=ASSET_ITEMS, default='Rust002', update=_on_material)
    rust_amount: FloatProperty(name='Rust coverage', default=0.14, min=0.0, max=1.0,
                               subtype='FACTOR', update=_on_material)
    edge_rust: FloatProperty(name='Cut-edge rust', default=0.75, min=0.0, max=1.0,
                             subtype='FACTOR', update=_on_material)
    rust_patch_scale: FloatProperty(name='Rust patch size', default=3.4, min=0.2, max=50.0,
                                    description='Lower numbers create larger rust patches', update=_on_material)
    dirt_amount: FloatProperty(name='Dirt', default=0.08, min=0.0, max=1.0,
                               subtype='FACTOR', update=_on_material)
    texture_scale: FloatProperty(name='Texture metres / tile', default=1.0, min=0.1, max=10.0,
                                 description='Length represented by one full PBR texture repeat', update=_on_material)
    roughness_bias: FloatProperty(name='Roughness adjustment', default=0.05, min=-0.8, max=0.8,
                                  update=_on_material)
    bump_strength: FloatProperty(name='Bump strength', default=0.4, min=0.0, max=1.0,
                                 subtype='FACTOR', update=_on_material)
    micro_height: FloatProperty(name='Relief height', default=0.0007, min=0.0, max=0.02,
                                precision=5, subtype='DISTANCE', unit='LENGTH', update=_on_material)
    displacement_mode: EnumProperty(name='Micro-detail mode', items=[
        ('BUMP', 'Bump / normal (fast)', 'No micro-detail geometry, Eevee/Cycles compatible'),
        ('TRUE', 'True displacement (Cycles)', 'Render-only subdivisions; higher render polygon count'),
    ], default='BUMP', update=_on_modifiers)
    render_subdivision: IntProperty(name='Render subdivisions', default=2, min=1, max=4,
                                    description='Only active for true displacement; viewport stays unsplit', update=_on_modifiers)
    download_resolution: EnumProperty(name='Texture resolution', items=[
        ('1K', '1K JPG', 'Smaller download and VRAM footprint'),
        ('2K', '2K JPG', 'Higher detail / more VRAM'),
    ], default='1K', update=_on_material)


class CI_OT_add_sheet(Operator):
    bl_idname = 'mesh.ci_add_sheet'
    bl_label = 'Corrugated Iron Sheet'
    bl_description = 'Add a corrugated sheet; configure live using N > Corrugated Iron'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        mesh = bpy.data.meshes.new('Corrugated Iron / Sheet')
        obj = bpy.data.objects.new('Corrugated Iron', mesh)
        context.collection.objects.link(obj)
        obj.matrix_world = context.scene.cursor.matrix.copy()
        for other in context.selected_objects:
            other.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj
        obj.ci_iron.is_sheet = True
        rebuild_mesh(obj)
        rebuild_material(obj, cache_root(context))
        self.report({'INFO'}, 'Sheet added; use N > Corrugated Iron for live editing')
        return {'FINISHED'}


class CI_OT_fetch(Operator):
    bl_idname = 'ci.fetch_asset'
    bl_label = 'Download ambientCG PBR'
    bl_description = 'Fetch selected CC0 texture maps into the local user cache'
    bl_options = {'REGISTER'}

    asset_id: StringProperty()
    resolution: EnumProperty(items=[('1K', '1K', ''), ('2K', '2K', '')], default='1K')

    def execute(self, context):
        if self.asset_id not in ASSET_IDS:
            self.report({'ERROR'}, 'Unknown ambientCG asset')
            return {'CANCELLED'}
        try:
            _url, maps = download_and_install(self.asset_id, self.resolution, cache_root(context))
            _refresh_users(context, self.asset_id)
        except Exception as error:
            self.report({'ERROR'}, 'Download failed: ' + str(error)[:240])
            return {'CANCELLED'}
        self.report({'INFO'}, f'{self.asset_id}: installed {len(maps)} PBR maps ({self.resolution})')
        return {'FINISHED'}


class CI_OT_import_zip(Operator, ImportHelper):
    bl_idname = 'ci.import_ambientcg_zip'
    bl_label = 'Install downloaded ambientCG ZIP'
    bl_description = 'Import an official ambientCG 1K or 2K ZIP from disk, without any network request'
    bl_options = {'REGISTER'}
    filename_ext = '.zip'
    filter_glob: StringProperty(default='*.zip', options={'HIDDEN'})

    def execute(self, context):
        try:
            ident = asset_from_archive_name(self.filepath)
            filename = Path(self.filepath).name.upper()
            res = '2K' if '_2K-' in filename else '1K'
            maps = install_archive(self.filepath, cache_root(context), ident, res)
            _refresh_users(context, ident)
            self.report({'INFO'}, f'{ident}: imported {len(maps)} PBR maps')
            return {'FINISHED'}
        except Exception as error:
            self.report({'ERROR'}, str(error)[:240])
            return {'CANCELLED'}


class CI_OT_refresh(Operator):
    bl_idname = 'ci.refresh_materials'
    bl_label = 'Refresh textures'
    bl_description = 'Re-scan cached ambientCG maps and rebuild sheet materials'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        count = 0
        for obj in bpy.data.objects:
            if obj.type == 'MESH' and obj.ci_iron.is_sheet:
                rebuild_material(obj, cache_root(context))
                count += 1
        self.report({'INFO'}, f'Refreshed {count} sheet materials')
        return {'FINISHED'}


class CI_OT_pack_images(Operator):
    bl_idname = 'ci.pack_images'
    bl_label = 'Pack sheet images into .blend'
    bl_description = 'Embed this sheet\'s installed PBR maps for portable .blend files'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or not obj.ci_iron.is_sheet or not obj.active_material:
            return {'CANCELLED'}
        count = 0
        tree = obj.active_material.node_tree
        for node in tree.nodes:
            if node.type == 'TEX_IMAGE' and node.image and not node.image.packed_file:
                try:
                    node.image.pack()
                    count += 1
                except (RuntimeError, OSError):
                    pass
        self.report({'INFO'}, f'Packed {count} texture image(s)')
        return {'FINISHED'}


class CI_OT_open_source(Operator):
    bl_idname = 'ci.open_source'
    bl_label = 'Open on ambientCG'
    bl_description = 'Open the official CC0 ambientCG asset page'
    asset_id: StringProperty()

    def execute(self, context):
        if self.asset_id not in ASSET_IDS:
            return {'CANCELLED'}
        bpy.ops.wm.url_open(url='https://ambientcg.com/view?id=' + self.asset_id)
        return {'FINISHED'}


def _refresh_users(context, asset_id):
    # Replace files in cache without leaving old pixels resident in Blender.
    folder = str(Path(cache_root(context)) / asset_id)
    for image in bpy.data.images:
        try:
            if image.source == 'FILE' and str(Path(bpy.path.abspath(image.filepath))).startswith(folder + os.sep):
                image.reload()
        except (RuntimeError, OSError, ValueError):
            pass
    for obj in bpy.data.objects:
        if obj.type == 'MESH' and obj.ci_iron.is_sheet:
            p = obj.ci_iron
            if p.base_asset == asset_id or p.rust_asset == asset_id:
                rebuild_material(obj, cache_root(context))


class CI_PT_sheet(Panel):
    bl_label = 'Corrugated Iron'
    bl_idname = 'CI_PT_sheet'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Corrugated Iron'

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        if not obj or obj.type != 'MESH' or not obj.ci_iron.is_sheet:
            layout.label(text='Shift+A > Mesh > Corrugated Iron Sheet', icon='INFO')
            layout.operator('mesh.ci_add_sheet', icon='MESH_GRID')
            return
        p = obj.ci_iron
        layout.label(text='Sheet profile', icon='MOD_WAVE')
        col = layout.column(align=True)
        if obj.mode != 'OBJECT':
            col.label(text='Switch to Object Mode to edit profile', icon='INFO')
        col.enabled = (obj.mode == 'OBJECT')
        col.prop(p, 'profile_style')
        col.prop(p, 'width')
        col.prop(p, 'length')
        col.prop(p, 'pitch')
        col.prop(p, 'depth')
        col.prop(p, 'thickness')
        col.separator()
        col.prop(p, 'phase')
        col.prop(p, 'samples_per_wave')
        tris = len(obj.data.polygons) * 2
        layout.label(text=f'Base mesh: {len(obj.data.vertices):,} verts / {tris:,} tris')
        layout.label(text='G / R / S to place, rotate and scale.')


class CI_PT_material(Panel):
    bl_label = 'Metal / Weathering'
    bl_parent_id = 'CI_PT_sheet'
    bl_idname = 'CI_PT_material'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return bool(obj and obj.type == 'MESH' and obj.ci_iron.is_sheet)

    def draw(self, context):
        p = context.active_object.ci_iron
        layout = self.layout
        layout.prop(p, 'base_asset')
        layout.prop(p, 'rust_asset')
        layout.prop(p, 'rust_amount', slider=True)
        layout.prop(p, 'edge_rust', slider=True)
        layout.prop(p, 'rust_patch_scale')
        layout.prop(p, 'dirt_amount', slider=True)
        layout.separator()
        layout.prop(p, 'texture_scale')
        layout.prop(p, 'roughness_bias')
        layout.prop(p, 'bump_strength', slider=True)
        layout.prop(p, 'micro_height')
        layout.prop(p, 'displacement_mode')
        if p.displacement_mode == 'TRUE':
            layout.prop(p, 'render_subdivision')
            if context.scene.render.engine != 'CYCLES':
                layout.label(text='True displacement needs Cycles', icon='ERROR')
            else:
                layout.label(text='Render-only subdivision, not viewport', icon='INFO')


class CI_PT_textures(Panel):
    bl_label = 'ambientCG PBR Library'
    bl_parent_id = 'CI_PT_sheet'
    bl_idname = 'CI_PT_textures'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return bool(obj and obj.type == 'MESH' and obj.ci_iron.is_sheet)

    def draw(self, context):
        layout = self.layout
        p = context.active_object.ci_iron
        root = cache_root(context)
        layout.prop(p, 'download_resolution')
        for title, asset_id in (('Base PBR', p.base_asset), ('Rust / overlay PBR', p.rust_asset)):
            maps = installed_maps(root, asset_id, p.download_resolution)
            col = layout.column(align=True)
            row = col.row(align=True)
            row.label(text=f'{title}: {asset_id}')
            row.label(text=('Ready' if maps else 'Not downloaded'),
                      icon=('CHECKMARK' if maps else 'IMPORT'))
            row = col.row(align=True)
            op = row.operator('ci.fetch_asset', text='Download ' + p.download_resolution,
                              icon='IMPORT')
            op.asset_id = asset_id
            op.resolution = p.download_resolution
            op = row.operator('ci.open_source', text='', icon='URL')
            op.asset_id = asset_id
        layout.separator()
        layout.operator('ci.import_ambientcg_zip', icon='FILE_FOLDER')
        layout.operator('ci.refresh_materials', icon='FILE_REFRESH')
        layout.operator('ci.pack_images', icon='PACKAGE')
        layout.label(text='CC0 textures by ambientCG. Downloads on demand.')
        layout.label(text='Procedural fallback works without downloads.')


def draw_add_mesh(self, context):
    self.layout.operator(CI_OT_add_sheet.bl_idname, text='Corrugated Iron Sheet', icon='MESH_GRID')


CLASSES = (
    CI_AddonPreferences, CI_SheetProperties, CI_OT_add_sheet, CI_OT_fetch,
    CI_OT_import_zip, CI_OT_refresh, CI_OT_pack_images, CI_OT_open_source,
    CI_PT_sheet, CI_PT_material, CI_PT_textures,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Object.ci_iron = PointerProperty(type=CI_SheetProperties)
    bpy.types.VIEW3D_MT_mesh_add.append(draw_add_mesh)


def unregister():
    bpy.types.VIEW3D_MT_mesh_add.remove(draw_add_mesh)
    del bpy.types.Object.ci_iron
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


if __name__ == '__main__':
    register()
