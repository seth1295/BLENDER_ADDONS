"""Town Builder 0.4.4: isolated road/district/bridge-reservation preview.

Planning data is packaged inside the ZIP (town_layout.json), not obtained through
external services. No existing chunk/river geometry is modified or removed.
"""
from __future__ import annotations
import bpy, json, math
from pathlib import Path
from bpy.types import Operator, Panel
from . import terrain_math as tm, layout_generator

ROOT = 'TB_Planned_Town'
TAG = 'town_builder_planning'


def _read_layout():
    path = Path(__file__).with_name('town_layout.json')
    result = json.loads(path.read_text(encoding='utf-8'))
    if result.get('schema') != 'town_builder.layout.v1' or result['terrain_baseline'] != 'v0.4.3':
        raise ValueError('Unsupported town layout schema / terrain baseline')
    # Regenerate the plan procedurally from the bundled terrain-based generator.
    generated=layout_generator.build_layout()
    if generated != result:
        raise ValueError('Bundled layout preview differs from the procedural plan generator')
    return generated


def _collection(scene):
    col=bpy.data.collections.get(ROOT)
    if col is None:col=bpy.data.collections.new(ROOT)
    if scene.collection.children.get(col.name) is None:scene.collection.children.link(col)
    return col


def _material(name,rgba,alpha=1.0):
    mat=bpy.data.materials.get(name) or bpy.data.materials.new(name)
    mat.diffuse_color=(*rgba,alpha)
    mat.use_nodes=True
    shader=mat.node_tree.nodes.get('Principled BSDF')
    if shader:
        shader.inputs['Base Color'].default_value=(*rgba,1.0)
        shader.inputs['Roughness'].default_value=.85
        shader.inputs['Alpha'].default_value=alpha
    # These are diagnostic planning overlays, not production ambientCG materials.
    if hasattr(mat,'surface_render_method'):
        mat.surface_render_method='BLENDED' if alpha<1 else 'DITHERED'
    return mat


def _make_mesh(name,vertices,faces,material,collection,kind):
    mesh=bpy.data.meshes.new(name+'_mesh')
    mesh.from_pydata(vertices,[],faces);mesh.update()
    obj=bpy.data.objects.new(name,mesh);collection.objects.link(obj)
    obj.data.materials.append(material)
    obj['tb_generated']=TAG
    obj['tb_type']=kind
    obj['tb_layout_version']='0.1.0'
    return obj


def _elev(x,y,settings):return tm.terrain_height(x,y,settings)


def _road(road,collection,settings):
    points=road['centerline'];width=road['width_m'];vertices=[];faces=[]
    for i,(x,y) in enumerate(points):
        px,py=points[max(0,i-1)];nx,ny=points[min(len(points)-1,i+1)]
        dx,dy=nx-px,ny-py;ln=math.hypot(dx,dy) or 1.0
        ox,oy=-dy/ln*width/2,dx/ln*width/2
        for side in (-1,1):
            wx,wy=x+side*ox,y+side*oy
            vertices.append((wx,wy,_elev(wx,wy,settings)+1.2))
        if i:faces.append((2*(i-1),2*i,2*i+1,2*(i-1)+1))
    mat=_material('TB_Road_Plan',(0.16,0.21,0.24) if road['class']!='collector' else (0.22,0.26,0.28))
    obj=_make_mesh('TB_Road_'+road['id'],vertices,faces,mat,collection,'planned_road')
    obj['tb_road_id']=road['id'];obj['tb_road_class']=road['class']
    obj['tb_road_from_node']=road['from'];obj['tb_road_to_node']=road['to']


def _district(d,collection,settings):
    inner=d['inner_boundary'];outer=d['outer_boundary'];across=11
    vertices=[];faces=[]
    for i in range(len(inner)):
        for j in range(across+1):
            t=j/across;x=inner[i][0]*(1-t)+outer[i][0]*t
            y=inner[i][1]*(1-t)+outer[i][1]*t
            vertices.append((x,y,_elev(x,y,settings)+.55))
            if i and j:
                a=(i-1)*(across+1)+j-1;b=i*(across+1)+j-1
                faces.append((a,b,b+1,a+1) if d['bank']=='north' else (a,a+1,b+1,b))
    color=tuple(int(d['color'][j:j+2],16)/255 for j in (1,3,5))
    obj=_make_mesh('TB_District_'+d['id'],vertices,faces,
          _material('TB_District_'+d['id']+'_Mat',color,.30),collection,'planned_district')
    obj['tb_district_id']=d['id'];obj['tb_district_name']=d['name'];obj['tb_land_use']=d['use']


def _bridge_reservation(br,collection,settings):
    a=br['south_abutment'];b=br['north_abutment']
    z=max(_elev(*a,settings),_elev(*b,settings))+4.0
    vertices=[];faces=[];w=2.0
    vx=b[0]-a[0];vy=b[1]-a[1];length=math.hypot(vx,vy)
    nx,ny=-vy/length,vx/length
    for k in range(14):
        t0=(k+.17)/14;t1=(k+.68)/14
        p0=(a[0]+vx*t0,a[1]+vy*t0)
        p1=(a[0]+vx*t1,a[1]+vy*t1)
        q=len(vertices)
        vertices.extend([(p0[0]-nx*w,p0[1]-ny*w,z),(p1[0]-nx*w,p1[1]-ny*w,z),
                         (p1[0]+nx*w,p1[1]+ny*w,z),(p0[0]+nx*w,p0[1]+ny*w,z)])
        faces.append((q,q+1,q+2,q+3))
    ob=_make_mesh('TB_BR_01_Reserved_Only',vertices,faces,
         _material('TB_Bridge_Reservation_Mat',(1,.76,.28)),collection,'bridge_reservation_only')
    ob['tb_bridge_status']='RESERVED — NO BRIDGE GEOMETRY'
    ob['tb_bridge_water_width_m']=br['water_width_m']
    ob['tb_span_between_abutments_m']=br['span_between_reserved_abutments_m']


def _clear():
    count=0
    for ob in list(bpy.data.objects):
        if ob.get('tb_generated')==TAG:
            bpy.data.objects.remove(ob,do_unlink=True);count+=1
    return count


class TB_OT_generate_town_layout(Operator):
    bl_idname='tb.generate_town_layout'
    bl_label='Generate Town Road / District Layout'
    bl_description='Generate planning roads, six river-aware districts and a reserved bridge crossing; no river/terrain edits'
    bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        scene=context.scene;s=scene.tb_terrain_settings
        if abs(s.width-4000)>0.01 or abs(s.length-4000)>0.01 or not s.world_space or abs(s.river_width-150)>.01:
            self.report({'ERROR'},'Apply the 4 km Map Preset (150 m river) first');return {'CANCELLED'}
        try:
            data=_read_layout()
            _clear();col=_collection(scene)
            for d in data['districts']:_district(d,col,s)
            for r in data['roads']:_road(r,col,s)
            _bridge_reservation(data['bridge'],col,s)
        except (ValueError,OSError,KeyError) as exc:
            self.report({'ERROR'},str(exc));return {'CANCELLED'}
        scene['tb_town_layout']='0.1.0'
        self.report({'INFO'},f"Town layout: {len(data['roads'])} roads, {len(data['districts'])} districts, bridge reserved")
        return {'FINISHED'}


class TB_OT_clear_town_layout(Operator):
    bl_idname='tb.clear_town_layout'
    bl_label='Clear Town Planning Overlay'
    bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        count=_clear();self.report({'INFO'},f'Cleared {count} town planning objects');return {'FINISHED'}


class TB_PT_town_layout(Panel):
    bl_label='Town Road / District Planning'
    bl_idname='TB_PT_town_layout'
    bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='Town Builder'
    def draw(self,context):
        layout=self.layout
        layout.label(text='6 districts | 14 road segments')
        layout.label(text='BR-01 | 150 m water | 178 m reserved span')
        layout.operator('tb.generate_town_layout',text='Generate / Update Town Plan',icon='OUTLINER_COLLECTION')
        layout.operator('tb.clear_town_layout',text='Clear Planning Objects',icon='TRASH')
        layout.label(text='Bridge reservation only — no deck.')
        layout.label(text='Terrain chunks stay unchanged.')

classes=(TB_OT_generate_town_layout,TB_OT_clear_town_layout,TB_PT_town_layout)

def register():
    for cls in classes:bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):bpy.utils.unregister_class(cls)
