bl_info = {
    "name": "Radial Grab — G then E",
    "author": "Seth McLaughlin",
    "version": (1, 0, 0),
    "blender": (4, 2, 0),
    "location": "3D Viewport, Object Mode: G then E; or F3 > Radial Grab",
    "description": "Mouse-driven radial translation of selected object origins; no object scaling",
    "category": "Object",
    "license": "MIT",
}

import bpy
from bpy.props import BoolProperty
from bpy_extras import view3d_utils
from mathutils import Vector

from .geometry import distribution, displaced


# Add-on keymaps have priority over built-in bindings in Blender's keymap merge.
# Intercept only *plain* G, only in Object Mode; hand off every non-E action
# immediately to Blender's original native Translate operator.
_ADDON_KEYMAPS = []
_NUM_KEYS = {**{str(i): str(i) for i in range(10)},
             **{('NUMPAD_%d' % i): str(i) for i in range(10)},
             **{n: str(i) for i, n in enumerate((
                 'ZERO', 'ONE', 'TWO', 'THREE', 'FOUR', 'FIVE',
                 'SIX', 'SEVEN', 'EIGHT', 'NINE'))}}


def _parent_depth(obj):
    depth = 0
    p = obj.parent
    while p is not None:
        depth += 1
        p = p.parent
    return depth


def _native_grab(context, event):
    """Run Blender's transform, not an approximation of its mouse handling.

    X/Y/Z are translated to their equivalent native transform constraint.
    Other first key presses are delegated, although Blender cannot replay the
    exact first keyboard event into a newly invoked modal native operator.
    """
    if event.type in {'X', 'Y', 'Z'} and event.value == 'PRESS':
        index = 'XYZ'.index(event.type)
        axes = tuple(i == index for i in range(3))
        orientation = context.scene.transform_orientation_slots[0].type
        # G, X/Y/Z in Blender uses the current transform orientation.
        if orientation in {'GLOBAL', 'LOCAL', 'NORMAL', 'GIMBAL', 'VIEW', 'CURSOR', 'PARENT'}:
            bpy.ops.transform.translate('INVOKE_DEFAULT',
                                        constraint_axis=axes, orient_type=orientation)
        else:
            bpy.ops.transform.translate('INVOKE_DEFAULT', constraint_axis=axes)
    else:
        bpy.ops.transform.translate('INVOKE_DEFAULT')


class VIEW3D_OT_radial_grab(bpy.types.Operator):
    """Move origins apart or together with one mouse drag."""
    bl_idname = 'view3d.radial_grab'
    bl_label = 'Radial Grab'
    bl_description = 'Expand selected objects radially using the mouse (C: exact circle)'
    bl_options = {'REGISTER', 'UNDO', 'BLOCKING'}

    exact_circle: BoolProperty(
        name='Exact Circle',
        description='Place objects on a perfect ring rather than offsetting existing locations',
        default=False,
    )

    @classmethod
    def poll(cls, context):
        return (context.area is not None and context.area.type == 'VIEW_3D'
                and context.mode == 'OBJECT'
                and len(context.selected_editable_objects) >= 2)

    def _set_header(self, context):
        if self._area is None:
            return
        style = 'EXACT CIRCLE' if self.exact_circle else 'RELATIVE SPREAD'
        shown = self._numeric if self._numeric else f'{self._amount:+.3f} BU'
        self._area.header_text_set(
            f'Radial Grab  |  {style}  |  {shown}  |  '
            f'Mouse horizontal: distance   Shift: fine   Ctrl: snap 0.1 BU   '
            f'C: circle/relative   LMB/Enter: confirm   Esc/RMB: cancel'
        )

    def _cleanup(self):
        if getattr(self, '_area', None) is not None:
            try:
                self._area.header_text_set(None)
            except ReferenceError:
                pass
            self._area = None

    def _apply(self):
        amount = self._amount
        if self._numeric:
            try:
                amount = float(self._numeric)
            except ValueError:
                return
        points = displaced(self._positions, self._center, self._angles,
                           amount, exact_circle=self.exact_circle,
                           base_radius=self._base_radius)
        # Assign parent objects before their selected children. Full world
        # matrices preserve original rotation, orientation, and object scaling.
        for index in self._apply_order:
            mat = self._initial_matrices[index].copy()
            mat.translation = Vector(points[index])
            self._objects[index].matrix_world = mat

    def _restore(self):
        for index in self._apply_order:
            try:
                self._objects[index].matrix_world = self._initial_matrices[index].copy()
            except ReferenceError:
                pass

    def invoke(self, context, event):
        if not self.poll(context):
            self.report({'WARNING'}, 'Select two or more editable objects in Object Mode')
            return {'CANCELLED'}

        # Sort once for deterministic naming and repeatable circle layout.
        self._objects = sorted(context.selected_editable_objects, key=lambda ob: ob.name_full)
        self._initial_matrices = [obj.matrix_world.copy() for obj in self._objects]
        self._positions = [tuple(matrix.translation) for matrix in self._initial_matrices]
        self._center, self._angles, self._base_radius = distribution(
            self._positions, [obj.name_full for obj in self._objects]
        )
        self._apply_order = sorted(range(len(self._objects)),
                                   key=lambda idx: (_parent_depth(self._objects[idx]), idx))
        self._mouse_start_x = event.mouse_region_x
        self._mouse_x = event.mouse_region_x
        self._mouse_y = event.mouse_region_y
        self._amount = 0.0
        self._numeric = ''
        self._area = context.area
        self._units_per_pixel = self._pixel_scale(context)
        self._set_header(context)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def _pixel_scale(self, context):
        # World-space viewport distance corresponding to a horizontal pixel.
        # This works in orthographic and perspective view at the centre depth.
        try:
            x = self._mouse_x
            y = self._mouse_y
            a = view3d_utils.region_2d_to_location_3d(
                context.region, context.space_data.region_3d,
                (x, y), Vector(self._center))
            b = view3d_utils.region_2d_to_location_3d(
                context.region, context.space_data.region_3d,
                (x + 100, y), Vector(self._center))
            val = (b - a).length / 100.0
            if val > 1e-8:
                return val
        except (RuntimeError, ValueError, AttributeError):
            pass
        return max(0.0001, context.space_data.region_3d.view_distance / max(context.region.width, 1))

    def _mouse_move(self, event):
        self._mouse_x = event.mouse_region_x
        self._mouse_y = event.mouse_region_y
        # Move mouse right to expand, left to contract.
        offset = (self._mouse_x - self._mouse_start_x) * self._units_per_pixel
        if event.shift:
            offset *= 0.1
        if event.ctrl:
            offset = round(offset / 0.1) * 0.1
        self._amount = offset

    def modal(self, context, event):
        if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
            self._restore()
            self._cleanup()
            return {'CANCELLED'}
        if (event.type in {'LEFTMOUSE', 'RET', 'NUMPAD_ENTER'}
                and event.value == 'PRESS'):
            self._apply()
            self._cleanup()
            return {'FINISHED'}

        if event.type == 'MOUSEMOVE':
            self._mouse_move(event)
            self._apply()
            self._set_header(context)
            return {'RUNNING_MODAL'}

        if event.value == 'PRESS':
            if event.type == 'C':
                self.exact_circle = not self.exact_circle
            elif event.type in _NUM_KEYS:
                self._numeric += _NUM_KEYS[event.type]
            elif event.type in {'PERIOD', 'NUMPAD_PERIOD'}:
                if '.' not in self._numeric:
                    self._numeric += '.'
            elif event.type in {'MINUS', 'NUMPAD_MINUS'}:
                if self._numeric.startswith('-'):
                    self._numeric = self._numeric[1:]
                else:
                    self._numeric = '-' + self._numeric
            elif event.type == 'BACK_SPACE':
                self._numeric = self._numeric[:-1]
            elif event.type == 'R':
                self._numeric = ''
                self._mouse_start_x = self._mouse_x
                self._amount = 0.0
            else:
                return {'RUNNING_MODAL'}
            self._apply()
            self._set_header(context)
        return {'RUNNING_MODAL'}


class VIEW3D_OT_radial_grab_prefix(bpy.types.Operator):
    """Start normal G, or press E before mouse motion to enter Radial Grab."""
    bl_idname = 'view3d.radial_grab_prefix'
    bl_label = 'Grab / Radial Grab Prefix'
    bl_description = 'Press E immediately after G for radial spread; otherwise normal Grab'
    bl_options = {'INTERNAL', 'BLOCKING'}

    @classmethod
    def poll(cls, context):
        return (context.area is not None and context.area.type == 'VIEW_3D'
                and context.mode == 'OBJECT')

    def invoke(self, context, event):
        self._start_x = event.mouse_region_x
        self._start_y = event.mouse_region_y
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
            return {'CANCELLED'}
        if event.type == 'E' and event.value == 'PRESS':
            if VIEW3D_OT_radial_grab.poll(context):
                bpy.ops.view3d.radial_grab('INVOKE_DEFAULT')
            else:
                self.report({'WARNING'}, 'Radial Grab requires at least 2 selected editable objects')
            return {'CANCELLED'}
        # Don't hand off on modifier events or key releases; this lets users
        # reach E even if a keyboard modifier or key-up event intervenes.
        if event.type in {'LEFT_SHIFT', 'RIGHT_SHIFT', 'LEFT_CTRL', 'RIGHT_CTRL',
                          'LEFT_ALT', 'RIGHT_ALT'} or event.value == 'RELEASE':
            return {'RUNNING_MODAL'}
        if event.type.startswith('TIMER') or event.type in {'INBETWEEN_MOUSEMOVE'}:
            return {'RUNNING_MODAL'}
        if event.type in {'MOUSEMOVE', 'LEFTMOUSE'} or event.value == 'PRESS':
            try:
                _native_grab(context, event)
            except Exception as exc:
                self.report({'ERROR'}, f'Could not start native Grab: {exc}')
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}


_CLASSES = (VIEW3D_OT_radial_grab, VIEW3D_OT_radial_grab_prefix)


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    wm = bpy.context.window_manager
    if wm and wm.keyconfigs.addon:
        km = wm.keyconfigs.addon.keymaps.new(name='Object Mode', space_type='EMPTY')
        item = km.keymap_items.new('view3d.radial_grab_prefix', 'G', 'PRESS')
        _ADDON_KEYMAPS.append((km, item))
        # A direct keybinding remains available when another addon overrides G.
        direct = km.keymap_items.new('view3d.radial_grab', 'G', 'PRESS', shift=True, ctrl=True)
        _ADDON_KEYMAPS.append((km, direct))


def unregister():
    for km, item in reversed(_ADDON_KEYMAPS):
        try:
            km.keymap_items.remove(item)
        except (RuntimeError, ReferenceError):
            pass
    _ADDON_KEYMAPS.clear()
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)


if __name__ == '__main__':
    register()
