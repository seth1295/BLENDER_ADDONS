"""Shed Builder: parametric steel portal sheds and hinged corrugated doors.

Create: Shift+A > Shed Builder. Edit: N > Shed Builder.
"""
bl_info = {
    'name': 'Shed Builder - Portal Frames & Corrugated Cladding',
    'author': 'Community Shed Tools',
    'version': (1, 0, 3),
    'blender': (4, 2, 0),
    'location': '3D View > Shift+A > Shed Builder; N > Shed Builder',
    'description': 'Editable steel portal-frame sheds, corrugated walls and roofs, hinged doors, and ambientCG materials',
    'category': 'Add Mesh',
}

import math
from pathlib import Path

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty, StringProperty
from bpy.types import Operator, Panel, Menu, PropertyGroup
from bpy_extras.io_utils import ImportHelper

from .assets import ASSETS, ASSET_IDS, asset_from_archive_name, download_and_install, install_archive, installed_maps
from .generator import (
    ROOT_ID, HINGE_ID, associated_objects, create_root, delete_shed, owner_root,
    rebuild, swing_doors, toggle_cladding,
)
from .materials import cache_root, get_cladding_material

ASSET_ITEMS = [(key, label, 'ambientCG CC0 material', index) for index,(key,label) in enumerate(ASSETS)]
_RUNNING=set()


def _owner(p):
    ob=p.id_data
    return ob if isinstance(ob,bpy.types.Object) and ob.get(ROOT_ID) else None


def _on_shape(self,context):
    root=_owner(self)
    if root is None or root.get('sb_initializing') or not self.auto_update or context.mode!='OBJECT':
        return
    token=root[ROOT_ID]
    if token in _RUNNING:return
    try:
        _RUNNING.add(token)
        # If a generated member was selected, preserve a valid active object
        # while its old mesh is replaced.
        if context.view_layer.objects.active is not root:
            current=context.view_layer.objects.active
            if current and owner_root(current)==root:
                current.select_set(False)
                root.select_set(True)
                context.view_layer.objects.active=root
        rebuild(root,context)
    finally:
        _RUNNING.discard(token)



def _on_material(self,context):
    root=_owner(self)
    if root is not None and not root.get('sb_initializing'):
        get_cladding_material(root,context)

def _on_view(self,context):
    root=_owner(self)
    if root is not None:
        toggle_cladding(root)


class SB_Settings(PropertyGroup):
    is_root: BoolProperty(default=False,options={'HIDDEN'})
    auto_update: BoolProperty(name='Update automatically',default=True,
        description='Rebuild live when dimensions or materials change; disable for large buildings')
    width: FloatProperty(name='Span / width',default=9.0,min=2,max=80,subtype='DISTANCE',unit='LENGTH',update=_on_shape)
    length: FloatProperty(name='Length',default=12.0,min=2,max=150,subtype='DISTANCE',unit='LENGTH',update=_on_shape)
    eave_height: FloatProperty(name='Eave height',default=4.1,min=2.2,max=20,
                               subtype='DISTANCE',unit='LENGTH',update=_on_shape)
    roof_type: EnumProperty(name='Roof design',items=[
        ('GABLE','Gable','Classic pitched roof / double slope'),
        ('SKILLION','Skillion / mono-pitch','Single roof plane sloping across the span'),
        ('GAMBREL','Gambrel / barn','Four pitched roof faces'),
    ],default='GABLE',update=_on_shape)
    roof_pitch: FloatProperty(name='Main roof pitch',default=math.radians(17),min=math.radians(3),
                              max=math.radians(50),subtype='ANGLE',unit='ROTATION',update=_on_shape)
    barn_lower_pitch: FloatProperty(name='Barn lower pitch',default=math.radians(55),
                                    min=math.radians(25),max=math.radians(75),subtype='ANGLE',unit='ROTATION',update=_on_shape)
    barn_break: FloatProperty(name='Barn lower run',default=.37,min=.15,max=.8,
                               subtype='FACTOR',update=_on_shape)
    overhang: FloatProperty(name='Roof overhang',default=.30,min=0,max=2.0,
                            subtype='DISTANCE',unit='LENGTH',update=_on_shape)
    bay_spacing: FloatProperty(name='Portal bay spacing',default=3.,min=.75,max=12,
                               subtype='DISTANCE',unit='LENGTH',update=_on_shape)
    purlin_spacing: FloatProperty(name='Roof purlin spacing',default=1.25,min=.35,max=4,
                                  subtype='DISTANCE',unit='LENGTH',update=_on_shape)
    girt_spacing: FloatProperty(name='Wall girt spacing',default=1.15,min=.35,max=4,
                                subtype='DISTANCE',unit='LENGTH',update=_on_shape)
    bracing: BoolProperty(name='Bracing',default=True,update=_on_shape)
    front_wall: BoolProperty(name='Front wall',default=True,update=_on_shape)
    back_wall: BoolProperty(name='Back wall',default=True,update=_on_shape)
    left_wall: BoolProperty(name='Left wall',default=True,update=_on_shape)
    right_wall: BoolProperty(name='Right wall',default=True,update=_on_shape)
    show_cladding: BoolProperty(name='Show cladding in viewport',default=True,update=_on_view)
    sheet_width: FloatProperty(name='Nominal sheet width',default=.91,min=.20,max=2,
                               subtype='DISTANCE',unit='LENGTH',update=_on_shape)
    sheet_pitch: FloatProperty(name='Corrugation pitch',default=.076,min=.02,max=.3,
                               subtype='DISTANCE',unit='LENGTH',update=_on_shape)
    sheet_depth: FloatProperty(name='Corrugation depth',default=.018,min=0,max=.10,
                               subtype='DISTANCE',unit='LENGTH',update=_on_shape)
    sheet_thickness: FloatProperty(name='Sheet gauge',default=.0007,min=0,max=.01,
                                   precision=4,subtype='DISTANCE',unit='LENGTH',update=_on_shape)
    sheet_profile: EnumProperty(name='Profile',items=[
        ('ROUND','Round corrugation','Traditional sinusoidal profile'),
        ('TRAPEZOID','Trapezoid','Crimped, flat crest/valley profile'),
    ],default='ROUND',update=_on_shape)
    samples_per_wave: IntProperty(name='Segments / wave',default=6,min=4,max=16,update=_on_shape)
    overlap_waves: IntProperty(name='Side-lap waves',default=1,min=0,max=3,update=_on_shape)
    door_mode: EnumProperty(name='Door type',items=[
        ('NONE','No door','No opening'),
        ('SINGLE','Single hinged','One swinging metal-clad leaf'),
        ('DOUBLE','Double hinged','Two swinging metal-clad leaves'),
    ],default='DOUBLE',update=_on_shape)
    door_wall: EnumProperty(name='Door wall',items=[
        ('FRONT','Front gable','Front wall at local negative Y'),
        ('BACK','Rear gable','Rear wall at positive Y'),
        ('LEFT','Left side','Left wall at local negative X'),
        ('RIGHT','Right side','Right wall at positive X'),
    ],default='FRONT',update=_on_shape)
    hinge_side: EnumProperty(name='Single hinge',items=[
        ('LEFT','Left hinge','Hinges at the left edge of the door'),
        ('RIGHT','Right hinge','Hinges at the right edge of the door'),
    ],default='LEFT',update=_on_shape)
    door_width: FloatProperty(name='Door opening width',default=3.0,min=.7,max=12,
                              subtype='DISTANCE',unit='LENGTH',update=_on_shape)
    door_height: FloatProperty(name='Door opening height',default=3.15,min=1.5,max=10,
                               subtype='DISTANCE',unit='LENGTH',update=_on_shape)
    door_offset: FloatProperty(name='Door horizontal offset',default=0,min=-50,max=50,
                               subtype='DISTANCE',unit='LENGTH',update=_on_shape)
    base_asset: EnumProperty(name='Main metal',items=ASSET_ITEMS,default='Metal050C',update=_on_material)
    rust_asset: EnumProperty(name='Corrosion PBR',items=ASSET_ITEMS,default='Rust002',update=_on_material)
    rust_amount: FloatProperty(name='Rust',default=.13,min=0,max=1,subtype='FACTOR',update=_on_material)
    dirt_amount: FloatProperty(name='Dirt',default=.09,min=0,max=1,subtype='FACTOR',update=_on_material)
    edge_rust: FloatProperty(name='Cut-edge corrosion',default=.45,min=0,max=1,subtype='FACTOR',update=_on_material)
    rust_patch_size: FloatProperty(name='Rust island scale',default=3.8,min=.5,max=50,update=_on_material)
    roughness_bias: FloatProperty(name='Extra roughness',default=.06,min=-.5,max=.5,update=_on_material)
    bump_strength: FloatProperty(name='Bump strength',default=.4,min=0,max=1,update=_on_material)
    micro_height: FloatProperty(name='PBR height',default=.0005,min=0,max=.01,
                                precision=5,subtype='DISTANCE',unit='LENGTH',update=_on_material)
    micro_detail: EnumProperty(name='Surface relief',items=[
        ('BUMP','Bump / normal (fast)','No additional render triangles'),
        ('TRUE','True Cycles displacement','Adds render subdivision; expensive for many sheets'),
    ],default='BUMP',update=_on_shape)
    render_subdivision: IntProperty(name='Render subdivision',default=1,min=1,max=3,update=_on_shape)
    texture_tile_m: FloatProperty(name='Texture metres / tile',default=1.2,min=.1,max=10,update=_on_material)
    texture_resolution: EnumProperty(name='PBR resolution',items=[
        ('1K','1K','Lower RAM/VRAM usage'),('2K','2K','Higher detail')
    ],default='1K',update=_on_shape)


class SB_OT_Add(Operator):
    bl_idname='mesh.sb_add_shed'
    bl_label='Create Parametric Shed'
    bl_description='Add a portal frame shed at the 3D Cursor, then edit in the N-sidebar'
    bl_options={'REGISTER','UNDO'}
    preset: EnumProperty(name='Shed preset',items=[
        ('GABLE','Gable workshop','Enclosed steel portal shed with paired hinged doors'),
        ('OPEN','Open-bay farm shed','Partly enclosed portal-frame farm shed'),
        ('SKILLION','Mono-pitch shed','Enclosed skillion roof workshop'),
        ('BARN','Barn / gambrel shed','Four-slope barn-style portal shed'),
    ],default='GABLE')

    def execute(self,context):
        if context.mode!='OBJECT':
            self.report({'ERROR'},'Switch to Object Mode to create a shed')
            return {'CANCELLED'}
        root=create_root(context,self.preset)
        self.report({'INFO'},f'Shed created ({root.get("sb_parts",0)} parts). N > Shed Builder to edit.')
        return {'FINISHED'}


class SB_MT_Add(Menu):
    bl_label='Shed Builder'
    bl_idname='SB_MT_add'

    def draw(self,context):
        layout=self.layout
        for preset,label,icon in (
            ('GABLE','Enclosed gable shed','HOME'),
            ('OPEN','Open-bay farm shed','OUTLINER_COLLECTION'),
            ('SKILLION','Mono-pitch shed','MOD_BUILD'),
            ('BARN','Barn / gambrel shed','MOD_ARRAY'),
        ):
            op=layout.operator('mesh.sb_add_shed',text=label,icon=icon)
            op.preset=preset


def _draw_add(self,context):
    self.layout.menu(SB_MT_Add.bl_idname,text='Shed Builder',icon='HOME')


class SB_OT_Rebuild(Operator):
    bl_idname='sb.rebuild'
    bl_label='Rebuild Shed'
    bl_description='Regenerate framing and cladding from the shed dimensions; keep door hinge angles'
    bl_options={'REGISTER','UNDO'}

    def execute(self,context):
        root=owner_root(context.active_object)
        if not root:
            return {'CANCELLED'}
        if context.mode!='OBJECT':
            self.report({'ERROR'},'Switch to Object Mode to rebuild')
            return {'CANCELLED'}
        if context.active_object is not root:
            context.active_object.select_set(False)
            root.select_set(True)
            context.view_layer.objects.active=root
        count=rebuild(root,context)
        self.report({'INFO'},f'Rebuilt {count} components')
        return {'FINISHED'}


def _empty_failed_roots():
    """Pre-1.0.1 leftovers: a controller with no completed build or children."""
    objects = list(bpy.data.objects)
    return [ob for ob in objects
            if ob.get(ROOT_ID) and ob.sb_settings.is_root
            and 'sb_parts' not in ob
            and not any(item.parent == ob or
                        item.get('shed_builder_owner') == ob.get(ROOT_ID)
                        for item in objects if item is not ob)]


class SB_OT_CleanFailed(Operator):
    bl_idname='sb.clean_failed_sheds'
    bl_label='Remove Empty Failed Shed Controllers'
    bl_description='Remove only incomplete shed controllers with no generated or manually attached objects'
    bl_options={'REGISTER','UNDO'}

    def execute(self,context):
        candidates=_empty_failed_roots()
        for root in candidates:
            delete_shed(root)
        self.report({'INFO'},f'Removed {len(candidates)} empty failed shed controllers')
        return {'FINISHED'}


class SB_OT_Delete(Operator):
    bl_idname='sb.delete_shed'
    bl_label='Delete Entire Shed'
    bl_description='Remove the shed controller, framing, doors, cladding and its collection'
    bl_options={'REGISTER','UNDO'}

    def execute(self,context):
        root=owner_root(context.active_object)
        if not root:return {'CANCELLED'}
        delete_shed(root)
        return {'FINISHED'}


class SB_OT_Swing(Operator):
    bl_idname='sb.swing_door'
    bl_label='Set Door Opening'
    bl_description='Rotate hinge pivot around its local Z axis (angle can also be edited or keyframed manually)'
    bl_options={'REGISTER','UNDO'}
    angle: FloatProperty(name='Open angle',subtype='ANGLE',default=math.radians(90))

    def execute(self,context):
        root=owner_root(context.active_object)
        if not root:return {'CANCELLED'}
        swing_doors(root,self.angle)
        return {'FINISHED'}


class SB_OT_Fetch(Operator):
    bl_idname='sb.fetch_pbr'
    bl_label='Download ambientCG Maps'
    bl_description='Download selected CC0 PBR files to the shared Corrugated Iron Generator texture cache'
    bl_options={'REGISTER'}
    asset_id: StringProperty()
    resolution: EnumProperty(items=[('1K','1K',''),('2K','2K','')],default='1K')

    def execute(self,context):
        if self.asset_id not in ASSET_IDS:return {'CANCELLED'}
        try:
            _,maps=download_and_install(self.asset_id,self.resolution,cache_root(context))
        except Exception as exc:
            self.report({'ERROR'},'ambientCG download failed: '+str(exc)[:200])
            return {'CANCELLED'}
        # Material updates do not regenerate any sheets or erase hinge selections.
        for image in bpy.data.images:
            try:
                image.reload()
            except (RuntimeError,ValueError,OSError):
                pass
        for ob in bpy.data.objects:
            if ob.get(ROOT_ID):
                get_cladding_material(ob,context)
        self.report({'INFO'},f'{self.asset_id}: {len(maps)} PBR maps downloaded')
        return {'FINISHED'}


class SB_OT_Import(Operator,ImportHelper):
    bl_idname='sb.import_pbr_zip'
    bl_label='Import ambientCG ZIP'
    bl_options={'REGISTER'}
    filename_ext='.zip'
    filter_glob: StringProperty(default='*.zip',options={'HIDDEN'})

    def execute(self,context):
        try:
            asset=asset_from_archive_name(self.filepath)
            res='2K' if '_2K-' in Path(self.filepath).name.upper() else '1K'
            maps=install_archive(self.filepath,cache_root(context),asset,res)
        except Exception as exc:
            self.report({'ERROR'},str(exc)[:200])
            return {'CANCELLED'}
        root=owner_root(context.active_object)
        if root:get_cladding_material(root,context)
        self.report({'INFO'},f'{asset}: {len(maps)} maps installed')
        return {'FINISHED'}


def _active_root(context):
    return owner_root(context.active_object)


class SB_PT_Main(Panel):
    bl_label='Shed Builder'
    bl_idname='SB_PT_main'
    bl_space_type='VIEW_3D'
    bl_region_type='UI'
    bl_category='Shed Builder'

    def draw(self,context):
        ui=self.layout
        failed_count=len(_empty_failed_roots())
        if failed_count:
            ui.operator('sb.clean_failed_sheds',
                        text=f'Remove {failed_count} Empty Failed Controllers',icon='TRASH')
        root=_active_root(context)
        if not root:
            ui.label(text='Shift+A > Shed Builder',icon='INFO')
            ui.operator('mesh.sb_add_shed',icon='HOME')
            return
        s=root.sb_settings
        ui.label(text='Select controller, G/R to position')
        ui.prop(s,'auto_update')
        row=ui.row(align=True)
        row.operator('sb.rebuild',icon='FILE_REFRESH')
        row.operator('sb.delete_shed',text='',icon='TRASH')
        col=ui.column(align=True)
        col.prop(s,'width')
        col.prop(s,'length')
        col.prop(s,'eave_height')
        col.prop(s,'roof_type')
        col.prop(s,'roof_pitch')
        if s.roof_type=='GAMBREL':
            col.prop(s,'barn_lower_pitch')
            col.prop(s,'barn_break')
        col.prop(s,'overhang')
        ui.separator()
        ui.prop(s,'show_cladding',toggle=True,icon='HIDE_OFF')
        ui.label(text=f'{root.get("sb_parts",0)} components / {root.get("sb_sheets",0)} cladding parts')
        if root.get('sb_material_warning'):
            warning=ui.box()
            warning.label(text='PBR unavailable - basic steel in use',icon='ERROR')
            warning.label(text=str(root['sb_material_warning'])[:85])
        ui.label(text='Build 1.0.3 | Visualisation only')


class SB_PT_Frame(Panel):
    bl_label='Steel Framework'
    bl_parent_id='SB_PT_main'
    bl_idname='SB_PT_frame'
    bl_space_type='VIEW_3D'
    bl_region_type='UI'

    @classmethod
    def poll(cls,context):return bool(_active_root(context))

    def draw(self,context):
        ui=self.layout;s=_active_root(context).sb_settings
        ui.prop(s,'bay_spacing')
        ui.prop(s,'purlin_spacing')
        ui.prop(s,'girt_spacing')
        ui.prop(s,'bracing')
        ui.label(text='I-portals / C-girts / C-purlins')
        ui.label(text='Artist-controlled; not load-rated')


class SB_PT_Walls(Panel):
    bl_label='Walls & Corrugated Sheets'
    bl_parent_id='SB_PT_main'
    bl_idname='SB_PT_walls'
    bl_space_type='VIEW_3D'
    bl_region_type='UI'

    @classmethod
    def poll(cls,context):return bool(_active_root(context))

    def draw(self,context):
        ui=self.layout;s=_active_root(context).sb_settings
        row=ui.row(align=True)
        row.prop(s,'front_wall',toggle=True)
        row.prop(s,'back_wall',toggle=True)
        row=ui.row(align=True)
        row.prop(s,'left_wall',toggle=True)
        row.prop(s,'right_wall',toggle=True)
        ui.separator()
        ui.prop(s,'sheet_profile')
        ui.prop(s,'sheet_width')
        ui.prop(s,'sheet_pitch')
        ui.prop(s,'sheet_depth')
        ui.prop(s,'overlap_waves')
        ui.prop(s,'samples_per_wave')
        ui.prop(s,'sheet_thickness')
        ui.label(text='Last sheets cut; corrugation phase preserved')


class SB_PT_Doors(Panel):
    bl_label='Hinged Doors'
    bl_parent_id='SB_PT_main'
    bl_idname='SB_PT_doors'
    bl_space_type='VIEW_3D'
    bl_region_type='UI'

    @classmethod
    def poll(cls,context):return bool(_active_root(context))

    def draw(self,context):
        ui=self.layout;root=_active_root(context);s=root.sb_settings
        ui.prop(s,'door_mode')
        if s.door_mode=='NONE':return
        ui.prop(s,'door_wall')
        if s.door_mode=='SINGLE':ui.prop(s,'hinge_side')
        ui.prop(s,'door_width')
        ui.prop(s,'door_height')
        ui.prop(s,'door_offset')
        ui.label(text='Pivot objects are keyframeable')
        row=ui.row(align=True)
        for label,angle in [('Closed',0),('45°',45),('90°',90),('120°',120)]:
            op=row.operator('sb.swing_door',text=label)
            op.angle=math.radians(angle)
        for ob in associated_objects(root):
            side=ob.get(HINGE_ID)
            if side:
                box=ui.box()
                row=box.row(align=True)
                row.label(text=side+' hinge',icon='CONSTRAINT_BONE')
                row.prop(ob,'rotation_euler',index=2,text='Z')
                row.operator('sb.select_hinge',text='',icon='RESTRICT_SELECT_OFF').hinge_key=side
        ui.label(text='Select hinge; R Z to swing, I to keyframe')


class SB_OT_SelectHinge(Operator):
    bl_idname='sb.select_hinge'
    bl_label='Select Hinge Pivot'
    bl_options={'REGISTER','UNDO'}
    hinge_key: StringProperty()

    def execute(self,context):
        root=_active_root(context)
        if not root:return {'CANCELLED'}
        for ob in associated_objects(root):
            if ob.get(HINGE_ID)==self.hinge_key:
                for selected in context.selected_objects:selected.select_set(False)
                ob.select_set(True)
                context.view_layer.objects.active=ob
                return {'FINISHED'}
        return {'CANCELLED'}


class SB_PT_Material(Panel):
    bl_label='ambientCG / Surface Detail'
    bl_parent_id='SB_PT_main'
    bl_idname='SB_PT_mat'
    bl_space_type='VIEW_3D'
    bl_region_type='UI'

    @classmethod
    def poll(cls,context):return bool(_active_root(context))

    def draw(self,context):
        ui=self.layout;s=_active_root(context).sb_settings
        ui.prop(s,'base_asset')
        ui.prop(s,'rust_asset')
        ui.prop(s,'rust_amount',slider=True)
        ui.prop(s,'edge_rust',slider=True)
        ui.prop(s,'dirt_amount',slider=True)
        ui.prop(s,'rust_patch_size')
        ui.prop(s,'texture_tile_m')
        ui.prop(s,'roughness_bias')
        ui.prop(s,'bump_strength')
        ui.prop(s,'micro_height')
        ui.prop(s,'micro_detail')
        if s.micro_detail=='TRUE':
            ui.prop(s,'render_subdivision')
            if context.scene.render.engine!='CYCLES':
                ui.label(text='True displacement requires Cycles',icon='ERROR')
        ui.separator()
        ui.prop(s,'texture_resolution')
        for asset,label in ((s.base_asset,'Main metal'),(s.rust_asset,'Corrosion')):
            ready=bool(installed_maps(cache_root(context),asset,s.texture_resolution))
            row=ui.row(align=True)
            row.label(text=f'{label}: {asset}',icon='CHECKMARK' if ready else 'IMPORT')
            if not ready:
                op=row.operator('sb.fetch_pbr',text='Download',icon='IMPORT')
                op.asset_id=asset
                op.resolution=s.texture_resolution
        ui.operator('sb.import_pbr_zip',icon='FILE_FOLDER')
        ui.label(text='Uses existing Corrugated Iron texture cache')
        ui.label(text='Six ambientCG CC0 assets supported')


CLASSES=(SB_Settings,SB_OT_Add,SB_MT_Add,SB_OT_Rebuild,SB_OT_Delete,SB_OT_CleanFailed,SB_OT_Swing,
         SB_OT_Fetch,SB_OT_Import,SB_OT_SelectHinge,SB_PT_Main,SB_PT_Frame,
         SB_PT_Walls,SB_PT_Doors,SB_PT_Material)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Object.sb_settings=PointerProperty(type=SB_Settings)
    bpy.types.VIEW3D_MT_add.append(_draw_add)


def unregister():
    bpy.types.VIEW3D_MT_add.remove(_draw_add)
    del bpy.types.Object.sb_settings
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)

if __name__=='__main__':
    register()
