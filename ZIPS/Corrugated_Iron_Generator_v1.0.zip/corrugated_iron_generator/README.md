# Corrugated Iron Generator — Blender Add-on v1.0

**Blender 4.2+**, traditional add-on ZIP. No other Python packages required.

## Install

1. In Blender open **Edit → Preferences → Add-ons → Install from Disk** (or **Get Extensions → Install from Disk**, depending on Blender version).
2. Select `Corrugated_Iron_Generator_v1.0.zip` and enable **Corrugated Iron Generator**.
3. In the 3D viewport press **Shift+A → Mesh → Corrugated Iron Sheet**.
4. Place the sheet with Blender's native **G / R / S** transforms. Open **N → Corrugated Iron** for live profile and weathering settings.

### Mesh geometry

Round and trapezoidal corrugation; editable dimensions, corrugation pitch, depth, phase, profile resolution, and Solidify thickness. The cross-section uses just one quad strip along the length (no unnecessary lengthwise tessellation). The PBR UVs track the arc length of each corrugation in metres, keeping patterns consistent along bends. Sheet outline is represented by actual geometry, not shader displacement.

### Six ambientCG materials

All six are available in both **Base texture** and **Corrosion texture** selectors:

- [Metal026](https://ambientcg.com/view?id=Metal026)
- [Metal062C](https://ambientcg.com/view?id=Metal062C)
- [Metal050C](https://ambientcg.com/view?id=Metal050C)
- [Metal059C](https://ambientcg.com/view?id=Metal059C)
- [Metal020](https://ambientcg.com/view?id=Metal020)
- [Rust002](https://ambientcg.com/view?id=Rust002)

Materials include base color, roughness, metalness, OpenGL tangent normal, AO, and displacement when provided by ambientCG. Rust is generated as a **material blend** with separate patch coverage, edge weathering, and dirt. Changes are live for the selected sheet.

The ZIP deliberately **does not include the 1K/2K textures**. Use the **ambientCG PBR Library** section of N-panel and click **Download 1K** or **Download 2K** for each selected slot. Downloads use ambientCG's official ZIP redirect, and only PBR image maps are extracted into a persistent cache under Blender's user data directory. Set a custom directory under the add-on's Preferences if desired. Internet access is required **only** when downloading. You can alternatively download original `1K-JPG.zip`/`2K-JPG.zip` assets from the ambientCG website and use **Install downloaded ambientCG ZIP**. A procedural metal/rust material is present before any downloads.

Click **Pack sheet images into .blend** to pack the used image maps in a saved Blender file.

### Displacement and performance

- **Bump / normal (fast)**: default; no micro-detail topology. Works in Eevee and Cycles.
- **True displacement (Cycles)**: render-only Simple subdivision before Solidify + a Material Output Displacement node. Use Cycles; increase Render subdivisions only as needed. The viewport mesh remains low-poly, but **true rendered displacement increases render-time polygon count**.

Actual corrugations always use real (but inexpensive) cross-sectional mesh geometry so silhouettes are right. A 0.90 m sheet with 76 mm pitch and 8 samples per wave has about 95 profile segments, or ~190 surface triangles, prior to Solidify.

### Restrictions / practical notes

- Generated material changes apply to an individual object, even if you duplicate the sheet.
- Object-mode live editing only; manual vertex edits on generated geometry are replaced when changing profile properties. For permanent direct vertex editing, duplicate and convert/apply as needed.
- Downloads happen synchronously on pressing the download button; on a slow network Blender may briefly stop responding until the archive is received.
- The texture cache may remain in Blender's user data folder after the add-on is uninstalled. Delete it manually when no longer needed.
- Asset quality is determined by the source maps; ambientCG metal presets were not made specifically for corrugated galvanized sheet metal.
- No official affiliation with ambientCG. Its textures are published under **Creative Commons CC0**; see [ambientCG license](https://docs.ambientcg.com/license/).

## Attributions / third-party data

Code in this add-on does not ship bundled image maps. Linked ambientCG materials and their downloads are CC0. Blender is a trademark of Blender Foundation. All network transfers are initiated by a button click.
