"""Dependency-free 3D path and frame mathematics for Conduit Forge.

The Blender layer passes local-space coordinates as ordinary tuples. This module
can be tested outside Blender and deliberately never imports bpy/mathutils.
"""
import bisect
import math

TAU = math.tau
EPS = 1.0e-9


def add(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def mul(a, s):
    return (a[0] * s, a[1] * s, a[2] * s)


def dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])


def length(a):
    return math.sqrt(dot(a, a))


def unit(a, fallback=(1.0, 0.0, 0.0)):
    n = length(a)
    return mul(a, 1.0/n) if n > EPS else fallback


def cubic(p0, p1, p2, p3, t):
    v = 1.0 - t
    return add(add(mul(p0, v*v*v), mul(p1, 3*v*v*t)),
               add(mul(p2, 3*v*t*t), mul(p3, t*t*t)))


def cubic_tangent(p0, p1, p2, p3, t):
    v = 1.0 - t
    return add(add(mul(sub(p1,p0), 3*v*v), mul(sub(p2,p1), 6*v*t)),
               mul(sub(p3,p2), 3*t*t))


def sample_route(start, middle, end, directions, scales, tension, segments):
    """Two C1-connected cubic segments. Directions follow each empty's local Z.

    A middle guide is BOTH a position and a tangent; local Z scale extends its
    tangent handles. No join discontinuity is introduced at the middle guide.
    """
    d0, dm, d1 = [unit(d) for d in directions]
    s0, sm, s1 = [max(0.05, abs(float(s))) for s in scales]
    a = length(sub(middle, start))
    b = length(sub(end, middle))
    a = max(a, 0.0001)
    b = max(b, 0.0001)
    k = 0.37 * tension
    middle_handle = 0.5 * (a+b) * k * sm
    curves = [
        (start, add(start, mul(d0, a*k*s0)), sub(middle, mul(dm, middle_handle)), middle),
        (middle, add(middle, mul(dm, middle_handle)), sub(end, mul(d1, b*k*s1)), end),
    ]
    samples, tangents = [], []
    for j, c in enumerate(curves):
        for i in range(segments + 1):
            if j and i == 0:
                continue
            t = i / segments
            samples.append(cubic(*c, t))
            tangents.append(unit(cubic_tangent(*c, t), (1.0, 0.0, 0.0)))
    return samples, tangents


def _rotate_axis(v, axis, sin_a, cos_a):
    # Rodrigues' rotation formula.
    return add(add(mul(v, cos_a), mul(cross(axis, v), sin_a)),
               mul(axis, dot(axis, v) * (1.0 - cos_a)))


def parallel_frames(tangents):
    """Parallel-transport frames: significantly less twisting than Frenet frames."""
    if not tangents:
        return []
    t0 = unit(tangents[0])
    helper = (0.0, 0.0, 1.0) if abs(t0[2]) < 0.85 else (0.0, 1.0, 0.0)
    normal = unit(cross(t0, helper), (1.0, 0.0, 0.0))
    frames = [(normal, unit(cross(t0, normal)))]
    old = t0
    for raw in tangents[1:]:
        t = unit(raw, old)
        axis = cross(old, t)
        sin_a = length(axis)
        cos_a = max(-1.0, min(1.0, dot(old, t)))
        if sin_a > EPS:
            normal = _rotate_axis(normal, mul(axis, 1.0/sin_a), sin_a, cos_a)
        elif cos_a < 0.0:
            normal = mul(normal, -1.0)
        normal = unit(sub(normal, mul(t, dot(t, normal))), frames[-1][0])
        frames.append((normal, unit(cross(t, normal))))
        old = t
    return frames


def cumulative_lengths(points):
    lengths = [0.0]
    for a, b in zip(points, points[1:]):
        lengths.append(lengths[-1] + length(sub(b, a)))
    return lengths


def interpolate_distance(points, tangents, frames, lengths, fraction):
    """Linear interpolation indexed by true arc-length, with re-orthogonalization."""
    if not points:
        raise ValueError('Empty path')
    f = max(0.0, min(1.0, fraction))
    goal = lengths[-1] * f
    idx = max(0, min(len(points)-2, bisect.bisect_right(lengths, goal)-1))
    gap = lengths[idx+1] - lengths[idx]
    w = (goal-lengths[idx])/gap if gap > EPS else 0.0
    lerp = lambda a, b: add(mul(a, 1.0-w), mul(b, w))
    point = lerp(points[idx], points[idx+1])
    tangent = unit(lerp(tangents[idx], tangents[idx+1]))
    n = lerp(frames[idx][0], frames[idx+1][0])
    n = unit(sub(n, mul(tangent, dot(n, tangent))), frames[idx][0])
    side = unit(cross(tangent, n))
    return point, tangent, n, side


def helical_points(points, tangents, frames, lengths, turns, radius, phase,
                   steps, f0=0.0, f1=1.0, radial_wave=0.0, wave_frequency=1.0):
    out = []
    for i in range(steps+1):
        f = f0 + (f1-f0)*i/steps
        p, _, n, b = interpolate_distance(points,tangents,frames,lengths,f)
        theta = TAU * turns * f + phase
        wave = radial_wave * math.sin(TAU*wave_frequency*f + phase*2.0)
        r = radius + wave
        out.append(add(p, add(mul(n, r*math.cos(theta)), mul(b, r*math.sin(theta)))))
    return out


def tube_mesh(points, frames, radius, sides):
    verts = []
    faces = []
    for p, (n, b) in zip(points, frames):
        for j in range(sides):
            theta = TAU*j/sides
            verts.append(add(p, add(mul(n, radius*math.cos(theta)), mul(b, radius*math.sin(theta)))))
    for k in range(len(points)-1):
        for j in range(sides):
            j2 = (j+1) % sides
            faces.append((k*sides+j, k*sides+j2, (k+1)*sides+j2, (k+1)*sides+j))
    faces.append(tuple(reversed(tuple(range(sides)))))
    base = (len(points)-1)*sides
    faces.append(tuple(range(base, base+sides)))
    return verts, faces
