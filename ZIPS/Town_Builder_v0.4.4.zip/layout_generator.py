"""Town Builder layout source: deterministic spatial design (stdlib only).

Generates bridge reservation, connected arterial-road network and six river-aware
planning districts on the exact 4 km Town Builder terrain. All positions are
world-space metres, with x east and y north (viewer: x and z).
No road grading or bridge construction is performed in this milestone.
"""
from __future__ import annotations
import json, math, sys
from pathlib import Path
from types import SimpleNamespace

TM_PATH = Path(__file__).resolve().parent / 'terrain_math.py'
import importlib.util
spec=importlib.util.spec_from_file_location('layout_terrain_math', TM_PATH)
tm=importlib.util.module_from_spec(spec)
spec.loader.exec_module(tm)

S=SimpleNamespace(world_space=True,width=4000.,length=4000.,seed=1,elevation=38,
    base_height=18,river_width=150,river_depth=24,bank_width=2,bank_rise=7,
    valley_width=220,water_level=0,water_drop=4,rolling_relief=11,
    border_hill_height=82,border_hill_band=850)

def v2(x,y): return [round(x,5),round(y,5)]
def rcenter(x): return tm.river_center_y(x,S)
def scale(x): return math.hypot(1,tm.river_dydx(x,S))
def nxy(x):
    m=tm.river_dydx(x,S); q=math.hypot(1,m)
    return -m/q,1/q

def normal_point(x,t):
    nx,ny=nxy(x)
    return v2(x+nx*t,rcenter(x)+ny*t)

def bank_parallel(x,side,offset=320.):
    return v2(x,rcenter(x)+side*offset*scale(x))

def h(xy):return tm.terrain_height(xy[0],xy[1],S)

def select_bridge():
    # Seed-free, auditable suitability scoring. No grade is fabricated by this check.
    candidates=[]
    for x in range(-400,401,25):
        m=tm.river_dydx(x,S)
        curv=abs((tm.river_dydx(x+60,S)-tm.river_dydx(x-60,S))/120)/(1+m*m)**1.5
        gradients=[];height_pair=[]
        for side in (-1,+1):
            ts=[92,125,165,210,260,320]
            z=[h(normal_point(x,side*t)) for t in ts]
            gradients.extend(abs(z[i+1]-z[i])/(ts[i+1]-ts[i]) for i in range(len(ts)-1))
            height_pair.append(z[-1])
        grade=max(gradients)
        # prioritize gentle approaches, river straightness, balanced banks and centrality
        # slight east-of-centre preference places bridge between both major activity areas
        score=grade*28+curv*700+abs(height_pair[0]-height_pair[1])*.055+abs(x-200)*.0009
        candidates.append((score,x,grade,curv,height_pair))
    candidates.sort()
    score,x,grade,curv,height_pair=candidates[0]
    span_t=S.river_width/2+S.bank_width+12
    return {'id':'BR-01','status':'reserved_not_constructed','site_x_m':x,
      'center':normal_point(x,0),'water_width_m':150,'bank_clearance_m':12,
      'north_abutment':normal_point(x,+span_t),'south_abutment':normal_point(x,-span_t),
      'span_between_reserved_abutments_m':round(2*span_t,2),
      'alignment_normal':v2(*nxy(x)),
      'site_score':round(score,4),'max_sampled_approach_grade':round(grade,5),
      'river_curvature':round(curv,7),'approach_terrain_heights_m':[round(z,2) for z in height_pair]}

def lerp(a,b,t): return [a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t]
def bezier(a,b,c,d,t):
    u=1-t;return v2(*(u*u*u*a[k]+3*u*u*t*b[k]+3*u*t*t*c[k]+t*t*t*d[k] for k in (0,1)))

def line_samples(f,a,b,step=12.):
    n=math.ceil(abs(b-a)/step)
    return [f(a+(b-a)*i/n) for i in range(n+1)]

def build_layout():
    bridge=select_bridge();x0=bridge['site_x_m']
    north_node=bank_parallel(x0,+1); south_node=bank_parallel(x0,-1)
    sites={
      'N_GATE_W':bank_parallel(-1150,+1),'N_JCT':north_node,'N_GATE_E':bank_parallel(1170,+1),
      'S_GATE_W':bank_parallel(-1150,-1),'S_JCT':south_node,'S_GATE_E':bank_parallel(1170,-1),
      'N_ABUT':bridge['north_abutment'],'S_ABUT':bridge['south_abutment']}
    roads=[]
    def road(code,label,bank,a,b,pts,width=12,roadclass='arterial'):
        assert len(pts)>=2
        roads.append({'id':code,'name':label,'class':roadclass,'bank':bank,'from':a,'to':b,
                      'width_m':width,'centerline':pts})
    for side,code,bank in [(+1,'N','north'),(-1,'S','south')]:
        for xa,xb,letter,n1,n2 in [(-1150,x0,'W',f'{code}_GATE_W',f'{code}_JCT'),
                                 (x0,1170,'E',f'{code}_JCT',f'{code}_GATE_E')]:
            road(f'{code}-MAIN-{letter}',f'{bank.title()} Main Street {letter}',bank,n1,n2,
                 line_samples(lambda xx:bank_parallel(xx,side),xa,xb),14,'primary')
        a=sites[f'{code}_JCT'];d=sites[f'{code}_ABUT']; nx,ny=nxy(x0)
        # Curved approach meets the river approximately perpendicular to flow.
        c1=v2(a[0],a[1]-side*85)
        c2=v2(d[0]+side*nx*62,d[1]+side*ny*62)
        road(f'{code}-BRIDGE-APP',f'{bank.title()} Bridge Approach',bank,
             f'{code}_JCT',f'{code}_ABUT',
             [bezier(a,c1,c2,d,i/28) for i in range(29)],14,'bridge_approach')
    # Tributary road stubs form the primary town-to-hinterland connection points.
    for side,code,bank in [(+1,'N','north'),(-1,'S','south')]:
        for xx,stub in [(-760,'W'),(850,'E')]:
            start=bank_parallel(xx,side)
            end=bank_parallel(xx+(-125 if stub=='W' else 135),side,770)
            nk=f'{code}_FEED_{stub}';ek=nk+'_END'
            sites[nk]=start;sites[ek]=end
            p1=v2(start[0]-60 if stub=='W' else start[0]+60,start[1]+side*125)
            p2=v2(end[0]+35 if stub=='W' else end[0]-35,end[1]-side*140)
            road(f'{code}-FEED-{stub}',f'{bank.title()} {"West" if stub=="W" else "East"} Connector',bank,
                 nk,ek,[bezier(start,p1,p2,end,i/42) for i in range(43)],10,'collector')
    # Main streets have graph nodes where the collectors join; snap canonical coordinates
    # to the exact existing roads, then split the affected main routes at those nodes.
    roads2=[]
    for r in roads:
        if not r['id'].startswith(('N-MAIN','S-MAIN')):
            roads2.append(r);continue
        side=1 if r['bank']=='north' else -1
        feederXs=[x for x in (-760,850) if min(r['centerline'][0][0],r['centerline'][-1][0])+1e-8<x<max(r['centerline'][0][0],r['centerline'][-1][0])-1e-8]
        if not feederXs:
            roads2.append(r);continue
        bounds=[r['centerline'][0][0]]+sorted(feederXs)+[r['centerline'][-1][0]]
        for idx,(xa,xb) in enumerate(zip(bounds,bounds[1:])):
            key=('N' if side==1 else 'S')+'_FEED_'+('W' if xa==-760 or xb==-760 else 'E')
            nodeFrom=r['from'] if idx==0 else f'{"N" if side==1 else "S"}_FEED_{"W" if xa==-760 else "E"}'
            nodeTo=r['to'] if idx==len(bounds)-2 else f'{"N" if side==1 else "S"}_FEED_{"W" if xb==-760 else "E"}'
            roads2.append({**r,'id':r['id']+f'-{idx+1}',
                          'from':nodeFrom,'to':nodeTo,
                          'centerline':line_samples(lambda xx:bank_parallel(xx,side),xa,xb)})
    roads=roads2
    # District strips follow the meandering centreline, with irregular outside boundaries.
    # Their river-facing limits begin beyond the bank, never in the 150 m water.
    defs=[
     ('N-OLD','Old Quarter','residential','north',-1150,-300,155,610,'#d9b56a'),
     ('N-CIV','Civic Centre','mixed_civic','north',-300,570,155,630,'#e5a66a'),
     ('N-WORK','North Works','industrial_trades','north',570,1200,170,640,'#a5a4cf'),
     ('S-GROVE','The Grove','residential','south',-1150,-350,155,635,'#88bd93'),
     ('S-VILL','Southbank','mixed_residential','south',-350,570,150,655,'#70b2b6'),
     ('S-FIELD','East Fields','rural_agriculture','south',570,1200,180,705,'#c8c27e'),
    ]
    districts=[]
    for did,label,kind,bank,xmin,xmax,near,outer,color in defs:
        sign=1 if bank=='north' else -1
        n=math.ceil((xmax-xmin)/24)
        # parametric bands; inside and outside borders share the same landform basis
        def inner(xx): return near+9*math.sin(xx/155+1.8)
        def far(xx): return outer+28*math.sin(xx/260+0.7)
        upper=[bank_parallel(xx,sign,far(xx)) for xx in [xmin+(xmax-xmin)*i/n for i in range(n+1)]]
        lower=[bank_parallel(xx,sign,inner(xx)) for xx in [xmin+(xmax-xmin)*i/n for i in range(n+1)]]
        polygon=(lower+upper[::-1]) if sign==1 else (upper+lower[::-1])
        districts.append({'id':did,'name':label,'use':kind,'bank':bank,'color':color,
                          'range_x_m':[xmin,xmax], 'offset_near_m':near,'offset_far_m':outer,
                          'polygon':polygon,'inner_boundary':lower,'outer_boundary':upper,
                          'label_point':bank_parallel((xmin+xmax)/2,sign,(near+outer)/2)})
    graph_edges=[{'road':r['id'],'from':r['from'],'to':r['to'],'status':'existing_in_layout'} for r in roads]
    graph_edges.append({'road':'BR-01','from':'S_ABUT','to':'N_ABUT','status':'reserved_not_constructed'})
    data={'schema':'town_builder.layout.v1','version':'0.1.0','source':'procedural',
          'coordinate_system':'metres_xy_blender__xz_threejs','terrain_baseline':'v0.4.3',
          'extent_m':[-2000,-2000,2000,2000],
          'design_intent':{'population_target':250,'town_form':'one_town_two_banks',
                 'river_width_m':150,'status':'planning_no_bridge_or_road_grading'},
          'bridge':bridge,'nodes':sites,'roads':roads,'graph_edges':graph_edges,'districts':districts}
    return data

if __name__=='__main__':
    data=build_layout()
    out=Path(__file__).resolve().parent/'town_layout.json'
    out.write_text(json.dumps(data,indent=2)+'\n')
    print('bridge',data['bridge'])
    print('roads',len(data['roads']),'districts',len(data['districts']),'layout bytes',out.stat().st_size)
