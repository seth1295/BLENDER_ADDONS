"""Pure-Python corrugated sheet profile generation in metres."""
import math


def profile_height(t, depth, style='ROUND'):
    t = t % 1.0
    if style == 'TRAPEZOID':
        if t < 0.15:
            return 0.0
        if t < 0.35:
            return depth * (t - 0.15) / 0.20
        if t < 0.65:
            return depth
        if t < 0.85:
            return depth * (0.85 - t) / 0.20
        return 0.0
    return depth * (1.0 - math.cos(2.0 * math.pi * t)) / 2.0


def build_profile(width, pitch, depth, samples_per_wave=8, style='ROUND', phase=0.0):
    """Width is exact; clipped waves at cut edges; trapezoids keep crisp bends."""
    if width <= 0 or pitch <= 0 or depth < 0:
        raise ValueError('Width / pitch must be positive and depth non-negative')
    n = min(4096, max(2, math.ceil(width / pitch * samples_per_wave)))
    positions = {0.0, width}
    for i in range(1, n):
        positions.add(width * i / n)
    if style == 'TRAPEZOID':
        start_wave = math.floor(phase) - 1
        end_wave = math.ceil(width / pitch + phase) + 1
        for wave in range(start_wave, end_wave):
            for threshold in (0.15, 0.35, 0.65, 0.85):
                x = (wave + threshold - phase) * pitch
                if 0.0 < x < width:
                    positions.add(x)
    if len(positions) > 8193:
        raise ValueError('Profile exceeds segment limit')
    return [(x - width * 0.5, profile_height(x / pitch + phase, depth, style))
            for x in sorted(positions)]


def make_sheet_geometry(width, length, pitch, depth, samples_per_wave=8,
                        style='ROUND', phase=0.0):
    """Returns vertices, quads and metre-based UVs; only two longitudinal rows."""
    if length <= 0:
        raise ValueError('Length must be positive')
    profile = build_profile(width, pitch, depth, samples_per_wave, style, phase)
    verts, faces, uvs = [], [], []
    surface_distance = 0.0
    for i, (x, z) in enumerate(profile):
        if i:
            prev_x, prev_z = profile[i-1]
            surface_distance += math.hypot(x - prev_x, z - prev_z)
        for y, v in ((-length / 2.0, 0.0), (length / 2.0, length)):
            verts.append((x, y, z))
            uvs.append((surface_distance, v))
    for i in range(len(profile) - 1):
        j = i * 2
        faces.append((j, j + 2, j + 3, j + 1))
    return verts, faces, uvs
