# Conduit Forge 1.0

A procedural Blender cable & hose rig with zero manual scripting. The creator operates through Blender's native tools rather than using an external script workflow.

**Supported Blender**: Designed for Blender 4.3+ (Blender 4.5 / 5.0 APIs referenced). Runtime in Blender has not been executed in this environment; unit and dry-run assembly checks pass.

## Install

Blender **Edit → Preferences → Get Extensions → ▼ → Install from Disk**, select `Conduit_Forge_1.0_Extension.zip` (no extraction required), then enable **Conduit Forge** if it is not already enabled. The `Legacy_Addon.zip` alternative is also supplied for Blender's legacy add-on installer.

## First use

1. In the **3D Viewport in Object Mode**, press **Shift+A → Conduit Forge Rig**.
2. Three visible arrows appear: `01 START`, `02 BEND`, `03 END`. Click and **G** to position; **R** to orient the tangent along the arrow's local Z axis; **S** on a handle to adjust tangent influence. These are Blender empties, so native constraints, parenting and keyframes are available.
3. Press **N → Conduit Forge** to set construction, dimensions, braid density, wire count, finishes, clamps, couplers and output resolution. Changes regenerate the geometry automatically, including when moving an arrow.
4. Select the rig, any arrow, or the conduit body to access the same controls later.
5. **Bake Mesh Copy** creates independent mesh copies for conventional mesh editing/export while preserving the live source.

Four constructions:

- **Cross-weave braid** — paired, counter-rotating metallic wire directions with radial crossing modulation and a flexible core.
- **Corrugated conduit** — raised helical ribs over protective tubing.
- **Multi-core harness** — independently coloured wires twisted along the routing path.
- **Hydraulic hose** — flexible rubber body with twin identification stripes.

Each style supports machined hexagonal metal couplers, clamps/ties, and selectable metallic or high-visibility finishes.

## Behaviour & limitations

- The geometry updates from **three** editable guide empties. It does **not** automatically avoid collisions or simulate physical cable settling; route the midpoint visually.
- Rotating the guide changes the tangent direction, not the object's visual appearance alone.
- Scaling a *guide* affects its tangent handle length; scaling the *root* scales the full rig.
- The 35ms coalesced update system is designed for responsive manipulation without rebuilding a new rig for every change. Dense braid settings can take longer to update on large scenes.
- Parameter values are stored in the Blend file on the root object. No runtime network calls, external scripts, or external libraries.
- Bake creates separate mesh objects (one per procedural part). Join them in Blender if a single object is required.

## Validation performed

- Python AST/compile checks on all source files.
- 11 passing tests in `tests/test_geometry.py` and `tests/test_assembly.py` (mathematical continuity, frame transport, tube topology, four style geometries, coupling/band construction).
- Cross-checked property names in Blender 5.0 Python API for `Mesh.clear_geometry`, `Spline.material_index`, `Spline.use_smooth`, and `Curve.use_fill_caps`.
- **Not** run in the actual Blender runtime because Blender is not installed in the execution environment. Functional Blender UI/runtime acceptance remains to be tested.

For a local test checkout, run `python -m unittest discover -s tests -v` in the source directory. Blender integration smoke-test is in `tests/blender_smoke.py` and can be run with `blender -b --python tests/blender_smoke.py` with `CF_SOURCE_DIR` set to the folder containing `conduit_forge`.

License: GPL-3.0-or-later for the extension distribution. The author/maintainer metadata is a neutral `Project Owner` placeholder rather than assigning credit to a model vendor.
