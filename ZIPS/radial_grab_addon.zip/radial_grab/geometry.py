"""Pure-Python radial arrangement mathematics; no Blender dependency."""
from __future__ import annotations

from math import atan2, cos, hypot, pi, sin


def distribution(positions, labels=None):
    """Return (centre_xyz, angle_per_original_index, mean_xy_radius).

    Angles are equally spaced but preserve the clockwise/counterclockwise order of
    objects around their ORIGINAL centroid. Objects at precisely the same position
    use a stable label sort (or input ordering if labels are not provided).
    The centre is the arithmetic mean of world-space object origins.
    """
    positions = [tuple(map(float, p)) for p in positions]
    count = len(positions)
    if count < 2:
        raise ValueError("Radial Grab needs at least two objects")
    if any(len(p) != 3 for p in positions):
        raise ValueError("Expected 3D positions")
    labels = [f"{i:010d}" for i in range(count)] if labels is None else labels
    if len(labels) != count:
        raise ValueError("One label per object is required")

    centre = tuple(sum(p[axis] for p in positions) / count for axis in range(3))
    data = []
    for index, (pos, name) in enumerate(zip(positions, labels)):
        dx, dy = pos[0] - centre[0], pos[1] - centre[1]
        data.append((atan2(dy, dx), hypot(dx, dy), name, index))
    mean_radius = sum(item[1] for item in data) / count

    # Entirely coincident objects have no meaningful geometric angular order.
    if max(item[1] for item in data) < 1e-9:
        order = sorted(range(count), key=lambda i: (labels[i], i))
        start_angle = 0.0
    else:
        data.sort(key=lambda item: (item[0], item[1], item[2], item[3]))
        order = [item[3] for item in data]
        start_angle = data[0][0]

    angles = [0.0] * count
    for rank, index in enumerate(order):
        angles[index] = start_angle + rank * 2.0 * pi / count
    return centre, angles, mean_radius


def displaced(positions, centre, angles, amount, *, exact_circle=False, base_radius=0.0):
    """Calculate absolute world-space targets, preserving each object's Z.

    Relative mode: object_i_original + amount * unit(angle_i).
    Circle mode: centroid + (base_radius + amount) * unit(angle_i).
    """
    radius = max(0.0, base_radius + amount)
    result = []
    for pos, angle in zip(positions, angles):
        ux, uy = cos(angle), sin(angle)
        if exact_circle:
            result.append((centre[0] + radius * ux,
                           centre[1] + radius * uy,
                           pos[2]))
        else:
            result.append((pos[0] + amount * ux,
                           pos[1] + amount * uy,
                           pos[2]))
    return result
