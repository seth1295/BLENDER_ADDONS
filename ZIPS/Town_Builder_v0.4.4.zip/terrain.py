import bpy
import bmesh
import math
from mathutils import Vector
from bpy.props import FloatProperty, IntProperty, PointerProperty, BoolProperty
from bpy.types import Operator, Panel, PropertyGroup


# Kept as a stable wrapper: the same math drives Blender and the PNG preview.
from . import terrain_math as tm


def terrain_height(nx, ny, settings):
    x = (nx - 0.5) * settings.width
    y = ny * settings.length
    return tm.terrain_height(x, y, settings)


def _material(name, rgba, roughness):
    material = bpy.data.materials.get(name)
    if material is None:
        material = bpy.data.materials.new(name)
    material.diffuse_color = rgba
    material.use_nodes = True
    principled = material.node_tree.nodes.get('Principled BSDF')
    if principled:
        principled.inputs['Base Color'].default_value = rgba
        principled.inputs['Roughness'].default_value = roughness
    return material


def _replace_obj(context, name):
    existing = bpy.data.objects.get(name)
    if existing and existing.type == 'MESH':
        old_mesh = existing.data
        existing.data = bpy.data.meshes.new(name + '_Mesh')
        if old_mesh and old_mesh.users == 0:
            bpy.data.meshes.remove(old_mesh)
        return existing
    if existing:
        bpy.data.objects.remove(existing, do_unlink=True)
    mesh = bpy.data.meshes.new(name + '_Mesh')
    obj = bpy.data.objects.new(name, mesh)
    context.collection.objects.link(obj)
    return obj


def _build_grid_mesh(obj, grid, material):
    bm = bmesh.new()
    verts = []
    for row in grid:
        verts.append([bm.verts.new(co) for co in row])
    for j in range(len(verts) - 1):
        for i in range(len(verts[j]) - 1):
            bm.faces.new((verts[j][i], verts[j + 1][i], verts[j + 1][i + 1], verts[j][i + 1]))
    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()
    if material.name not in obj.data.materials:
        obj.data.materials.append(material)
    for poly in obj.data.polygons:
        poly.use_smooth = True


def build_mesh(context, settings):
    """Construct terrain and a separate, connected river water surface."""
    error = tm.validate_corridor(settings)
    if error:
        raise ValueError(error)

    xs = tm.terrain_x_coords(settings)
    terrain_grid = []
    water_grid = []
    for x in xs:
        ys, shore_left, shore_right = tm.terrain_y_rows(x, settings)
        terrain_grid.append([(x, y, tm.terrain_height(x, y, settings)) for y in ys])
        water_z = tm.river_water_z(x, settings)
        water_grid.append([(x, ys[j], water_z) for j in range(shore_left, shore_right + 1)])

    # The two meshes share identical x/y coordinates at both shore edges.
    terrain_obj = _replace_obj(context, 'TB_BasicTerrain')
    _build_grid_mesh(terrain_obj, terrain_grid, _material('TB_Terrain_Debug', (0.42, 0.49, 0.31, 1.0), 0.9))
    terrain_obj['tb_type'] = 'terrain'
    terrain_obj['tb_generator'] = 'basic_terrain'
    terrain_obj['tb_map_width_m'] = settings.width
    terrain_obj['tb_map_length_m'] = settings.length
    terrain_obj['tb_town_focus_m'] = settings.focus_size
    terrain_obj['tb_resolution_mode'] = 'adaptive' if settings.world_space else 'legacy'
    terrain_obj['tb_generator_version'] = '0.4.3'

    river_obj = _replace_obj(context, 'TB_RiverWater')
    _build_grid_mesh(river_obj, water_grid, _material('TB_Water_Debug', (0.08, 0.29, 0.47, 1.0), 0.18))
    river_obj['tb_type'] = 'water'
    river_obj['tb_generator'] = 'basic_terrain'
    river_obj['tb_is_water_surface'] = True
    river_obj['tb_generator_version'] = '0.4.3'
    return terrain_obj, river_obj


class TB_TerrainSettings(PropertyGroup):
    width: FloatProperty(name="Map Width (m)", default=4000.0, min=20.0, max=100000.0)
    length: FloatProperty(name="Map Length (m)", default=4000.0, min=20.0, max=100000.0)
    resolution_x: IntProperty(name="X Segments", default=240, min=40, max=800)
    resolution_y: IntProperty(name="Y Segments", default=240, min=80, max=800)
    elevation: FloatProperty(name="Relief (m)", default=38.0, min=0.0, max=500.0)
    base_height: FloatProperty(name="Ground Datum (m)", default=18.0, min=-100.0, max=500.0)
    river_width: FloatProperty(name="River Width (m)", default=150.0, min=1.0, max=1000.0)
    river_depth: FloatProperty(name="Depth Below Water (m)", default=24.0, min=0.1, max=200.0)
    bank_width: FloatProperty(name="Bank Slope Width (m)", default=2.0, min=0.5, max=400.0)
    bank_rise: FloatProperty(name="Bank to Water Drop (m)", default=7.0, min=0.1, max=100.0)
    rolling_relief: FloatProperty(name="Local Rolling Relief (m)", default=11.0, min=0.0, max=100.0)
    border_hill_height: FloatProperty(name="Border Hills Height (m)", default=82.0, min=0.0, max=500.0)
    border_hill_band: FloatProperty(name="Border Hill Band (m)", default=850.0, min=1.0, max=1900.0)
    valley_width: FloatProperty(name="Valley Width (m)", default=220.0, min=0.0, max=1500.0)
    water_level: FloatProperty(name="Water Datum (m)", default=0.0)
    water_drop: FloatProperty(name="Water Drop / 4 km", default=4.0, min=0.0, max=100.0)
    focus_size: FloatProperty(name="Town Focus (m)", default=1000.0, min=100.0, max=10000.0)
    focus_density: FloatProperty(name="Focus Density", default=3.0, min=1.0, max=12.0)
    world_space: BoolProperty(name="Stable World-Space Terrain", default=True,
                             description="World-anchored terrain/river path; changing map bounds does not relocate landforms")
    seed: IntProperty(name="Seed", default=1, min=0)


class TB_OT_set_four_km_preset(Operator):
    bl_idname = 'tb.set_four_km_preset'
    bl_label = 'Apply 4 km Map Preset'
    bl_description = 'Configure 4 by 4 km map with 1 km high-detail town focus and central deep river'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        s = context.scene.tb_terrain_settings
        options = {
            'width': 4000.0, 'length': 4000.0,
            'resolution_x': 240, 'resolution_y': 240,
            'elevation': 38.0, 'base_height': 18.0,
            'river_width': 150.0, 'river_depth': 24.0,
            'bank_width': 2.0, 'bank_rise': 7.0,
            'rolling_relief': 11.0, 'border_hill_height': 82.0,
            'border_hill_band': 850.0,
            'valley_width': 220.0, 'water_level': 0.0,
            'water_drop': 4.0, 'focus_size': 1000.0,
            'focus_density': 3.0, 'world_space': True,
        }
        for key, value in options.items():
            setattr(s, key, value)
        self.report({'INFO'}, '4 km x 4 km terrain preset applied')
        return {'FINISHED'}


class TB_OT_create_basic_terrain(Operator):
    bl_idname = "tb.create_basic_terrain"
    bl_label = "Create Basic Terrain"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.tb_terrain_settings
        try:
            build_mesh(context, settings)
        except ValueError as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        return {'FINISHED'}


class TB_PT_terrain_panel(Panel):
    bl_label = "Town Builder"
    bl_idname = "TB_PT_terrain_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Town Builder'

    def draw(self, context):
        layout = self.layout
        s = context.scene.tb_terrain_settings
        layout.operator('tb.set_four_km_preset', icon='PRESET')
        box = layout.box()
        box.label(text='Map / Fidelity')
        box.prop(s, 'width')
        box.prop(s, 'length')
        box.prop(s, 'focus_size')
        box.prop(s, 'focus_density')
        box.prop(s, 'resolution_x')
        box.prop(s, 'resolution_y')
        box.prop(s, 'world_space')
        box = layout.box()
        box.label(text='Landforms')
        box.prop(s, 'base_height')
        box.prop(s, 'elevation')
        box.prop(s, 'rolling_relief')
        box.prop(s, 'border_hill_height')
        box.prop(s, 'border_hill_band')
        box.prop(s, 'seed')
        box = layout.box()
        box.label(text='River + Valley')
        box.prop(s, 'river_width')
        box.prop(s, 'river_depth')
        box.prop(s, 'bank_width')
        box.prop(s, 'bank_rise')
        box.prop(s, 'valley_width')
        box.prop(s, 'water_level')
        box.prop(s, 'water_drop')
        layout.operator('tb.create_basic_terrain', text='Generate Town Terrain + River', icon='MESH_GRID')


def terrain_add_menu(self, context):
    self.layout.operator("tb.create_basic_terrain", text="Town Terrain + River", icon='MESH_GRID')
