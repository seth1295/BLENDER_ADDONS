"""Shared terrain/river geometry functions used by Blender and preview rendering.

The river is geometric, not simulated hydraulics. All distances and widths are
world-space Blender units. No elevation threshold is used to select water.
"""
import math
import bisect


def fract(x):
    return x - math.floor(x)


def hash2(x, y, seed):
    return fract(math.sin(x * 127.1 + y * 311.7 + seed * 74.7) * 43758.5453123)


def smoothstep(t):
    t = min(1.0, max(0.0, t))
    return t * t * (3.0 - 2.0 * t)


def smootherstep(t):
    t = min(1.0, max(0.0, t))
    return t * t * t * (t * (t * 6.0 - 15.0) + 10.0)


def value_noise(x, y, seed):
    x0 = math.floor(x)
    y0 = math.floor(y)
    x1 = x0 + 1
    y1 = y0 + 1
    sx = smoothstep(x - x0)
    sy = smoothstep(y - y0)
    n00 = hash2(x0, y0, seed)
    n10 = hash2(x1, y0, seed)
    n01 = hash2(x0, y1, seed)
    n11 = hash2(x1, y1, seed)
    ix0 = n00 * (1.0 - sx) + n10 * sx
    ix1 = n01 * (1.0 - sx) + n11 * sx
    return ix0 * (1.0 - sy) + ix1 * sy


def fractal_noise(x, y, seed, octaves=4):
    value = 0.0
    amplitude = 1.0
    frequency = 1.0
    total = 0.0
    for i in range(octaves):
        value += value_noise(x * frequency, y * frequency, seed + i * 19) * amplitude
        total += amplitude
        amplitude *= 0.5
        frequency *= 2.0
    return value / total if total else 0.0


def border_hills(x, y, settings):
    """World-space peripheral hills; drainage corridor is cut later."""
    tx = smootherstep(max(0.0, min(1.0, (settings.border_hill_band-(2000.0-abs(x)))/settings.border_hill_band)))
    ty = smootherstep(max(0.0, min(1.0, (settings.border_hill_band-(2000.0-abs(y)))/settings.border_hill_band)))
    t = 1.0-(1.0-tx)*(1.0-ty)  # smooth union instead of a diagonal min() crease
    if t <= 0.0:
        return 0.0
    ridge = fractal_noise(x/530.0+12.5, y/530.0-8.25, settings.seed+509, 4)
    rolling = fractal_noise(x/230.0-3.8, y/230.0+5.2, settings.seed+613, 3)
    return (t**1.35)*settings.border_hill_height*(0.64+0.58*ridge+0.12*rolling)


def natural_height(x, y, settings):
    if getattr(settings, 'world_space', False):
        # World-space frequencies: expanding the map does not move local terrain.
        broad = (fractal_noise(x / 1400.0, y / 1400.0, settings.seed, 5) - 0.5) * settings.elevation
        detail = (fractal_noise(x / 360.0, y / 360.0, settings.seed + 131, 3) - 0.5) * settings.elevation * 0.22
        local = (fractal_noise(x/165.0, y/165.0, settings.seed+287, 4) - 0.5) * settings.rolling_relief
        return settings.base_height + broad + detail + local + border_hills(x,y,settings)
    # Coordinates normalized to [0,1] across terrain, as in v0.2.0.
    nx = x / settings.width + 0.5
    ny = y / settings.length
    broad = (fractal_noise(nx * 2.0, ny * 2.0, settings.seed, 4) - 0.5) * settings.elevation
    detail = (fractal_noise(nx * 7.0, ny * 7.0, settings.seed + 131, 3) - 0.5) * settings.elevation * 0.25
    return broad + detail


def river_center_y(x, settings):
    if getattr(settings, 'world_space', False):
        # Scale-anchored, continuous two-band meander; not hydraulic routing.
        return (210.0 * math.sin(x / 980.0 + 0.55)
                + 85.0 * math.sin(x / 440.0 - 0.35))
    nx = x / settings.width + 0.5
    return settings.length * (
        0.20 * math.sin(nx * math.pi * 1.2 + 0.4)
        + 0.10 * math.sin(nx * math.pi * 3.2)
    )


def river_dydx(x, settings):
    if getattr(settings, 'world_space', False):
        return ((210.0 / 980.0) * math.cos(x / 980.0 + 0.55)
                + (85.0 / 440.0) * math.cos(x / 440.0 - 0.35))
    nx = x / settings.width + 0.5
    return (settings.length / settings.width) * (
        0.20 * 1.2 * math.pi * math.cos(nx * math.pi * 1.2 + 0.4)
        + 0.10 * 3.2 * math.pi * math.cos(nx * math.pi * 3.2)
    )


def river_cross_scale(x, settings):
    # Normal-distance approximation for a river parameterized by X.
    return math.hypot(1.0, river_dydx(x, settings))


def river_half_y(x, settings):
    return 0.5 * settings.river_width * river_cross_scale(x, settings)


def river_water_z(x, settings):
    if getattr(settings, 'world_space', False):
        # Fixed water datum at world X=0. water_drop = drop in 4 km.
        return settings.water_level - (settings.water_drop / 4000.0) * x
    # Monotonic downstream fall, no elevation-mask inference.
    nx = x / settings.width + 0.5
    return settings.water_level - settings.water_drop * nx


def river_distance(x, y, settings):
    return abs(y - river_center_y(x, settings)) / river_cross_scale(x, settings)


def terrain_height(x, y, settings):
    natural = natural_height(x, y, settings)
    distance = river_distance(x, y, settings)
    half = 0.5 * settings.river_width
    water = river_water_z(x, settings)
    bank = settings.bank_width
    valley = getattr(settings, 'valley_width', 0.0) if getattr(settings, 'world_space', False) else 0.0
    fade = max(1.0, valley if valley > 0.0 else bank * 1.25)

    # Elliptical U-section: flat tangent at deepest centre, near-vertical
    # side walls at the waterline. Continuous shore; depth controlled by settings.river_depth.
    # Normalised distance keeps the true designed perpendicular river width.
    if distance <= half:
        t = min(1.0, distance / max(half, 0.001))
        if t >= 1.0 - 1.0e-9:
            return water  # exact geometric shoreline, despite floating point roundoff
        return water - settings.river_depth * math.sqrt(max(0.0, 1.0 - t*t))

    # Keep the v0.2.1 bank/transition when using the legacy setup.
    if valley <= 0.0:
        dry_height = max(natural, water + settings.bank_rise)
        if distance <= half + bank:
            t = (distance - half) / max(bank, 0.001)
            return water * (1.0 - smootherstep(t)) + dry_height * smootherstep(t)
        if distance <= half + bank + fade:
            t = (distance - half - bank) / fade
            return dry_height * (1.0 - smootherstep(t)) + natural * smootherstep(t)
        return natural

    # Wider alluvial valley: a gently rising lower bank blends into hills.
    # Land and water are still constructed from the same shoreline coordinates.
    floor = water + settings.bank_rise
    if distance <= half + bank:
        t = (distance - half) / max(bank, 0.001)
        return water + (floor - water) * smootherstep(t)
    if distance <= half + bank + valley:
        t = (distance - half - bank) / valley
        return floor * (1.0 - smootherstep(t)) + natural * smootherstep(t)
    return natural


def _terrain_y_rows_legacy(x, settings):
    """v0.2.1 Y grid, preserved for existing compact terrains."""
    n = max(32, settings.resolution_y)
    channel = max(12, round(n * 0.18))
    bank = max(4, round(n * 0.09))
    outer_left = (n - channel - 2 * bank) // 2
    outer_right = n - channel - 2 * bank - outer_left
    cy = river_center_y(x, settings)
    scale = river_cross_scale(x, settings)
    side = 0.5 * settings.river_width * scale
    bank_extent = settings.bank_width * scale
    bounds = [
        -settings.length * 0.5,
        cy - side - bank_extent,
        cy - side,
        cy + side,
        cy + side + bank_extent,
        settings.length * 0.5,
    ]
    segments = [outer_left, bank, channel, bank, outer_right]
    rows = [bounds[0]]
    for j, count in enumerate(segments):
        for k in range(1, count + 1):
            rows.append(bounds[j] + (bounds[j+1] - bounds[j]) * (k / count))
    assert len(rows) == n+1
    return rows, outer_left + bank, outer_left + bank + channel



def _interval(a, b, segments):
    """Segment endpoint generator (excluding a, including b)."""
    if segments < 1 or b <= a:
        raise ValueError('Invalid row interval or segment count')
    return [a + (b-a) * (i / segments) for i in range(1, segments+1)]


def terrain_x_coords(settings):
    """Nonuniform X grid: sample town focus more densely than remote terrain.

    Existing X coordinates are world-anchored when settings.world_space=True.
    """
    width = settings.width
    n = max(40, settings.resolution_x)
    if not getattr(settings, 'world_space', False):
        return [width * (i / n - 0.5) for i in range(n+1)]
    focus = min(settings.focus_size, 0.85 * width)
    factor = max(1.0, settings.focus_density)
    core = round(n * (focus*factor) / (focus*factor + width-focus))
    core = max(16, min(n-16, core))
    left = (n-core)//2
    right = n-core-left
    a, b, c, d = (-width/2.0, -focus/2.0, focus/2.0, width/2.0)
    return [a] + _interval(a,b,left) + _interval(b,c,core) + _interval(c,d,right)


def _weighted_interval(a, b, segments, settings, near_bank):
    """Monotone numerical inverse-CDF; denser near the town and river valley.

    Results are ALWAYS strictly ordered and include the precise segment end.
    """
    if segments < 1 or b <= a:
        raise ValueError('Invalid weighted row interval')
    steps = max(192, segments * 3)
    half_focus = max(1.0, settings.focus_size * 0.5)
    valley = max(35.0, getattr(settings, 'valley_width', 0.0))
    weights = []
    for j in range(steps+1):
        y = a + (b-a) * j/steps
        focus = math.exp(-((abs(y)/(half_focus*1.15))**4))
        bank = math.exp(-(((y-near_bank)/(valley*0.95))**2))
        weights.append(1.0 + (max(1.0, settings.focus_density)-1.0)*focus + 1.8*bank)
    cdf = [0.0]
    for j in range(steps):
        cdf.append(cdf[-1] + 0.5*(weights[j]+weights[j+1]))
    total = cdf[-1]
    coords = []
    for k in range(1, segments+1):
        target = total*k/segments
        j = min(steps-1, max(0, bisect.bisect_left(cdf,target)-1))
        fraction = (target-cdf[j])/max(1e-12, cdf[j+1]-cdf[j])
        coords.append(a + (b-a)*(j+fraction)/steps)
    coords[-1] = b
    return coords


def terrain_y_rows(x, settings):
    """Adaptive per-column Y coordinates with guaranteed shared shore vertices.

    Fixed row counts permit a single continuous quad strip. Bank, river and
    outside land are explicitly subdivided and cannot produce T-junctions.
    """
    if not getattr(settings, 'world_space', False):
        return _terrain_y_rows_legacy(x, settings)
    n = max(80, settings.resolution_y)
    channel = max(18, round(n*0.12))
    bank = max(8, round(n*0.052))
    remain = n-channel-2*bank
    left = remain//2
    right = remain-left
    cy = river_center_y(x, settings)
    scale = river_cross_scale(x, settings)
    shore = 0.5*settings.river_width*scale
    bank_extent = settings.bank_width*scale
    lo, a, b, c, d, hi = (
        -settings.length*.5,
        cy-shore-bank_extent,
        cy-shore,
        cy+shore,
        cy+shore+bank_extent,
        settings.length*.5,
    )
    if not lo < a < b < c < d < hi:
        raise ValueError('River/bank corridor does not fit within map extent')
    y = [lo]
    y += _weighted_interval(lo,a,left,settings,a)
    y += _interval(a,b,bank)
    y += _interval(b,c,channel)
    y += _interval(c,d,bank)
    y += _weighted_interval(d,hi,right,settings,d)
    if len(y) != n+1:
        raise AssertionError('Adaptive Y row count mismatch')
    return y, left+bank, left+bank+channel


def validate_corridor(settings):
    if settings.river_depth <= 0:
        return 'River depth must be greater than zero'
    for i in range(max(101, settings.resolution_x + 1)):
        x = settings.width * (i / max(100, settings.resolution_x) - 0.5)
        center = river_center_y(x, settings)
        margin = (0.5 * settings.river_width + settings.bank_width) * river_cross_scale(x, settings)
        if abs(center) + margin >= 0.5 * settings.length - 0.1:
            return 'River/banks extend beyond map edge. Increase map length or reduce river width.'
    return None
