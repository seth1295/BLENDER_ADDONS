# Town Builder v0.4.3 — Chunked Terrain Foundation

Self-contained Blender 4.2+ extension. Install **Town_Builder_v0.4.3.zip** through Blender's extension ZIP installer. No external Python packages or other Blender add-ons are required.

## World specification

- One fixed **4,000 × 4,000 metre** terrain (16 km²), centred at world origin.
- **16 × 16 = 256** independent **250 × 250 metre** root chunks.
- The existing river centreline and 4 km coordinate system are preserved; the river cross-section and terrain elevations have been deliberately updated.
- Separate river-water mesh per intersected chunk. The water mesh and terrain share geometric shoreline coordinates, never an elevation-threshold water colour mask.
- Chunks have stable names, identifiers, world coordinates and regeneration settings stored as Blender object custom properties.
- The existing monolithic terrain operator remains installed. Existing terrain and water objects are **hidden, not deleted**, when chunked terrain is built; clearing chunks restores them.

## v0.4.3 river cross-section change

- Cross-section matches the supplied red U-shaped reference: a rounded deep riverbed and steep exposed bank faces.
- River widens from 15 m to **150 m** and deepens to **24 m**, with the crest **7m above water**.
- The **2 m horizontal bank run** and **7 m bank rise** are retained.
- More wet and bank profile stations are always embedded into LOD0 chunk geometry, plus shared seam profiles.
- Other terrain equations, chunk IDs, controls and project rules remain unchanged.

## v0.4.3 landforms

- Border hill band: **850 m** from the edges; procedural ridge height parameter **82 m** blended smoothly across corners.
- Local terrain variation: existing large-scale terrain noise plus **11 m** fine rolling relief.
- River: **150 m width across the water**, **24 m depth below the water surface**, **7 m high bank crests** reached over a **2 m** lateral bank face; crest-to-bed elevation is **31 m**.
- Valley blend: **220 m** from each bank into the rest of the terrain.
- The riverbed now uses a **semi-elliptical U-profile** with explicit stations from shoreline to centreline. The 2 m near-vertical banks are separately tessellated, even at LOD0. Water continues as a separate physical mesh, not a height colour mask.
- All landform parameters are available in the Town Builder N-sidebar; no external generator or texture dependency.

## Resolution

| LOD | Segments per chunk edge | Approximate spacing |
| --- | ---: | ---: |
| 0 | 64 | 3.90625 m |
| 1 | 128 | 1.953125 m |
| 2 | 256 | 0.9765625 m |
| 3 | 512 | 0.48828125 m |
| 4 | 1024 | 0.244140625 m |

Quadtree subdivision of **one selected root chunk** is also supported:
- Depth 0: one 250 m tile
- Depth 1: four 125 m tiles
- Depth 2: sixteen 62.5 m tiles

Subdivision can be combined with LOD. Resolution refers to geometry sampling, **not the frequency/content of the current terrain noise**. More fine-scale erosion/noise and ambientCG material integration are future work.

**Seam architecture:** every chunk edge, regardless of LOD, conforms to a stable 3.90625 m world-aligned reference polyline with extra exact shoreline, bed-profile and bank-face crossing points. This ensures independently generated neighbours retain matching edge elevations. The price is that edges are represented at base-LOD fidelity, while interiors can be much denser. Shared boundaries and river shores are included in the regression tests.

## Blender workflow

1. Install and enable the ZIP in Blender 4.2 or later.
2. Open **3D View → N-sidebar → Town Builder → Chunked Terrain (v0.4)**.
3. **Generate / Update Region** builds the default 3 × 3 mixed-LOD region around grid cell (8, 8), LOD2 centre, LOD1 cardinal neighbours and LOD0 corner chunks.
4. **Generate Entire Map (LOD 0)** replaces existing chunked detail with all 256 base-resolution chunks.
5. Change **Focus Quadtree Depth** to 1 or 2, then update the region to refine the centre tile into child tiles.
6. Select a generated terrain or water chunk and click **Regenerate Selected Chunk** to update only that tile.
7. **Clear Chunked Terrain** removes only generated chunk objects and restores any previously hidden monolithic terrain.

There is a safety cap of approximately **2.5 million base-grid vertices per generation operation**. For extreme resolution, reduce the region size or quadtree depth. Existing chunks in other regions are preserved when a local region is rebuilt; changing map-wide settings does **not** automatically regenerate every untouched chunk. **Existing saved .blend scenes keep their old scene-level river parameters until you select **Apply 4 km Map Preset**. Apply the preset before regenerating the 150 m river.**

## Source modules

- `terrain_math.py` — shared world-space terrain, modified U-shaped riverbed and water equations
- `terrain.py` — existing terrain operators, panels and mesh builder, now with configurable landform settings
- `chunk_core.py` — pure Python chunk plans, quadtree subdivision, detailed cross-section band clipping and LOD stitching
- `chunks.py` — Blender scene integration, stable chunk objects, sidebar and generation operators
- `tests/validate_chunks.py` — reproducible tests independent of Blender or third-party packages
- `validation_report.json` — last test results, including mixed-LOD and quadtree geometry checks
- `terrain_overhead_preview.png` and `river_section_preview.png` — diagnostic overhead map renders from the same source height equations (not Blender renders)
- `RULES.md` — the two governing project rules, carried forward unchanged

## Important limitations

- Blender's `bpy` runtime was **not available** in the packaging environment. Python syntax, world geometry, shoreline, mixed LOD, quadtree, mesh coverage and Python syntax checks passed. Actual add-on registration and viewport behaviour must still be tested in Blender.
- This is **manual region-based LOD selection**, not yet camera-driven streaming or background chunk loading.
- Terrain geometry is generated procedurally. The preview uses diagnostic colours rather than ambientCG PBR materials. No final textures have been substituted.
- The river is mathematically constructed, not a hydraulic flow solver. The water and channel remain geometric, with a sampled riverbed centreline.
- Chunk water meshes and terrain are separate objects. No physics, road network, buildings, or atmosphere are included.

## 150 m river and future bridge corridor (current update)

The river has an actual **150 m water-surface span** measured approximately perpendicular to the
meandering centreline (not a painted band). At the centreline the submerged rounded bed is
**24 m below the waterline**; bank crests remain **7 m above water**, giving **31 m** from crest
to deepest bed. Dry bank rise remains 2 m horizontally on either side; valley transition remains
220 m per side. All 33 wet cross-section stations are geometric, included in coarse LOD meshes
and chunk seam profiles. The river and water surfaces are created from the same shoreline boundaries.

The 150 m river width is the future bridge's **minimum water crossing**, not its finished span.
Actual bridge length will also depend on bank setbacks, foundations and chosen approach grade;
no bridge or abutment geometry has been added yet.

## v0.4.4 — Primary road/district planning

New self-contained `town_layout_blender.py` and `layout_generator.py` modules plus
`town_layout.json` and `TOWN_LAYOUT_DESIGN.md`.

1. Install the single `Town_Builder_v0.4.4.zip` extension in Blender as normal.
2. In the **Town Builder** N-sidebar, choose **Apply 4 km Map Preset** (if not
   already set), then generate the full 4 km terrain or the working chunk region.
3. In **Town Road / District Planning**, choose **Generate / Update Town Plan**.
4. Six coloured planning districts, 14 terrain-following road segments and an
   **unbuilt** dashed bridge reservation appear in a separate
   `TB_Planned_Town` collection. Re-run to regenerate just the planning layer.
5. **Clear Town Planning Overlay** removes only this layer; the terrain chunks
   and their river water objects are left untouched.

The plan is generated deterministically inside the add-on from bundled source,
with the supplied JSON as a regression reference. No manual road drawing is
required. Road ribbons are preliminary terrain-draped surfaces, **not** a
physically graded road system. The crossing and approaches are reserved only.
