# Town Layout v0.1.0 — Design & Validation

**Terrain baseline:** Town Builder v0.4.3, exactly 4,000 × 4,000 metres.
The v0.4.3 river width (150 m), depth (24 m), bank rise (7 m), valley, hill
and chunk geometry functions are unchanged. This is a planning-stage overlay.

## Road network and bridge

BR-01 was selected by evaluating candidate perpendicular crossings within 400 m
of the map centre on 25 m spacing. Evaluation includes river curvature,
terrain-elevation difference between both approach corridors, approach
longitudinal grades sampled at six offsets per bank, and distance from the
central activity area. Selection is deterministic and reproducible.

- **Chosen river centre:** X **200.00 m**, Y **152.64029 m**.
- **River width:** 150 m, measured approximately perpendicular to flow.
- **Reserved abutments:** south (229.27537, 68.59297), north (170.72463, 236.68762).
- **Reserved abutment span:** 178 m, including 12 m extra past each side's 2 m bank face.
- **Sampled approach grade near the crossing:** 10.65% maximum on source terrain.
- **No bridge deck, structural engineering or terrain grading has been performed.**
  A dashed reservation marker is rendered in the viewer and Blender; it has
  no gameplay collision or structural geometry.

The road graph contains two bank-parallel main-street spines, two bridge
approaches and four feeder connectors. Main streets are split at the feeder
junctions and the bridge junctions to retain explicit graph nodes. The resulting
**14 segment** geometry is included in the same layout data used by both apps.
The reservation is a *future edge* in the graph; there is no current physical
connection between the two banks until a bridge is actually constructed.

## Districts

North bank:

1. Old Quarter — residential, west
2. Civic Centre — mixed civic/commercial, central
3. North Works — small industry and trades, east

South bank:

4. The Grove — established residential, west
5. Southbank — residential plus local services, central
6. East Fields — agricultural / low density, east

The boundaries are procedural curves in offsets relative to the existing
meandering river centreline and exclude the river's water corridor. Shapes are
irregular and terrain-draped; no cadastral lots or property parcels exist yet.
Land outside the six zones is left unassigned for countryside and future
expansion. Zone sizes are planning footprints, not fixed population counts.

## Generator and data ownership

`layout_generator.py` is bundled with the Blender add-on. It deterministically
reconstructs `town_layout.json` from the terrain mathematics using Python
standard-library functionality only; the stored JSON is an exact audited
snapshot. The Three.js viewer consumes that JSON. Both render the road and zone
geometry procedurally from shared geographic positions. No extra installed
Blender add-ons, external GIS programs, or asset downloads are required.

The road and district materials in this first planning-stage pass are **debug
colours only**, not production PBR materials. Rule #2 still specifies ambientCG.

## Remaining civil engineering work

- Survey/refine the ~10.7% approach grade, horizontal alignment and sightlines;
  road grading, cut/fill, retaining structures and drainage are not yet designed.
- Verify district sites at parcel scale before allocating building footprints.
- Design the actual bridge span, deck elevation, foundations, clearances and
  structural load case in a separate milestone.
- Finalize collector/secondary street network after parcels and access points.
- Replace planning road materials with suitable real ambientCG surfaces.

## Acceptance checks

- 4 km terrain and 150 m river unchanged.
- Exactly 6 districts, 14 road segments and 1 unbuilt bridge reservation.
- No road centrelines or district boundaries intersect the water surface.
- Road endpoints join the labelled graph nodes; all nodes become connected
  when and only when the reserved bridge edge is included.
- Cross-section width and abutment spacing are physically distinct.
- Existing LOD streaming, fly/walk and P-to-release remain unchanged.
- Blender runtime/GPU visual validation remains to be performed in Blender;
  Python and Node source-level checks are reported separately.
