"""Blender scene objects and per-frame deforming steel curtain for Shed Roller Door."""

import math

import bpy

from .geometry import DoorSpec, coil_collision_margin, path_point, roller_state, sample_rings
from . import materials

# Transient runtime optimisation; never stored in the blend.
_last_states = {}
_in_update = False


def is_controller(obj):
    return bool(obj and obj.get('rd_controller', False))


def get_controller(obj):
    while obj is not None:
        if is_controller(obj):
            return obj
        obj = obj.parent
    return None


def _opening_fraction(props):
    """Convert the public 0–100% property to the geometry core's 0–1 value."""
    return max(0.0, min(1.0, float(props.open_percentage) / 100.0))


def make_spec(props):
    return DoorSpec(
        width=props.width,
        height=props.height,
        profile_pitch=props.rib_pitch,
        rib_width=min(props.rib_width, props.rib_pitch * 0.85),
        rib_depth=props.rib_depth,
        sheet_thickness=props.sheet_thickness,
        core_radius=props.core_radius,
        coil_layer_pitch=max(props.coil_layer_pitch, props.rib_depth + props.sheet_thickness + 0.002),
        seed_turns=props.seed_turns,
        headroom=props.headroom,
        opening_clearance=props.opening_clearance,
        transition_length=props.transition_length,
        samples_per_pitch=int(props.quality),
        uv_metres_per_tile=props.texture_scale,
    )


def _link_child(root, name, data, tag):
    obj = bpy.data.objects.new(name, data)
    # Linking to the same collection preserves typical hierarchy operations.
    col = root.users_collection[0] if root.users_collection else bpy.context.scene.collection
    col.objects.link(obj)
    obj.parent = root
    obj['rd_component'] = tag
    return obj


def _mesh_obj(root, name, tag, verts, faces, material, bevel=0.0):
    mesh = bpy.data.meshes.new(name + ' mesh')
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    if material is not None:
        mesh.materials.append(material)
    ob = _link_child(root, name, mesh, tag)
    if bevel:
        mod = ob.modifiers.new('Soft metal edges', 'BEVEL')
        mod.width = bevel
        mod.segments = 2
        if hasattr(mod, 'affect'):
            mod.affect = 'EDGES'
        normal = ob.modifiers.new('Weighted surface normals', 'WEIGHTED_NORMAL')
        normal.keep_sharp = True
    return ob


def _box(root, name, tag, centre, dims, material, bevel=0):
    cx, cy, cz = centre
    hx, hy, hz = (v / 2 for v in dims)
    verts = [
        (cx-hx, cy-hy, cz-hz), (cx+hx, cy-hy, cz-hz),
        (cx+hx, cy+hy, cz-hz), (cx-hx, cy+hy, cz-hz),
        (cx-hx, cy-hy, cz+hz), (cx+hx, cy-hy, cz+hz),
        (cx+hx, cy+hy, cz+hz), (cx-hx, cy+hy, cz+hz),
    ]
    faces = [
        (0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4),
        (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7),
    ]
    return _mesh_obj(root, name, tag, verts, faces, material, bevel=bevel)


def _cylinder(root, name, tag, center, radius, length, mat, segments=36, bevel=0.0):
    """Closed cylindrical object aligned with the horizontal X axle."""
    cx, cy, cz = center
    verts = []
    for x in (-length / 2, length / 2):
        for i in range(segments):
            a = 2 * math.pi * i / segments
            verts.append((x, radius * math.cos(a), radius * math.sin(a)))
    faces = []
    faces.append(tuple(range(segments - 1, -1, -1)))
    faces.append(tuple(range(segments, 2 * segments)))
    for i in range(segments):
        j = (i + 1) % segments
        faces.append((i, j, segments + j, segments + i))
    ob = _mesh_obj(root, name, tag, verts, faces, mat, bevel=bevel)
    ob.location = (cx, cy, cz)
    for poly in ob.data.polygons[2:]:
        poly.use_smooth = True
    return ob


def _curve_tube(root, name, tag, coords, radius, mat):
    curve = bpy.data.curves.new(name + ' curve', 'CURVE')
    curve.dimensions = '3D'
    curve.resolution_u = 12
    curve.bevel_depth = radius
    curve.bevel_resolution = 3
    spline = curve.splines.new('POLY')
    spline.points.add(len(coords) - 1)
    for p, pos in zip(spline.points, coords):
        p.co = (pos[0], pos[1], pos[2], 1.0)
    curve.materials.append(mat)
    return _link_child(root, name, curve, tag)


def _spring(root, name, x0, x1, axis_y, axis_z, mat, phase=0):
    turns = 11
    steps = turns * 20
    coords = []
    for i in range(steps + 1):
        u = i / steps
        a = phase + math.tau * turns * u
        radius = 0.047
        coords.append((x0 + (x1 - x0) * u,
                       axis_y + radius * math.cos(a),
                       axis_z + radius * math.sin(a)))
    return _curve_tube(root, name, 'spring', coords, 0.005, mat)


def _hood(root, spec, state, mat):
    # Rolled steel cowl: upper ~245-degree arc, bottom/front left open.
    radius = state['full_outer_radius'] + spec.rib_depth + 0.045
    x0, x1 = -spec.width / 2 - 0.065, spec.width / 2 + 0.065
    theta0, theta1 = -0.18, math.radians(235)
    sections = 48
    verts = []
    faces = []
    for x in (x0, x1):
        for i in range(sections + 1):
            t = theta0 + (theta1 - theta0) * i / sections
            verts.append((x, state['drum_y'] + radius * math.cos(t),
                             state['drum_z'] + radius * math.sin(t)))
    for i in range(sections):
        faces.append((i, i + 1, sections + 2 + i, sections + 1 + i))
    return _mesh_obj(root, 'Roller Hood - Curved Galvanised', 'hood', verts, faces, mat)


def _mesh_part_map(root):
    return {ob.get('rd_component'): ob for ob in root.children if ob.get('rd_component')}


def _remove_hardware(root):
    for ob in list(root.children):
        if ob.get('rd_component') in ('curtain', 'wind_locks'):
            continue
        if not ob.get('rd_component'):
            continue
        datablock = ob.data
        bpy.data.objects.remove(ob, do_unlink=True)
        if datablock is not None and datablock.users == 0:
            if isinstance(datablock, bpy.types.Mesh):
                bpy.data.meshes.remove(datablock)
            elif isinstance(datablock, bpy.types.Curve):
                bpy.data.curves.remove(datablock)


def _static_hardware(root, spec, state):
    mats = materials.shared_hardware_materials()
    steel, dark, black = mats['steel'], mats['dark'], mats['black']
    half_w = spec.width / 2
    y_axis, z_axis = state['drum_y'], state['drum_z']

    # Fabricated C-shaped side guides. Curtain enters between front and rear lips.
    guide_height = spec.height + 0.11
    for side, sign in (('Left', -1), ('Right', 1)):
        x_out = sign * (half_w + 0.026)
        outer = _box(root, f'{side} Guide - Back Wall', f'guide_wall_{side}',
                     (x_out, 0, guide_height / 2),
                     (0.026, 0.083, guide_height), steel, 0.002)
        _box(root, f'{side} Guide - Front Lip', f'guide_front_{side}',
             (sign * (half_w - 0.005), 0.036, guide_height / 2),
             (0.054, 0.008, guide_height), steel, 0.001)
        _box(root, f'{side} Guide - Rear Lip', f'guide_rear_{side}',
             (sign * (half_w - 0.005), -0.038, guide_height / 2),
             (0.054, 0.008, guide_height), steel, 0.001)
        # Visible dark polymer wear liner on the guide mouth.
        _box(root, f'{side} Guide - Wear Liner', f'guide_liner_{side}',
             (sign * (half_w + 0.010), 0, guide_height / 2),
             (0.006, 0.055, guide_height), black, 0)
        bx = sign * (half_w + 0.105)
        _box(root, f'{side} Drum Bracket', f'bracket_{side}',
             (bx, y_axis - 0.055, z_axis), (0.014, 0.19, 0.23), steel, 0.005)
        _box(root, f'{side} Bracket Reinforcement', f'bracket_arm_{side}',
             (sign * (half_w + 0.062), y_axis - 0.12, z_axis),
             (0.10, 0.017, 0.07), dark, 0.003)
        _cylinder(root, f'{side} Axle Bearing', f'bearing_{side}',
                  (sign * (half_w + 0.110), y_axis, z_axis),
                  0.050, 0.025, dark, segments=32, bevel=0.002)
        _cylinder(root, f'{side} Spring Drum Wheel', f'drum_{side}',
                  (sign * (half_w - 0.075), y_axis, z_axis),
                  spec.core_radius, 0.049, steel, segments=48, bevel=0.002)
        _cylinder(root, f'{side} Drum Wheel Hub', f'drumhub_{side}',
                  (sign * (half_w - 0.075), y_axis, z_axis),
                  0.058, 0.059, dark, segments=36, bevel=0.001)
        # Spring model is visual/kinematic, not a structural solver.
        spring_inner = sign * (half_w - 0.17)
        spring_outer = sign * (half_w - 0.42)
        _spring(root, f'{side} Torsion Spring', spring_inner, spring_outer,
                y_axis, z_axis, dark, phase=math.pi / 3)
        for n in (-1, 1):
            _cylinder(root, f'{side} Mounting Bolt {n}', f'bolt_{side}_{n}',
                      (bx + sign * 0.009, y_axis - 0.095, z_axis + n * 0.082),
                      0.011, 0.015, dark, segments=12)

    # Winding shaft and drive hub are separate from fixed support brackets.
    _cylinder(root, 'Main Winding Axle', 'axle', (0, y_axis, z_axis),
              0.024, spec.width + 0.33, steel, segments=36, bevel=0.001)

    # Bottom rail and rubber floor seal move with the curtain; no scaled geometry.
    _box(root, 'Reinforced Bottom Rail', 'bottom_rail',
         (0, 0.012, 0.055), (spec.width + 0.020, 0.050, 0.065),
         steel, 0.004)
    _box(root, 'Bottom Weather Seal', 'weather_seal',
         (0, 0.005, 0.012), (spec.width + 0.025, 0.041, 0.019),
         black, 0.006)
    _box(root, 'Bottom Rail Hand Grip', 'bottom_handle',
         (0, 0.053, 0.066), (0.19, 0.043, 0.026),
         dark, 0.007)

    if root.roller_door.include_motor:
        _cylinder(root, 'Motor Casing', 'motor',
                  (half_w + 0.26, y_axis, z_axis),
                  0.072, 0.225, dark, segments=40, bevel=0.005)
        _box(root, 'Motor Mounting Saddle', 'motor_mount',
             (half_w + 0.255, y_axis - 0.110, z_axis - 0.048),
             (0.24, 0.025, 0.09), steel, 0.004)
        _cylinder(root, 'Motor Drive Coupler', 'motor_coupler',
                  (half_w + 0.141, y_axis, z_axis),
                  0.039, 0.065, steel, segments=32)
    if root.roller_door.include_hood:
        _hood(root, spec, state, materials.curtain_material(root))


def _curtain_object(root):
    for child in root.children:
        if child.get('rd_component') == 'curtain':
            return child
    mesh = bpy.data.meshes.new('Corrugated Continuous Curtain Mesh')
    return _link_child(root, 'Continuous Corrugated Steel Curtain', mesh, 'curtain')


def _windlock_object(root):
    for child in root.children:
        if child.get('rd_component') == 'wind_locks':
            return child
    mesh = bpy.data.meshes.new('Wind Lock Tabs Mesh')
    return _link_child(root, 'Curtain Edge Wind-Lock Tabs', mesh, 'wind_locks')


def _windlocks_mesh(spec, st):
    """Retention tabs fixed to material stations (move into coil with curtain)."""
    verts, faces = [], []
    count = int(st['total_length'] / (spec.profile_pitch * 3))
    for i in range(1, count + 1):
        u = i * spec.profile_pitch * 3
        y, z, ny, nz = path_point(spec, st, u)
        ty, tz = -nz, ny
        for sign in (-1, 1):
            # Small steel saddle, protruding past curtain edge by ~20mm.
            cx = sign * (spec.width * 0.5 + 0.012)
            off = len(verts)
            for dx, dl, dn in (
                (-0.018, -0.016, -0.008), (+0.018, -0.016, -0.008),
                (+0.018, +0.016, -0.008), (-0.018, +0.016, -0.008),
                (-0.018, -0.016, +0.008), (+0.018, -0.016, +0.008),
                (+0.018, +0.016, +0.008), (-0.018, +0.016, +0.008),
            ):
                verts.append((cx+dx, y + dl*ty + dn*ny, z + dl*tz + dn*nz))
            faces.extend(tuple(off + j for j in face) for face in (
                (0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4),
                (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7),
            ))
    return verts, faces


def _reset_mesh(mesh, verts, faces):
    mesh.clear_geometry()
    mesh.from_pydata(verts, [], faces)
    mesh.update()


def _assign_curtain_materials(root, mesh):
    cloth = materials.curtain_material(root)
    edges = materials.shared_hardware_materials()['dark']
    mesh.materials.clear()
    mesh.materials.append(cloth)
    mesh.materials.append(edges)


def rebuild_motion(root, force=False):
    global _in_update
    if not is_controller(root) or _in_update:
        return
    p = root.roller_door
    if not p.enabled:
        return
    opening = round(_opening_fraction(p), 7)
    cache_key = root.as_pointer()
    if not force and _last_states.get(cache_key) == opening:
        return
    _in_update = True
    try:
        spec = make_spec(p)
        verts, faces, mat_indices, uv, st = sample_rings(spec, opening)
        curtain = _curtain_object(root)
        mesh = curtain.data
        _reset_mesh(mesh, verts, faces)
        if len(mesh.materials) != 2:
            _assign_curtain_materials(root, mesh)
        for polygon, mat_index in zip(mesh.polygons, mat_indices):
            polygon.material_index = mat_index
            polygon.use_smooth = mat_index == 0
        uv_layer = mesh.uv_layers.get('Arc-length UV') or mesh.uv_layers.new(name='Arc-length UV')
        uv_flat = []
        for polygon in mesh.polygons:
            for li in polygon.loop_indices:
                texcoord = uv[mesh.loops[li].vertex_index]
                uv_flat.extend(texcoord)
        if hasattr(uv_layer, 'uv'):
            # Modern Blender 4.x/5.x attribute API, faster than one-loop-at-a-time.
            uv_layer.uv.foreach_set('vector', uv_flat)
        else:
            for li, texcoord in enumerate(zip(uv_flat[::2], uv_flat[1::2])):
                uv_layer.data[li].uv = texcoord
        parts = _mesh_part_map(root)
        for tag in ('bottom_rail', 'weather_seal', 'bottom_handle'):
            if tag in parts:
                parts[tag].location.z = st['rise']
        # Only the winding shaft, drum wheels and their hubs rotate.
        closed_angle = roller_state(spec, 0.0)['drum_angle']
        turn = st['drum_angle'] - closed_angle
        for tag in ('axle', 'drum_Left', 'drum_Right', 'drumhub_Left', 'drumhub_Right', 'motor_coupler'):
            if tag in parts:
                ob = parts[tag]
                # Cylinders have local origins at the axle centre.
                ob.rotation_euler.x = turn
        if p.include_wind_locks:
            ob = _windlock_object(root)
            wverts, wfaces = _windlocks_mesh(spec, st)
            _reset_mesh(ob.data, wverts, wfaces)
            if len(ob.data.materials) == 0:
                ob.data.materials.append(materials.shared_hardware_materials()['steel'])
            ob.hide_viewport = False
            ob.hide_render = False
        else:
            ob = parts.get('wind_locks')
            if ob:
                ob.hide_viewport = True
                ob.hide_render = True
        # The witness marker makes rotation visible on symmetric hardware.
        marker = parts.get('winding_marker')
        if marker:
            radius = spec.core_radius + 0.010
            marker.location.y = st['drum_y'] + radius * math.cos(turn)
            marker.location.z = st['drum_z'] + radius * math.sin(turn)
        _last_states[cache_key] = opening
    finally:
        _in_update = False


def rebuild_complete(root):
    """Called when dimensions, mechanics or static options change."""
    global _in_update
    if not is_controller(root) or _in_update:
        return
    _in_update = True
    try:
        spec = make_spec(root.roller_door)
        state = roller_state(spec, _opening_fraction(root.roller_door))
        _remove_hardware(root)
        _static_hardware(root, spec, state)
        # Witness pin indicates real angular motion of the otherwise rotationally
        # symmetric axle, including during keyframed scrubbing.
        marker = _cylinder(root, 'Winding Axle Angular Witness', 'winding_marker',
                           (spec.width * .5 - .075, state['drum_y'] + spec.core_radius + .010,
                            state['drum_z']), 0.007, 0.032,
                           materials.shared_hardware_materials()['black'], segments=12)
        # Allow subsequent motion rebuild and remember any existing manual mat.
        _last_states.pop(root.as_pointer(), None)
        curtain = _curtain_object(root)
        _assign_curtain_materials(root, curtain.data)
    finally:
        _in_update = False
    rebuild_motion(root, force=True)


def update_material_only(root):
    if not is_controller(root):
        return
    curtain = _curtain_object(root)
    _assign_curtain_materials(root, curtain.data)
    if root.roller_door.include_hood:
        for ob in root.children:
            if ob.get('rd_component') == 'hood' and ob.data:
                ob.data.materials.clear()
                ob.data.materials.append(materials.curtain_material(root))


def forget_runtime_cache():
    _last_states.clear()
