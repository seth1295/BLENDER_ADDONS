"""Safe ambientCG archive download/extraction; no Blender dependency.

Only six explicitly curated CC0 assets can be installed. No asset files are
bundled with the add-on: downloads happen on demand from ambientCG.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import re
import shutil
import tempfile
from urllib.request import Request, urlopen
import zipfile

ASSETS = (
    ('Metal026', 'Metal026 | Rusted steel'),
    ('Metal062C', 'Metal062C | Dirty metal'),
    ('Metal050C', 'Metal050C | Scratched aluminium'),
    ('Metal059C', 'Metal059C | Worn metal'),
    ('Metal020', 'Metal020 | Weathered rusty steel'),
    ('Rust002', 'Rust002 | Heavy rust'),
)
ASSET_IDS = frozenset(a[0] for a in ASSETS)
MAP_TYPES = (
    'Color', 'Roughness', 'Metalness', 'NormalGL',
    'Displacement', 'AmbientOcclusion',
)
MAX_ARCHIVE_BYTES = 180 * 1024 * 1024
MAX_MAP_BYTES = 64 * 1024 * 1024


def download_url(asset_id: str, resolution: str = '1K') -> str:
    if asset_id not in ASSET_IDS:
        raise ValueError('Unsupported ambientCG asset')
    if resolution not in ('1K', '2K'):
        raise ValueError('Only 1K and 2K are supported')
    return f'https://ambientcg.com/get?file={asset_id}_{resolution}-JPG.zip'


def asset_from_archive_name(filename: str) -> str:
    name = Path(filename).name
    for ident in ASSET_IDS:
        if re.match(rf'^{re.escape(ident)}_(?:1K|2K)-(?:JPG|PNG)\.zip$', name, re.I):
            return ident
    raise ValueError('Choose a 1K or 2K ambientCG ZIP for one of the six supported materials')


def classify_map(filename: str) -> str | None:
    # New and old ambientCG names (Metal020_2K-JPG_NormalGL.jpg etc.)
    name = Path(filename).name
    if not name.lower().endswith(('.jpg', '.jpeg', '.png', '.tif', '.tiff', '.exr')):
        return None
    stem = Path(name).stem.lower()
    for kind in MAP_TYPES:
        if stem.endswith('_' + kind.lower()):
            return kind
    # Skip NormalDX: directX normal maps have inverted Y and cannot be used as GL.
    return None


def installed_maps(root: str | Path, asset_id: str, preferred_resolution: str = "2K") -> dict[str, str]:
    if asset_id not in ASSET_IDS:
        return {}
    root = Path(root) / asset_id
    preferred = '1K' if preferred_resolution == '1K' else '2K'
    other = '2K' if preferred == '1K' else '1K'
    for dirname in (preferred+'-JPG', preferred+'-PNG', other+'-JPG', other+'-PNG'):
        folder = root / dirname
        manifest = folder / 'manifest.json'
        if manifest.is_file():
            try:
                data = json.loads(manifest.read_text(encoding='utf8'))
                if data.get('asset_id') != asset_id:
                    continue
                maps = {k: str(folder / v) for k, v in data.get('maps', {}).items()
                        if k in MAP_TYPES and (folder / v).is_file()
                        and Path(v).name == v}
                if 'Color' in maps:
                    return maps
            except (OSError, ValueError, TypeError):
                continue
    return {}


def install_archive(archive_path: str | Path, root: str | Path,
                    asset_id: str, resolution: str = '1K') -> dict[str, str]:
    """Extract recognized texture images only; reject traversal/zip bombs.

    Existing successful installation is kept until a complete replacement is
    available. The extracted images are each under 64 MiB uncompressed.
    """
    if asset_id not in ASSET_IDS or resolution not in ('1K', '2K'):
        raise ValueError('Unsupported asset or resolution')
    archive_path = Path(archive_path)
    if archive_path.stat().st_size > MAX_ARCHIVE_BYTES:
        raise ValueError('ZIP exceeds the download size limit')
    archive_type = 'PNG' if re.search(r'_[12]K-PNG\.zip$', archive_path.name, re.I) else 'JPG'
    base = Path(root) / asset_id
    base.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix='.ci_staging_', dir=base))
    try:
        found = {}
        with zipfile.ZipFile(archive_path) as zf:
            for info in zf.infolist():
                kind = classify_map(info.filename)
                if not kind or kind in found or info.is_dir():
                    continue
                # Avoid taking entries from nested paths / unexpected products.
                filename = Path(info.filename).name
                if not filename.startswith(asset_id + '_'):
                    continue
                if info.file_size > MAX_MAP_BYTES:
                    raise ValueError(f'{kind} texture is unexpectedly large')
                outname = kind + Path(filename).suffix.lower()
                dest = staging / outname
                written = 0
                with zf.open(info) as source, dest.open('wb') as output:
                    while True:
                        chunk = source.read(1024 * 1024)
                        if not chunk:
                            break
                        written += len(chunk)
                        if written > MAX_MAP_BYTES:
                            raise ValueError('Expanded map exceeds the size limit')
                        output.write(chunk)
                found[kind] = outname
        if 'Color' not in found:
            raise ValueError('Archive did not contain an ambientCG Color texture')
        manifest = {
            'asset_id': asset_id, 'resolution': resolution,
            'source': f'https://ambientcg.com/view?id={asset_id}',
            'license': 'CC0', 'maps': found,
        }
        (staging / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf8')
        destfolder = base / (resolution + '-' + archive_type)
        # Remove only our previously generated map cache, if any.
        if destfolder.is_dir():
            shutil.rmtree(destfolder)
        staging.rename(destfolder)
        return {k: str(destfolder / v) for k, v in found.items()}
    finally:
        if staging.is_dir():
            shutil.rmtree(staging)


def download_and_install(asset_id: str, resolution: str, root: str | Path):
    """Blocking download (runs on operator click; no Blender API on threads)."""
    url = download_url(asset_id, resolution)
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix='ambientcg_', suffix='.zip', dir=root)
    try:
        with os.fdopen(fd, 'wb') as out:
            request = Request(url, headers={'User-Agent': 'CorrugatedIronGenerator/1.0 (Blender)'})
            with urlopen(request, timeout=90) as response:
                length = response.headers.get('Content-Length')
                if length and int(length) > MAX_ARCHIVE_BYTES:
                    raise ValueError('Archive exceeds the download limit')
                downloaded = 0
                while True:
                    chunk = response.read(1024 * 1024)
                    if not chunk:
                        break
                    downloaded += len(chunk)
                    if downloaded > MAX_ARCHIVE_BYTES:
                        raise ValueError('Archive exceeds the download limit')
                    out.write(chunk)
        return download_url(asset_id, resolution), install_archive(temp, root, asset_id, resolution)
    finally:
        if os.path.isfile(temp):
            os.unlink(temp)
