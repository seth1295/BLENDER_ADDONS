"""Blender-independent chunk planner and crack-resistant river/terrain geometry.

This module requires only Python's standard library. Coordinates are always
world-space metres. Tile data is independent of the Blender mesh display.

Town Builder v0.4.3 extends the same world-space terrain with new landforms.
"""

from dataclasses import dataclass
from bisect import bisect_right
import math
from . import terrain_math as tm

WORLD_SIZE_M = 4000.0
ROOT_TILE_M = 250.0
ROOT_COUNT = 16
BASE_SEGMENTS = 64
EPS = 1.0e-8

# Curvature-adaptive explicit river cross-section stations. These are
# independent of the chunk LOD, so coarse meshes still reproduce the rounded
# bed and the 7 m bank face rather than turning them into a sharp V.
BED_STATIONS = (-1.0, -.995, -.98, -.95, -.91, -.86, -.80, -.72,
                -.64, -.56, -.48, -.40, -.32, -.24, -.16, -.08,
                 0.0,  .08,  .16,  .24,  .32,  .40,  .48,  .56,
                 .64,  .72,  .80,  .86,  .91,  .95,  .98,  .995, 1.0)
BANK_STATIONS = (0.15, 0.5, 1.0)


def _cross_offsets(settings):
    half = settings.river_width*0.5
    bank = settings.bank_width
    return sorted(set([half*k for k in BED_STATIONS] +
                      [side*(half+bank*k) for side in (-1,1)
                       for k in BANK_STATIONS]))


def _cross_y(x, offset, settings):
    return tm.river_center_y(x, settings) + offset*tm.river_cross_scale(x, settings)


def _crossings_at_y(y, xa, xb, settings, offsets):
    # Conservative early-out derived from the actual corridor width, slope,
    # and variation of the river axis over this tile's X extent.
    mid=(xa+xb)*0.5
    local_shift=0.42*(xb-xa)*0.5
    max_normal=max(tm.river_cross_scale(x,settings) for x in (xa,mid,xb))
    reach=max(abs(offset) for offset in offsets)*max_normal+local_shift+2.0
    if abs(y-tm.river_center_y(mid,settings))>reach:
        return []
    out=[]
    for offset in offsets:
        out.extend(_root_find(lambda x:_cross_y(x,offset,settings)-y,xa,xb))
    return out


@dataclass(frozen=True)
class Tile:
    depth: int
    ix: int
    iy: int
    lod: int = 0

    @property
    def key(self):
        return f"d{self.depth}_x{self.ix:02d}_y{self.iy:02d}"

    @property
    def root_xy(self):
        shift = 1 << self.depth
        return self.ix // shift, self.iy // shift

    @property
    def size(self):
        return ROOT_TILE_M / (1 << self.depth)

    @property
    def segments(self):
        return BASE_SEGMENTS * (1 << self.lod)

    @property
    def spacing(self):
        return self.size / self.segments

    @property
    def bounds(self):
        size = self.size
        x0 = -WORLD_SIZE_M * 0.5 + self.ix * size
        y0 = -WORLD_SIZE_M * 0.5 + self.iy * size
        return x0, y0, x0 + size, y0 + size


@dataclass
class ChunkMesh:
    tile: Tile
    vertices: list
    faces: list
    water_vertices: list
    water_faces: list
    shoreline_vertices: int
    split_cells: int

    @property
    def terrain_faces(self):
        return len(self.faces)

    @property
    def water_faces_count(self):
        return len(self.water_faces)


def descendants(depth, ix, iy, lod):
    if depth == 0:
        return [Tile(depth, ix, iy, lod)]
    return [Tile(depth, ix * (1 << depth) + dx,
                 iy * (1 << depth) + dy, lod)
            for dy in range(1 << depth) for dx in range(1 << depth)]


def build_plan(cx=8, cy=8, radius=1, far_lod=0,
               neighbor_lod=1, focus_lod=2, focus_depth=0, region=True):
    """All 256 root cells have exactly one owner (possibly quadtree children).

    The plan includes tiles outside a requested 3x3 generation region so seam
    heights do not change when further chunks are built later.
    """
    if not (0 <= cx < ROOT_COUNT and 0 <= cy < ROOT_COUNT):
        raise ValueError('Centre chunk must be in [0, 15]')
    if not (0 <= radius <= 7):
        raise ValueError('Region radius must be 0..7')
    if not (0 <= min(far_lod, neighbor_lod, focus_lod)
            and max(far_lod, neighbor_lod, focus_lod) <= 4):
        raise ValueError('LOD must be in 0..4')
    if not (0 <= focus_depth <= 2):
        raise ValueError('Quadtree depth must be 0..2')

    leaves, targets = [], []
    for iy in range(ROOT_COUNT):
        for ix in range(ROOT_COUNT):
            ring = max(abs(ix-cx), abs(iy-cy))
            near = region and ring <= radius
            if region and ix == cx and iy == cy:
                tilelist = descendants(focus_depth, ix, iy, focus_lod)
            else:
                lod = (neighbor_lod if (region and ring == 1 and near
                                       and (ix == cx or iy == cy)) else far_lod)
                tilelist = [Tile(0, ix, iy, lod)]
            leaves.extend(tilelist)
            if near:
                targets.extend(tilelist)
    return leaves, targets


def whole_map_plan(lod=0):
    if not 0 <= lod <= 4:
        raise ValueError('LOD must be 0..4')
    return [Tile(0, x, y, lod) for y in range(ROOT_COUNT) for x in range(ROOT_COUNT)]


def adjacent_tiles(tile, side, leaves):
    x0, y0, x1, y1 = tile.bounds
    out = []
    for other in leaves:
        if other == tile:
            continue
        a, b, c, d = other.bounds
        if side == 'W' and abs(c-x0) < EPS and min(y1,d)-max(y0,b) > EPS:
            out.append(other)
        elif side == 'E' and abs(a-x1) < EPS and min(y1,d)-max(y0,b) > EPS:
            out.append(other)
        elif side == 'S' and abs(d-y0) < EPS and min(x1,c)-max(x0,a) > EPS:
            out.append(other)
        elif side == 'N' and abs(b-y1) < EPS and min(x1,c)-max(x0,a) > EPS:
            out.append(other)
    return out


def _river_limits(x, settings):
    midpoint = tm.river_center_y(x, settings)
    half = tm.river_half_y(x, settings)
    return midpoint - half, midpoint + half


def _root_find(func, a, b):
    """Scan then bisect crossings. Stable independent of sampling LOD."""
    roots = []
    samples = 24
    lastx, lastv = a, func(a)
    if abs(lastv) <= 1.0e-10:
        roots.append(a)
    for i in range(1, samples + 1):
        x = a + (b-a) * i/samples
        val = func(x)
        if abs(val) <= 1.0e-10:
            roots.append(x)
        elif lastv * val < 0.0:
            lo, hi = lastx, x
            vl = lastv
            for _ in range(46):
                mid = 0.5*(lo+hi)
                vm = func(mid)
                if vl * vm <= 0.0:
                    hi = mid
                else:
                    lo, vl = mid, vm
            roots.append(0.5*(lo+hi))
        lastx, lastv = x, val
    return sorted(set(round(r, 9) for r in roots if a-EPS <= r <= b+EPS))


def _bank_crossings_y(y, xa, xb, settings):
    result = []
    for which in (0, 1):
        result.extend(_root_find(lambda x: _river_limits(x, settings)[which]-y, xa, xb))
    return result


def _fixed_grid(a, b, n):
    return [a + (b-a) * i/n for i in range(n+1)]


def _uniq(values, lo, hi):
    return sorted(set(round(max(lo, min(hi, v)), 9)
                      for v in values if lo-EPS <= v <= hi+EPS))


def _clip_against_bank(poly, lx, rx, bank_l, bank_r, keep_above):
    """Clip convex cell to one side of linearly sampled shoreline."""
    if not poly:
        return []
    dx = rx-lx
    slope = (bank_r-bank_l)/dx
    def value(p):
        x,y = p
        d = y - (bank_l + slope*(x-lx))
        return d if keep_above else -d
    out = []
    prev = poly[-1]
    prev_d = value(prev)
    for now in poly:
        now_d = value(now)
        was_in, is_in = prev_d >= -1.e-10, now_d >= -1.e-10
        if was_in != is_in:
            t = prev_d/(prev_d-now_d)
            out.append((prev[0]+t*(now[0]-prev[0]), prev[1]+t*(now[1]-prev[1])))
        if is_in:
            out.append(now)
        prev, prev_d = now, now_d
    clean = []
    for x,y in out:
        p = (round(x,9),round(y,9))
        if not clean or clean[-1] != p:
            clean.append(p)
    if len(clean) > 1 and clean[0] == clean[-1]:
        clean.pop()
    return clean


def _polygon_area(poly):
    if len(poly) < 3:
        return 0.0
    x0,y0 = poly[0]
    return 0.5*sum((poly[i][0]-x0)*(poly[i+1][1]-y0) -
                   (poly[i+1][0]-x0)*(poly[i][1]-y0)
                   for i in range(1,len(poly)-1))


def _is_on_piecewise_shore(x,y,lx,rx,lower,upper):
    t = (x-lx)/(rx-lx)
    yl = lower[0]*(1-t)+lower[1]*t
    yu = upper[0]*(1-t)+upper[1]*t
    return min(abs(y-yl),abs(y-yu)) < 2.0e-7


def _edge_profiles(tile, leaves, settings):
    """World-anchored edge profiles stable under independent regeneration.

    Every tile seam uses the same 250 m-root LOD0 lattice (3.90625 m) and
    exact shoreline intersections. This is deliberate: loading/refining a
    neighbour later must never change elevations on an existing chunk edge.
    The fine mesh is edge-stitched to this low-detail continuous polyline.
    """
    x0,y0,x1,y1=tile.bounds
    profiles={}
    pitch=ROOT_TILE_M/BASE_SEGMENTS
    origin=-WORLD_SIZE_M*0.5
    for side in 'WESN':
        is_x=side in ('S','N')
        a,b=(x0,x1) if is_x else (y0,y1)
        fixed=(y0 if side=='S' else y1) if is_x else (x0 if side=='W' else x1)
        imin=math.ceil((a-origin)/pitch-1.e-8)
        imax=math.floor((b-origin)/pitch+1.e-8)
        pts=[a,b]+[origin+k*pitch for k in range(imin,imax+1)]
        offsets = _cross_offsets(settings)
        if is_x:
            pts.extend(_crossings_at_y(fixed,a,b,settings,offsets))
        else:
            pts.extend(_cross_y(fixed,o,settings) for o in offsets)
        coords=_uniq(pts,a,b)
        heights=[]
        for v in coords:
            px,py=(v,fixed) if is_x else (fixed,v)
            low,high=_river_limits(px,settings)
            if abs(py-low)<2.e-7 or abs(py-high)<2.e-7:
                h=tm.river_water_z(px,settings)
            else:
                h=tm.terrain_height(px,py,settings)
            heights.append(h)
        profiles[side]=(coords,heights)
    return profiles


def _edge_value(profile, coord):
    coords, heights = profile
    i=max(0,min(len(coords)-2,bisect_right(coords,round(coord,9))-1))
    a,b=coords[i],coords[i+1]
    t=min(1.,max(0.,(coord-a)/(b-a)))
    return heights[i]*(1-t) + heights[i+1]*t


def _outer_boundary_z(x,y,bounds,profiles):
    x0,y0,x1,y1=bounds
    # At a corner, all canonical profiles evaluate the same endpoint.
    if abs(x-x0)<EPS:
        return _edge_value(profiles['W'],y)
    if abs(x-x1)<EPS:
        return _edge_value(profiles['E'],y)
    if abs(y-y0)<EPS:
        return _edge_value(profiles['S'],x)
    if abs(y-y1)<EPS:
        return _edge_value(profiles['N'],x)
    return None


def generate_tile(tile, leaves, settings):
    """Return watertight terrain polygons and a distinct continuous water mesh.

    Heightfield is clipped by *geometric* shorelines per cell. No blue-water
    elevation masking. Water and terrain share the exact shoreline XY vertices.
    """
    if not settings.world_space:
        raise ValueError('Chunk generation requires world_space=True')
    x0,y0,x1,y1=tile.bounds
    n=tile.segments
    # Insert exact crossings at horizontal tile borders, independent of LOD.
    offsets=_cross_offsets(settings)
    xs=_uniq(_fixed_grid(x0,x1,n) +
             _crossings_at_y(y0,x0,x1,settings,offsets) +
             _crossings_at_y(y1,x0,x1,settings,offsets),x0,x1)
    ys=_fixed_grid(y0,y1,n)
    profiles=_edge_profiles(tile,leaves,settings)
    tv, tf, wv, wf=[],[],[],[]
    t_lookup,w_lookup={},{}
    shoreline_keys=set()
    partial=0
    # Data is kept in world space during construction. Blender maps it to a
    # local object origin when turning this into Mesh data.
    def land_vertex(x,y,on_shore=False):
        x,y=round(x,9),round(y,9)
        key=(x,y)
        index=t_lookup.get(key)
        if index is not None:
            return index
        if on_shore:
            z=tm.river_water_z(x,settings)
            shoreline_keys.add(key)
        else:
            boundary=_outer_boundary_z(x,y,(x0,y0,x1,y1),profiles)
            z=boundary if boundary is not None else tm.terrain_height(x,y,settings)
        index=len(tv)
        t_lookup[key]=index
        tv.append((x,y,z))
        return index

    def water_vertex(x,y):
        x,y=round(x,9),round(y,9)
        key=(x,y)
        if key not in w_lookup:
            w_lookup[key]=len(wv)
            wv.append((x,y,tm.river_water_z(x,settings)))
        return w_lookup[key]

    def face(poly,kind,left,right,lower,upper):
        if len(poly)<3 or _polygon_area(poly) < 1.e-10:
            return
        vids=[]
        for x,y in poly:
            is_shore=_is_on_piecewise_shore(x,y,left,right,lower,upper)
            vids.append(land_vertex(x,y,is_shore))
        if len(set(vids))>=3:
            # Polygon clipping guarantees convex regions with positive normal.
            tf.append(tuple(vids))
        if kind=='river':
            river_indices=tuple(water_vertex(x,y) for x,y in poly)
            if len(set(river_indices))>=3:
                wf.append(river_indices)

    def slice_poly(poly,left,right,offsets,kind,lower,upper):
        """Cut a cell into explicit cross-section bands at EVERY terrain LOD.

        Using individual constant-offset contours retains the semicircular
        U-section even on 3.9m grid cells and the nearly vertical banks.
        """
        if len(poly)<3:
            return
        remainder=poly
        for offset in offsets:
            edge_a=_cross_y(left,offset,settings)
            edge_b=_cross_y(right,offset,settings)
            under=_clip_against_bank(remainder,left,right,edge_a,edge_b,False)
            face(under,kind,left,right,lower,upper)
            remainder=_clip_against_bank(remainder,left,right,edge_a,edge_b,True)
            if len(remainder)<3:
                break
        face(remainder,kind,left,right,lower,upper)

    def dry_faces(poly,left,right,lower,upper):
        if len(poly)<3:return
        # Do not process the bulk of dry landscape through six channel clips.
        half=settings.river_width*0.5
        edge=settings.bank_width+half
        lo=min(_cross_y(left,-edge,settings), _cross_y(right,-edge,settings))
        hi=max(_cross_y(left,edge,settings), _cross_y(right,edge,settings))
        if max(p[1] for p in poly)<lo or min(p[1] for p in poly)>hi:
            face(poly,'dry',left,right,lower,upper)
            return
        # Additional 2m-bank samples on both banks; broad dry land is intact.
        off=[-half-settings.bank_width*k for k in BANK_STATIONS]
        off.extend([half+settings.bank_width*k for k in BANK_STATIONS])
        slice_poly(poly,left,right,sorted(off),'dry',lower,upper)

    def water_faces(poly,left,right,lower,upper):
        if len(poly)<3:return
        half=settings.river_width*0.5
        slice_poly(poly,left,right,[half*f for f in BED_STATIONS[1:-1]],
                   'river',lower,upper)

    for ix in range(len(xs)-1):
        xa,xb=xs[ix],xs[ix+1]
        lowa,uppa=_river_limits(xa,settings)
        lowb,uppb=_river_limits(xb,settings)
        low=(lowa,lowb); up=(uppa,uppb)
        lower_min=min(lowa,lowb); lower_max=max(lowa,lowb)
        upper_min=min(uppa,uppb); upper_max=max(uppa,uppb)
        for iy in range(n):
            ya,yb=ys[iy],ys[iy+1]
            rect=[(xa,ya),(xb,ya),(xb,yb),(xa,yb)]
            if yb < lower_min-EPS or ya > upper_max+EPS:
                dry_faces(rect,xa,xb,low,up)
            elif ya > lower_max+EPS and yb < upper_min-EPS:
                water_faces(rect,xa,xb,low,up)
            else:
                partial+=1
                lower=_clip_against_bank(rect,xa,xb,lowa,lowb,False)
                river=_clip_against_bank(rect,xa,xb,lowa,lowb,True)
                river=_clip_against_bank(river,xa,xb,uppa,uppb,False)
                upper=_clip_against_bank(rect,xa,xb,uppa,uppb,True)
                dry_faces(lower,xa,xb,low,up)
                water_faces(river,xa,xb,low,up)
                dry_faces(upper,xa,xb,low,up)
    return ChunkMesh(tile,tv,tf,wv,wf,len(shoreline_keys),partial)


def edge_vertices(mesh,side,water=False):
    """Sorted coordinates and Z for a mesh side, for continuous seam tests."""
    x0,y0,x1,y1=mesh.tile.bounds
    pts=mesh.water_vertices if water else mesh.vertices
    data=[]
    for x,y,z in pts:
        if side=='W' and abs(x-x0)<EPS:
            data.append((y,z))
        elif side=='E' and abs(x-x1)<EPS:
            data.append((y,z))
        elif side=='S' and abs(y-y0)<EPS:
            data.append((x,z))
        elif side=='N' and abs(y-y1)<EPS:
            data.append((x,z))
    return sorted(set(data))


def interpolate_polyline(points,pos):
    if len(points)==0:
        return None
    if pos < points[0][0]-EPS or pos>points[-1][0]+EPS:
        return None
    coords=[p[0] for p in points]
    i=max(0,min(len(points)-2,bisect_right(coords,pos)-1))
    a,za=points[i]
    b,zb=points[i+1]
    if b-a<EPS:
        return za
    t=(pos-a)/(b-a)
    return za+(zb-za)*t


def seam_error(mesh_a,mesh_b,side,water=False):
    """Maximum height mismatch along the overlapping edge polylines."""
    opposite={'W':'E','E':'W','S':'N','N':'S'}[side]
    a=edge_vertices(mesh_a,side,water)
    b=edge_vertices(mesh_b,opposite,water)
    if not a or not b:
        return None
    lower=max(a[0][0],b[0][0])
    upper=min(a[-1][0],b[-1][0])
    if upper-lower<EPS:
        return None
    coords=sorted(set([lower,upper]+[p for p,_ in a if lower-EPS<=p<=upper+EPS]
                                 +[p for p,_ in b if lower-EPS<=p<=upper+EPS]))
    return max(abs(interpolate_polyline(a,p)-interpolate_polyline(b,p)) for p in coords)
