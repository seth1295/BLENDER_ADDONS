"""Blender geometry and light-weight non-destructive modifiers."""
import bpy
from .profile import make_sheet_geometry


def update_modifiers(obj):
    p = obj.ci_iron
    thick = obj.modifiers.get('CI / Sheet Thickness')
    detail = obj.modifiers.get('CI / Render Detail')
    true_mode = p.displacement_mode == 'TRUE'

    if not true_mode and detail:
        obj.modifiers.remove(detail)
        detail = None
    elif true_mode:
        if not detail or detail.type != 'SUBSURF':
            if detail:
                obj.modifiers.remove(detail)
            detail = obj.modifiers.new('CI / Render Detail', 'SUBSURF')
        detail.subdivision_type = 'SIMPLE'
        detail.levels = 0
        detail.render_levels = p.render_subdivision
        detail.show_viewport = False
        detail.show_render = True
        # Keep the render subdivision BEFORE Solidify in the stack.
        if thick:
            obj.modifiers.remove(thick)
            thick = None

    if p.thickness > 0.0:
        if not thick or thick.type != 'SOLIDIFY':
            if thick:
                obj.modifiers.remove(thick)
            thick = obj.modifiers.new('CI / Sheet Thickness', 'SOLIDIFY')
        thick.thickness = p.thickness
        thick.offset = -1.0
        thick.use_even_offset = True
        thick.show_viewport = True
        thick.show_render = True
    elif thick:
        obj.modifiers.remove(thick)


def rebuild_mesh(obj):
    if obj.type != 'MESH' or not obj.ci_iron.is_sheet:
        return
    p = obj.ci_iron
    verts, faces, uvs = make_sheet_geometry(
        p.width, p.length, p.pitch, p.depth, p.samples_per_wave,
        p.profile_style, p.phase)
    old = obj.data
    mesh = bpy.data.meshes.new('Corrugated Iron / Sheet')
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    uv_layer = mesh.uv_layers.new(name='Surface Distance (m)')
    for poly in mesh.polygons:
        poly.use_smooth = (p.profile_style == 'ROUND')
        for li in poly.loop_indices:
            uv_layer.data[li].uv = uvs[mesh.loops[li].vertex_index]
    if old:
        for mat in old.materials:
            if mat:
                mesh.materials.append(mat)
    obj.data = mesh
    if old and old.users == 0:
        bpy.data.meshes.remove(old)
    update_modifiers(obj)
