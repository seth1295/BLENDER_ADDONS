# SPDX-FileCopyrightText: 2026 Seth McLaughlin
# SPDX-License-Identifier: MIT
"""Multi-Pass Denoiser for Blender 5.2 and 5.3.

Copyright (c) 2026 Seth McLaughlin.
"""

bl_info = {
    "name": "Multi-Pass Denoiser",
    "author": "Seth McLaughlin",
    "version": (1, 0, 1),
    "blender": (5, 2, 0),
    "location": "3D Viewport > Sidebar (N) > Denoiser",
    "description": "Non-destructive Cycles multi-pass compositor denoising setup",
    "category": "Render",
    "license": "MIT",
    "doc_url": "",
}

import bpy
import json
from bpy.props import EnumProperty

STATE_KEY = "smm_mpd_state_v1"
OWNER_KEY = "smm_mpd_role"
NAME = "Multi-Pass Denoiser | Seth McLaughlin"


def _socket(collection, name):
    return next((socket for socket in collection if socket.name == name), None)


def _node(tree, name):
    return tree.nodes.get(name) if tree else None

def _refresh_render_passes(layer):
    """Ask the render engine to rebuild the layer's dynamically exposed passes.

    A depsgraph ViewLayer.update() only flushes tagged scene updates; it does
    not re-query Cycles' render pass declarations.  In Blender 5.x the
    Render Layers node's outputs can otherwise remain stale in the same
    Python operator that enables Denoising Data.
    """
    layer.update_render_passes()
    layer.update()


def _raw_image_socket(source, layer):
    """Select a truly noisy beauty pass without accepting denoised imagery.

    Some Blender releases omit 'Noisy Image' when built-in denoising is off.
    In that configuration 'Image' itself is the undenoised combined pass.
    """
    raw = _socket(source.outputs, 'Noisy Image')
    if raw is not None:
        return raw
    if layer.cycles.use_denoising is False:
        return _socket(source.outputs, 'Image')
    return None




def _find_owned_node(tree, role):
    if not tree:
        return None
    for node in tree.nodes:
        if node.get(OWNER_KEY) == role:
            return node
    return None


def _socket_ref(node, socket, output):
    collection = node.outputs if output else node.inputs
    return {"node": node.name,
            "identifier": getattr(socket, "identifier", ""),
            "name": socket.name,
            "index": next(i for i, s in enumerate(collection) if s == socket)}


def _resolve_socket(tree, ref, output):
    node = _node(tree, ref["node"])
    if node is None:
        return None
    collection = node.outputs if output else node.inputs
    identifier = ref.get("identifier")
    if identifier:
        for sock in collection:
            if sock.identifier == identifier:
                return sock
    index = ref.get("index", -1)
    if 0 <= index < len(collection) and collection[index].name == ref.get("name"):
        return collection[index]
    return _socket(collection, ref.get("name"))


def _render_layers_matches(node, scene, layer):
    if node.bl_idname != 'CompositorNodeRLayers':
        return False
    return node.layer == layer.name and (node.scene is None or node.scene == scene)


def _choose_rewires(tree, scene, layer):
    """Find the unprocessed image path, preserving other compositor paths."""
    # Blender 5.3's first compositor effect receives its image via Group Input.
    # Blender 5.2 frequently has Render Layers -> Group Output directly.
    preferred = (('NodeGroupInput', 'CompositorNodeRLayers')
                 if bpy.app.version >= (5, 3, 0)
                 else ('CompositorNodeRLayers', 'NodeGroupInput'))
    for kind in preferred:
        for node in tree.nodes:
            if node.bl_idname != kind:
                continue
            if kind == 'CompositorNodeRLayers' and not _render_layers_matches(node, scene, layer):
                continue
            src = _socket(node.outputs, 'Image')
            if src is None:
                continue
            outgoing = [link for link in tuple(tree.links) if link.from_socket == src]
            # If there are no links, do not guess that this is the final image.
            if outgoing:
                return outgoing
    return []


def _ensure_composite_tree(scene):
    """Return tree and ownership bookkeeping. Copies shared trees before changes."""
    result = {
        "created_effect": False,
        "created_tree": False,
        "copied_tree": False,
        "original_tree": "",
        "effect_name": "",
        "prev_effect_render": None,
        "prev_effect_preview": None,
    }
    if bpy.app.version >= (5, 3, 0):
        effects = scene.compositor_effects
        if not len(effects):
            effect = effects.new(NAME)
            result['created_effect'] = True
        else:
            effect = effects[0]
        result['effect_name'] = effect.name
        result['prev_effect_render'] = bool(effect.enable_for_render)
        result['prev_effect_preview'] = bool(effect.enable_for_preview)
        tree = effect.node_group
    else:
        effect = None
        tree = scene.compositing_node_group

    if tree is None:
        tree = bpy.data.node_groups.new(NAME, 'CompositorNodeTree')
        result['created_tree'] = True
        # The first Image output of the node group is the compositor output.
        tree.interface.new_socket(name='Image', in_out='OUTPUT', socket_type='NodeSocketColor')
        group_output = tree.nodes.new('NodeGroupOutput')
        group_output.location = (360, 100)
        if effect is not None:
            effect.node_group = tree
        else:
            scene.compositing_node_group = tree
    elif tree.users > 1:
        # Do not silently modify node groups used by other scenes/effects.
        result['original_tree'] = tree.name
        tree = tree.copy()
        result['copied_tree'] = True
        tree.name = NAME + ' (Scene Copy)'
        if effect is not None:
            effect.node_group = tree
        else:
            scene.compositing_node_group = tree

    result['tree_name'] = tree.name
    if effect is not None:
        effect.enable_for_render = True
        effect.enable_for_preview = True
    return tree, result


def _restore_tree_assignment(scene, state):
    """Undo only the assignments our setup created or copied."""
    if bpy.app.version >= (5, 3, 0):
        effects = scene.compositor_effects
        effect = next((item for item in effects if item.name == state.get('effect_name')), None)
        if effect is not None:
            if state.get('created_effect'):
                effects.remove(effect)
            else:
                if state.get('copied_tree'):
                    original = bpy.data.node_groups.get(state.get('original_tree', ''))
                    if original is not None:
                        effect.node_group = original
                if state.get('created_tree'):
                    effect.node_group = None
                if state.get('prev_effect_render') is not None:
                    effect.enable_for_render = state['prev_effect_render']
                if state.get('prev_effect_preview') is not None:
                    effect.enable_for_preview = state['prev_effect_preview']
    else:
        if state.get('copied_tree'):
            original = bpy.data.node_groups.get(state.get('original_tree', ''))
            if original is not None:
                scene.compositing_node_group = original
        elif state.get('created_tree'):
            scene.compositing_node_group = None

    if state.get('created_tree') or state.get('copied_tree'):
        tree = bpy.data.node_groups.get(state.get('tree_name', ''))
        if tree is not None and tree.users == 0:
            bpy.data.node_groups.remove(tree)


def _scene_tree(scene, state):
    if bpy.app.version >= (5, 3, 0):
        effect = next((item for item in scene.compositor_effects
                       if item.name == state.get('effect_name')), None)
        return effect.node_group if effect else None
    return scene.compositing_node_group


def _save_state(scene, state):
    scene[STATE_KEY] = json.dumps(state, sort_keys=True)


def _read_state(scene):
    raw = scene.get(STATE_KEY)
    if raw is None:
        return None
    try:
        return json.loads(raw)
    except (ValueError, TypeError):
        return {'invalid': True}


def _install(scene, layer):
    if _read_state(scene) is not None:
        raise RuntimeError('Already set up: use Remove Setup before installing again')
    if not hasattr(layer, 'cycles') or not hasattr(layer.cycles, 'denoising_store_passes'):
        raise RuntimeError('Cycles denoising data is unavailable for this view layer')

    state = {
        'version': 1,
        'prev_engine': scene.render.engine,
        'prev_compositing': bool(scene.render.use_compositing),
        'view_layer_name': layer.name,
        'prev_passes': bool(layer.cycles.denoising_store_passes),
        'prev_render_denoise': bool(layer.cycles.use_denoising),
        'rewires': [],
    }
    tree = None
    setup_info = None
    made_nodes = []
    try:
        if scene.render.engine != 'CYCLES':
            scene.render.engine = 'CYCLES'
        layer.cycles.denoising_store_passes = True
        layer.cycles.use_denoising = False
        # Pass enumeration is NOT refreshed by a standard view-layer update.
        # Requery Cycles explicitly before creating compositor nodes.
        _refresh_render_passes(layer)
        scene.render.use_compositing = True

        tree, setup_info = _ensure_composite_tree(scene)
        state.update(setup_info)
        links = _choose_rewires(tree, scene, layer)
        # In a newly generated tree, connect directly to its Group Output.
        if not links and not state['created_tree']:
            raise RuntimeError('No safe Render Layers/Group Input image path to splice. '
                               'Existing compositor was left unchanged.')

        output = next((node for node in tree.nodes if node.bl_idname == 'NodeGroupOutput'), None)
        if state['created_tree'] and (output is None or _socket(output.inputs, 'Image') is None):
            raise RuntimeError('New compositor group has no Image output')

        source = tree.nodes.new('CompositorNodeRLayers')
        made_nodes.append(source)
        source.name = 'SMM - Raw Render Passes'
        source.label = 'Noisy / Albedo / Normal'
        source[OWNER_KEY] = 'source'
        source.scene = scene
        source.layer = layer.name
        source.location = (-550, -300)

        # On first creation the RLayers node may be using a cached socket
        # list from before the new layer and scene were assigned.
        _refresh_render_passes(layer)

        denoise = tree.nodes.new('CompositorNodeDenoise')
        made_nodes.append(denoise)
        denoise.name = 'SMM - Multi-Pass Denoise'
        denoise.label = 'Multi-Pass Denoise | Seth McLaughlin'
        denoise[OWNER_KEY] = 'denoise'
        denoise.location = (-250, -300)
        denoise.width = 240
        image = _raw_image_socket(source, layer)
        albedo = _socket(source.outputs, 'Denoising Albedo')
        normal = _socket(source.outputs, 'Denoising Normal')
        if image is None or albedo is None or normal is None:
            missing = [name for name, sock in (
                ('Noisy Image/Image', image),
                ('Denoising Albedo', albedo),
                ('Denoising Normal', normal),
            ) if sock is None]
            available = ', '.join(s.name for s in source.outputs)
            raise RuntimeError(
                'Required denoising passes missing: ' + ', '.join(missing) +
                '. Render Layers outputs: ' + available +
                '. Enable Denoising Data and retry.'
            )
        for src, name in ((image, 'Image'), (albedo, 'Albedo'), (normal, 'Normal')):
            dst = _socket(denoise.inputs, name)
            if dst is None:
                raise RuntimeError('Denoise node input missing: ' + name)
            tree.links.new(src, dst)

        result = _socket(denoise.outputs, 'Image')
        if result is None:
            raise RuntimeError('Denoise output socket missing')

        if state['created_tree']:
            tree.links.new(result, _socket(output.inputs, 'Image'))
        else:
            for old in links:
                record = {
                    'from': _socket_ref(old.from_node, old.from_socket, True),
                    'to': _socket_ref(old.to_node, old.to_socket, False),
                }
                state['rewires'].append(record)
            for old in links:
                destination = old.to_socket
                tree.links.remove(old)
                tree.links.new(result, destination)

        scene.render.use_compositing = True
        _save_state(scene, state)
        return state
    except Exception:
        # Never leave a half-wired compositor behind on failed installation.
        if tree is not None and setup_info is not None:
            if state['rewires']:
                for record in state['rewires']:
                    src = _resolve_socket(tree, record['from'], True)
                    dst = _resolve_socket(tree, record['to'], False)
                    if src is not None and dst is not None:
                        tree.links.new(src, dst)
            for node in made_nodes:
                if _node(tree, node.name) is not None:
                    tree.nodes.remove(node)
            _restore_tree_assignment(scene, setup_info)
        layer.cycles.denoising_store_passes = state['prev_passes']
        layer.cycles.use_denoising = state['prev_render_denoise']
        scene.render.use_compositing = state['prev_compositing']
        scene.render.engine = state['prev_engine']
        raise


def _remove(scene):
    state = _read_state(scene)
    if state is None or state.get('invalid'):
        raise RuntimeError('No valid managed setup found on this scene')
    tree = _scene_tree(scene, state)
    if tree is None:
        raise RuntimeError('Managed compositor graph is missing')

    denoise = _find_owned_node(tree, 'denoise')
    source = _find_owned_node(tree, 'source')
    if denoise is None or source is None:
        raise RuntimeError('Managed nodes are missing. Cannot safely restore links.')

    for item in state.get('rewires', []):
        src = _resolve_socket(tree, item['from'], True)
        dst = _resolve_socket(tree, item['to'], False)
        if src is None or dst is None:
            continue  # User deleted/changed source: do not reconstruct dead nodes.
        current = next((link for link in tree.links if link.to_socket == dst), None)
        if current is None or current.from_node == denoise:
            tree.links.new(src, dst)

    tree.nodes.remove(denoise)
    tree.nodes.remove(source)
    _restore_tree_assignment(scene, state)

    view_layer = scene.view_layers.get(state['view_layer_name'])
    if view_layer is not None:
        # Revert only values still under our management.
        if view_layer.cycles.denoising_store_passes is True:
            view_layer.cycles.denoising_store_passes = state['prev_passes']
        if view_layer.cycles.use_denoising is False:
            view_layer.cycles.use_denoising = state['prev_render_denoise']
    if scene.render.use_compositing is True:
        scene.render.use_compositing = state['prev_compositing']
    if scene.render.engine == 'CYCLES' and state['prev_engine'] != 'CYCLES':
        scene.render.engine = state['prev_engine']
    del scene[STATE_KEY]


class SMM_MPD_OT_setup(bpy.types.Operator):
    bl_idname = 'smm_mpd.setup'
    bl_label = 'Set Up Multi-Pass Denoiser'
    bl_description = 'Configure Cycles passes and safely splice denoising into the compositor'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            _install(context.scene, context.view_layer)
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        self.report({'INFO'}, 'Denoiser installed: raw image + albedo + normal')
        return {'FINISHED'}


class SMM_MPD_OT_remove(bpy.types.Operator):
    bl_idname = 'smm_mpd.remove'
    bl_label = 'Remove Denoiser Setup'
    bl_description = 'Remove managed nodes, restore image links and prior render settings'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            _remove(context.scene)
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        self.report({'INFO'}, 'Multi-Pass Denoiser removed')
        return {'FINISHED'}


class SMM_MPD_OT_preset(bpy.types.Operator):
    bl_idname = 'smm_mpd.preset'
    bl_label = 'Apply Sampling Preset'
    bl_description = 'Adjust Cycles adaptive sampling; presets are editable'
    bl_options = {'REGISTER', 'UNDO'}

    preset: EnumProperty(items=[
        ('DRAFT', 'Draft', '64 samples, 0.05 noise threshold'),
        ('BALANCED', 'Balanced', '256 samples, 0.01 noise threshold'),
        ('QUALITY', 'Quality', '500 samples, 0.005 noise threshold'),
    ])

    def execute(self, context):
        scene = context.scene
        if scene.render.engine != 'CYCLES':
            self.report({'ERROR'}, 'Switch to Cycles before choosing a preset')
            return {'CANCELLED'}
        samples, threshold = {
            'DRAFT': (64, .05),
            'BALANCED': (256, .01),
            'QUALITY': (500, .005),
        }[self.preset]
        scene.cycles.use_adaptive_sampling = True
        scene.cycles.samples = samples
        scene.cycles.adaptive_threshold = threshold
        self.report({'INFO'}, 'Cycles sampling preset: ' + self.preset.title())
        return {'FINISHED'}


class SMM_MPD_OT_open_compositor(bpy.types.Operator):
    bl_idname = 'smm_mpd.open_compositor'
    bl_label = 'Open Compositor'
    bl_description = 'Switch this editor to the compositor so you can inspect the nodes'

    @classmethod
    def poll(cls, context):
        return context.area is not None

    def execute(self, context):
        context.area.type = 'NODE_EDITOR'
        context.area.ui_type = 'CompositorNodeTree'
        return {'FINISHED'}


class SMM_MPD_PT_panel(bpy.types.Panel):
    bl_label = 'Multi-Pass Denoiser'
    bl_idname = 'SMM_MPD_PT_panel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Denoiser'

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        state = _read_state(scene)
        installed = bool(state and not state.get('invalid'))
        box = layout.box()
        box.label(text='by Seth McLaughlin  |  MIT', icon='INFO')
        box.prop(scene.render, 'engine', text='Engine')
        if not installed:
            if scene.render.engine != 'CYCLES':
                box.label(text='Setup will switch engine to Cycles', icon='INFO')
            box.operator('smm_mpd.setup', text='Set Up Multi-Pass Denoiser', icon='NODETREE')
        else:
            box.label(text='Installed on: ' + state['view_layer_name'], icon='CHECKMARK')
            box.operator('smm_mpd.remove', text='Remove Setup', icon='X')
            tree = _scene_tree(scene, state)
            denoise = _find_owned_node(tree, 'denoise')
            if denoise:
                box.prop(denoise, 'mute', text='Bypass Denoiser')
                props = box.column(align=True)
                for label in ('HDR', 'Prefilter', 'Quality'):
                    socket = _socket(denoise.inputs, label)
                    if socket is not None:
                        props.prop(socket, 'default_value', text=label)
            else:
                box.label(text='Managed nodes missing - inspect graph', icon='ERROR')
            box.operator('smm_mpd.open_compositor', icon='NODETREE')

        if scene.render.engine == 'CYCLES':
            sampling = layout.box()
            sampling.label(text='Cycles Final Render', icon='RENDER_STILL')
            sampling.prop(scene.cycles, 'use_adaptive_sampling', text='Adaptive Sampling')
            sampling.prop(scene.cycles, 'samples', text='Max Samples')
            row = sampling.row()
            row.enabled = bool(scene.cycles.use_adaptive_sampling)
            row.prop(scene.cycles, 'adaptive_threshold', text='Noise Threshold')
            row = sampling.row(align=True)
            for label, value in [('Draft', 'DRAFT'), ('Balanced', 'BALANCED'), ('500 Quality', 'QUALITY')]:
                op = row.operator('smm_mpd.preset', text=label)
                op.preset = value
            layer = context.view_layer
            info = layout.box()
            info.label(text='Active View Layer: ' + layer.name)
            info.prop(layer.cycles, 'denoising_store_passes', text='Denoising Data')
            info.prop(layer.cycles, 'use_denoising', text='Built-in Render Denoise')
            if installed and layer.cycles.use_denoising:
                info.label(text='Built-in denoise adds a second denoise step', icon='ERROR')
        layout.label(text='Node uses OpenImageDenoise')


_CLASSES = (
    SMM_MPD_OT_setup,
    SMM_MPD_OT_remove,
    SMM_MPD_OT_preset,
    SMM_MPD_OT_open_compositor,
    SMM_MPD_PT_panel,
)


def register():
    if not ((5, 2, 0) <= bpy.app.version < (5, 4, 0)):
        raise RuntimeError('Multi-Pass Denoiser 1.0.1 requires Blender 5.2 or 5.3')
    for cls in _CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)


if __name__ == '__main__':
    register()
