"""Conduit Forge — live procedural routed hoses, braid and cable harnesses.

Install the ZIP as a normal Blender add-on. No scripts are executed manually.
Requires Blender 4.3+; uses only bpy and Python's standard library.
"""
bl_info = {
    'name': 'Conduit Forge | Live Cable & Hose Rig',
    'author': 'Project Owner',
    'version': (1, 0, 0),
    'blender': (4, 3, 0),
    'location': 'Shift+A > Conduit Forge Rig; N > Conduit Forge',
    'description': 'Live procedural braided cables, corrugated tubing, bundles and hydraulic hoses',
    'category': 'Add Curve',
}

import math
import traceback
import uuid

import bpy
from bpy.app.handlers import persistent
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty, StringProperty
from mathutils import Vector

from . import math3d as m


_UID = 'cf_uid'
_ROLE = 'cf_role'
_PART = 'cf_part'
_PENDING = set()
_REBUILDING = False
_TIMER_ARMED = False


# --------------------------- materials ---------------------------

_PALETTE = {
    'rubber': ((0.018, 0.023, 0.030, 1), 0.05, 0.78),
    'dark_steel': ((0.105, 0.125, 0.145, 1), 0.82, 0.32),
    'steel': ((0.40, 0.46, 0.50, 1), 0.88, 0.25),
    'copper': ((0.66, 0.285, 0.105, 1), 0.83, 0.31),
    'brass': ((0.73, 0.50, 0.16, 1), 0.82, 0.30),
    'red': ((0.68, 0.035, 0.035, 1), 0.18, 0.38),
    'yellow': ((0.98, 0.59, 0.025, 1), 0.15, 0.31),
    'cyan': ((0.020, 0.41, 0.79, 1), 0.13, 0.34),
    'ivory': ((0.80, 0.82, 0.69, 1), 0.16, 0.34),
    'green': ((0.055, 0.55, 0.19, 1), 0.10, 0.39),
    'charcoal': ((0.040, 0.052, 0.068, 1), 0.20, 0.44),
}


def material(key):
    name = 'CF • ' + key.replace('_', ' ').title()
    mat = bpy.data.materials.get(name)
    if mat is None:
        rgba, metallic, roughness = _PALETTE[key]
        mat = bpy.data.materials.new(name)
        mat.diffuse_color = rgba
        mat.use_nodes = True
        bsdf = mat.node_tree.nodes.get('Principled BSDF')
        if bsdf:
            bsdf.inputs['Base Color'].default_value = rgba
            bsdf.inputs['Metallic'].default_value = metallic
            bsdf.inputs['Roughness'].default_value = roughness
    return mat


def apply_materials(data, keys):
    slots = data.materials
    slots.clear()
    for key in keys:
        slots.append(material(key))


# --------------------------- runtime ---------------------------


def get_root(uid):
    for obj in bpy.data.objects:
        if obj.get(_ROLE) == 'RIG' and obj.get(_UID) == uid:
            return obj
    return None


def selected_root(context):
    ob = context.active_object
    if ob is None:
        return None
    if ob.get(_ROLE) == 'RIG':
        return ob
    uid = ob.get(_UID)
    return get_root(uid) if uid else None


def find_child(root, role=None, part=None):
    for child in root.children:
        if role is not None and child.get(_ROLE) == role:
            return child
        if part is not None and child.get(_PART) == part:
            return child
    return None


def delete_object(obj):
    data = obj.data
    bpy.data.objects.remove(obj, do_unlink=True)
    if data is not None and data.users == 0:
        if isinstance(data, bpy.types.Mesh):
            bpy.data.meshes.remove(data)
        elif isinstance(data, bpy.types.Curve):
            bpy.data.curves.remove(data)


def ensure_part(root, key, obj_type):
    ob = find_child(root, part=key)
    if ob and ob.type != obj_type:
        delete_object(ob)
        ob = None
    if ob is None:
        if obj_type == 'MESH':
            data = bpy.data.meshes.new('CF | ' + key)
        else:
            data = bpy.data.curves.new('CF | ' + key, type='CURVE')
        ob = bpy.data.objects.new('CF | ' + key.title(), data)
        root.users_collection[0].objects.link(ob)
        ob.parent = root
        ob[_UID] = root[_UID]
        ob[_PART] = key
        ob.hide_select = key not in {'BODY'}
    return ob


def write_mesh(root, key, vertices, faces, mats, face_mat_indices=None):
    ob = ensure_part(root, key, 'MESH')
    mesh = ob.data
    mesh.clear_geometry()
    mesh.from_pydata(vertices, [], faces)
    mesh.update(calc_edges=True)
    apply_materials(mesh, mats)
    for idx, poly in enumerate(mesh.polygons):
        poly.use_smooth = len(poly.vertices) == 4
        if face_mat_indices:
            poly.material_index = face_mat_indices[idx]
    return ob


def write_curves(root, key, splines, mats, bevel_depth, bevel_quality=3):
    ob = ensure_part(root, key, 'CURVE')
    data = ob.data
    data.splines.clear()
    data.dimensions = '3D'
    data.resolution_u = 12
    data.bevel_depth = max(0.0001, bevel_depth)
    data.bevel_resolution = bevel_quality
    data.use_fill_caps = True
    apply_materials(data, mats)
    for positions, material_index in splines:
        if len(positions) < 2:
            continue
        spline = data.splines.new('POLY')
        spline.points.add(len(positions)-1)
        for point, position in zip(spline.points, positions):
            point.co = (position[0], position[1], position[2], 1.0)
        spline.material_index = material_index
        spline.use_smooth = True
    return ob


def remove_part(root, key):
    ob = find_child(root, part=key)
    if ob is not None:
        delete_object(ob)


def profile_ring_mesh(endpoint, outward, n, b, radius, profile, sides=24):
    """Turned metal coupling. Hexagonal middle section and annular open tip."""
    vertices, faces, material_ids = [], [], []
    for d, r, hex_blend, _ in profile:
        for i in range(sides):
            theta = m.TAU*i/sides
            # A true flat-sided 6-point nut, blended with circular shoulders.
            shape = math.cos(math.pi/6)/math.cos((theta % (math.pi/3))-math.pi/6)
            rr = radius*r*(1.0 + hex_blend*(shape - 1.0))
            offset = m.add(m.mul(outward, radius*d),
                           m.add(m.mul(n, rr*math.cos(theta)), m.mul(b, rr*math.sin(theta))))
            vertices.append(m.add(endpoint, offset))
    for layer in range(len(profile)-1):
        mi = profile[layer][3]
        for i in range(sides):
            j = (i+1) % sides
            faces.append((layer*sides+i, layer*sides+j,
                          (layer+1)*sides+j, (layer+1)*sides+i))
            material_ids.append(mi)
    # Visible, recessed hole rather than a solid metallic disk.
    d_last = profile[-1][0]
    base = len(vertices)
    for i in range(sides):
        t = m.TAU*i/sides
        inner = m.add(m.mul(outward, radius*d_last),
                      m.add(m.mul(n, radius*0.64*math.cos(t)),
                            m.mul(b, radius*0.64*math.sin(t))))
        vertices.append(m.add(endpoint, inner))
    prev = (len(profile)-1)*sides
    for i in range(sides):
        j = (i+1) % sides
        faces.append((prev+i, prev+j, base+j, base+i))
        material_ids.append(profile[-1][3])
    return vertices, faces, material_ids


def concat_mesh(dst, piece):
    vv, ff, mm = piece
    offset = len(dst[0])
    dst[0].extend(vv)
    dst[1].extend(tuple(i+offset for i in face) for face in ff)
    dst[2].extend(mm)


def coupling_profile():
    # (axial distance, radial size, hex factor, material index)
    return [(0.00,1.03,0,0), (0.38,1.03,0,0),
            (0.44,1.15,0,1), (0.70,1.15,0,1),
            (0.77,1.07,0,0), (0.92,1.23,0,0),
            (1.04,1.48,1,0), (1.86,1.48,1,0),
            (1.99,1.22,0,0), (2.14,1.08,0,0),
            (2.62,1.08,0,0), (2.73,1.20,0,2),
            (2.89,1.20,0,2)]


def build_fittings(root, radius, points, tangents, frames, colorway):
    mesh = [[], [], []]
    profile = coupling_profile()
    # Fittings extend outward, leaving the full cable exposed between ends.
    for p, t, (n, b), sign in ((points[0], tangents[0], frames[0], -1.0),
                              (points[-1], tangents[-1], frames[-1], 1.0)):
        concat_mesh(mesh, profile_ring_mesh(p, m.mul(t, sign), n, b, radius, profile))
    accent = 'copper' if colorway == 'COPPER' else ('yellow' if colorway == 'SAFETY' else 'brass')
    write_mesh(root, 'FITTINGS', mesh[0], mesh[1], ['steel','dark_steel',accent],mesh[2])


def build_bands(root, settings, points, tangents, frames, arclength, radius):
    count = settings.bands
    if count == 0:
        remove_part(root, 'BANDS')
        return
    combined = [[], [], []]
    for i in range(count):
        f = (i+1)/(count+1)
        p, t, n, b = m.interpolate_distance(points,tangents,frames,arclength,f)
        thickness = radius*(0.48 if settings.style == 'BUNDLE' else 0.42)
        profile = [(-thickness/radius/2.0, 1.13, 0, 0),
                   (-0.26*thickness/radius, 1.20, 0, 0),
                   (0.26*thickness/radius, 1.20, 0, 0),
                   (thickness/radius/2.0, 1.13, 0, 0)]
        concat_mesh(combined, profile_ring_mesh(p, t, n, b, radius, profile))
    band_mat = 'charcoal' if settings.style == 'BUNDLE' else 'steel'
    write_mesh(root, 'BANDS', combined[0], combined[1], [band_mat], combined[2])


def handle_info(root, kind):
    obj = find_child(root, role=kind)
    if obj is None:
        return None
    # Query in rig-local coordinates, so moving/rotating/scaling the whole rig
    # preserves its exact shape and appearance.
    local = root.matrix_world.inverted_safe() @ obj.matrix_world
    direction = local.to_3x3() @ Vector((0.0, 0.0, 1.0))
    return tuple(local.translation), tuple(direction.normalized()), local.to_scale().z


def rebuild(root):
    """Regenerate only the four result datablocks, preserving Blender objects."""
    global _REBUILDING
    if _REBUILDING or root is None:
        return
    _REBUILDING = True
    try:
        handles = [handle_info(root, name) for name in ('START','BEND','END')]
        if any(h is None for h in handles):
            return
        settings = root.cf_settings
        points, tangents = m.sample_route(
            handles[0][0], handles[1][0], handles[2][0],
            [h[1] for h in handles], [h[2] for h in handles],
            settings.tension, settings.resolution)
        frames = m.parallel_frames(tangents)
        arclength = m.cumulative_lengths(points)
        radius = settings.radius
        colorway = settings.colorway
        base_mat = 'rubber' if colorway != 'SAFETY' else 'charcoal'
        core_radius = {
            'BRAID': 0.86, 'CORRUGATED': 0.90,
            'BUNDLE': 0.34, 'HYDRAULIC': 1.0,
        }[settings.style] * radius
        verts, faces = m.tube_mesh(points,frames,core_radius,settings.sides)
        write_mesh(root,'BODY',verts,faces,[base_mat])
        write_detail(root,settings,points,tangents,frames,arclength,radius)
        if settings.fittings:
            build_fittings(root,radius,points,tangents,frames,colorway)
        else:
            remove_part(root, 'FITTINGS')
        build_bands(root,settings,points,tangents,frames,arclength,radius)
        root['cf_length_m'] = round(arclength[-1], 4)
    except Exception:
        print('[Conduit Forge] Rebuild failed:')
        traceback.print_exc()
    finally:
        _REBUILDING = False


def write_detail(root, s, points, tangents, frames, arclength, r):
    details = []
    if s.style == 'BRAID':
        strands = s.strands
        wraps = s.weave_turns
        samples = max(160, min(2400, int(wraps*48)))
        for handed in (1, -1):
            for i in range(strands):
                phase = m.TAU*i/strands + (math.pi/strands if handed < 0 else 0)
                # Counter-rotating filaments with a subtle over-under weave.
                positions = m.helical_points(
                    points,tangents,frames,arclength,
                    handed*wraps, r*0.925, phase,samples,
                    0.012,0.988,radial_wave=r*0.025*handed,
                    wave_frequency=wraps*strands)
                details.append((positions,0 if handed == 1 else 1))
        if s.colorway == 'COPPER':
            mats = ['copper','steel']
        elif s.colorway == 'SAFETY':
            mats = ['steel','yellow']
        else:
            mats = ['steel','dark_steel']
        bevel = r*s.strand_radius
    elif s.style == 'CORRUGATED':
        turns = s.rib_turns
        steps = max(160, min(2500, int(turns*13)))
        details = [(m.helical_points(points,tangents,frames,arclength,
                                    turns,r*0.93,0.0,steps,0.015,0.985),0)]
        mats = ['dark_steel' if s.colorway == 'STEEL' else 'copper' if s.colorway == 'COPPER' else 'yellow']
        bevel = r*0.145
    elif s.style == 'BUNDLE':
        colors = ['red','cyan','yellow','ivory','green','steel','copper','charcoal']
        count = s.wire_count
        for i in range(count):
            phase = m.TAU*i/count
            positions = m.helical_points(points,tangents,frames,arclength,
                s.bundle_twist,r*0.60,phase,max(130,s.resolution*3),0.015,0.985)
            details.append((positions,i))
        mats = colors[:count]
        bevel = r*0.31
    else: # HYDRAULIC
        for i in range(2):
            # The paint stripe rotates slowly around the curved hose.
            positions = m.helical_points(points,tangents,frames,arclength,
                    s.bundle_twist,r*1.013,0.27 + i*0.22,max(130,s.resolution*3),0.01,0.99)
            details.append((positions,i))
        mats = ['yellow' if s.colorway != 'COPPER' else 'copper',
                'ivory' if s.colorway != 'SAFETY' else 'red']
        bevel = r*0.031
    write_curves(root,'DETAIL',details,mats,bevel)


def _flush_dirty():
    global _TIMER_ARMED
    _TIMER_ARMED = False
    if _REBUILDING:
        return 0.05
    pending = list(_PENDING)
    _PENDING.clear()
    for uid in pending:
        root = get_root(uid)
        if root is not None:
            rebuild(root)
    return None


def queue(root):
    global _TIMER_ARMED
    if root is None or root.get(_ROLE) != 'RIG':
        return
    _PENDING.add(root[_UID])
    if not _TIMER_ARMED:
        _TIMER_ARMED = True
        bpy.app.timers.register(_flush_dirty, first_interval=0.035)


def settings_changed(self, context):
    root = self.id_data
    if isinstance(root, bpy.types.Object):
        queue(root)


@persistent
def changes_handler(scene, depsgraph):
    if _REBUILDING:
        return
    seen = set()
    for update in depsgraph.updates:
        obj = update.id
        if isinstance(obj, bpy.types.Object):
            if obj.get(_ROLE) in {'START','BEND','END'}:
                seen.add(obj.get(_UID))
    for uid in seen:
        if uid:
            queue(get_root(uid))


@persistent
def load_handler(_dummy):
    _PENDING.clear()
    for obj in bpy.data.objects:
        if obj.get(_ROLE) == 'RIG':
            queue(obj)


# --------------------------- settings ---------------------------

class CF_PG_settings(bpy.types.PropertyGroup):
    style: EnumProperty(
        name='Construction',
        items=[('BRAID','Cross-weave Braid','Counter-rotating strands woven over a hose'),
               ('CORRUGATED','Corrugated Conduit','Flexible raised-rib protective conduit'),
               ('BUNDLE','Multi-core Harness','Individually coloured wires in a twisted bundle'),
               ('HYDRAULIC','Hydraulic Hose','Smooth reinforced hose with identification stripes')],
        default='BRAID', update=settings_changed)
    colorway: EnumProperty(name='Finish',
        items=[('STEEL','Industrial Steel','Metal and charcoal'),
               ('COPPER','Copper Alloy','Copper and metallic highlights'),
               ('SAFETY','Safety / High Visibility','Yellow and contrast accents')],
        default='COPPER', update=settings_changed)
    radius: FloatProperty(name='Outer Radius', default=0.067, min=0.002,
                          max=5.0, subtype='DISTANCE', precision=3, update=settings_changed)
    tension: FloatProperty(name='Bend Handle Strength', default=1.0,
                           min=0.05,max=2.5,precision=2,update=settings_changed)
    resolution: IntProperty(name='Path Detail',default=64,min=12,max=180,update=settings_changed)
    sides: IntProperty(name='Roundness',default=16,min=8,max=48,update=settings_changed)
    strands: IntProperty(name='Braid Strands / Direction',default=8,min=3,max=18,update=settings_changed)
    weave_turns: FloatProperty(name='Braid Turns',default=12.0,min=1.0,max=50.0,
                               precision=1,update=settings_changed)
    strand_radius: FloatProperty(name='Fibre Thickness',default=0.087,min=0.025,
                                 max=0.2,precision=3,update=settings_changed)
    rib_turns: IntProperty(name='Conduit Ribs',default=64,min=8,max=180,update=settings_changed)
    wire_count: IntProperty(name='Core Count',default=5,min=2,max=8,update=settings_changed)
    bundle_twist: FloatProperty(name='Cable Twist / Stripe Spin',default=1.0,min=0.0,
                                max=12.0,update=settings_changed)
    fittings: BoolProperty(name='End Couplers',default=True,update=settings_changed)
    bands: IntProperty(name='Clamp / Tie Count',default=2,min=0,max=12,update=settings_changed)


# --------------------------- operators ---------------------------

class CF_OT_create(bpy.types.Operator):
    bl_idname = 'object.conduit_forge_create'
    bl_label = 'Conduit Forge Rig'
    bl_description = 'Create a procedural hose/cable with three direct viewport handles'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.mode != 'OBJECT':
            self.report({'WARNING'},'Switch to Object Mode to create a conduit')
            return {'CANCELLED'}
        uid = uuid.uuid4().hex
        collection = bpy.data.collections.new('Conduit Forge')
        context.scene.collection.children.link(collection)
        root = bpy.data.objects.new('CF | Conduit Rig', None)
        collection.objects.link(root)
        root[_UID] = uid
        root[_ROLE] = 'RIG'
        root.empty_display_type = 'PLAIN_AXES'
        root.empty_display_size = 0.16
        root.location = context.scene.cursor.location
        root.show_in_front = True
        root.show_name = True
        from mathutils import Vector as V
        rotation = V((1.0, 0.0, 0.0)).to_track_quat('Z','Y')
        for label, kind, loc in (
                ('01 START  |  move + rotate', 'START', (0.0, 0.0, 0.0)),
                ('02 BEND  |  move + rotate', 'BEND', (1.10, 0.48, 0.42)),
                ('03 END  |  move + rotate', 'END', (2.55, 0.0, 0.12))):
            handle = bpy.data.objects.new('CF | '+label, None)
            collection.objects.link(handle)
            handle.parent = root
            handle.location = loc
            handle.rotation_mode = 'QUATERNION'
            handle.rotation_quaternion = rotation
            handle.empty_display_type = 'SINGLE_ARROW' if kind != 'BEND' else 'ARROWS'
            handle.empty_display_size = 0.28 if kind == 'BEND' else 0.23
            handle.show_name = True
            handle.show_in_front = True
            handle[_UID] = uid
            handle[_ROLE] = kind
        context.view_layer.update()
        rebuild(root)
        _PENDING.discard(uid)
        bpy.ops.object.select_all(action='DESELECT')
        root.select_set(True)
        context.view_layer.objects.active = root
        self.report({'INFO'}, 'Move/rotate the three arrows; open N > Conduit Forge for parameters')
        return {'FINISHED'}


class CF_OT_select_handle(bpy.types.Operator):
    bl_idname = 'object.conduit_forge_select_handle'
    bl_label = 'Select Conduit Control'
    bl_description = 'Select one of this rig’s viewport controls'
    bl_options = {'REGISTER','UNDO'}

    kind: EnumProperty(items=[('START','Start',''),('BEND','Bend',''),
                              ('END','End',''),('RIG','Root','')],default='BEND')

    def execute(self, context):
        root = selected_root(context)
        if root is None:
            return {'CANCELLED'}
        obj = root if self.kind == 'RIG' else find_child(root, role=self.kind)
        if obj is None:
            self.report({'WARNING'}, 'The requested control is missing')
            return {'CANCELLED'}
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj
        return {'FINISHED'}


class CF_OT_refresh(bpy.types.Operator):
    bl_idname = 'object.conduit_forge_refresh'
    bl_label = 'Refresh Conduit'
    bl_options = {'REGISTER','UNDO'}

    def execute(self, context):
        root = selected_root(context)
        if root is None:
            return {'CANCELLED'}
        rebuild(root)
        return {'FINISHED'}


class CF_OT_bake(bpy.types.Operator):
    bl_idname = 'object.conduit_forge_bake'
    bl_label = 'Bake Mesh Copy'
    bl_description = 'Create independent mesh copies, retaining the editable source rig'
    bl_options = {'REGISTER','UNDO'}

    def execute(self, context):
        root = selected_root(context)
        if root is None:
            return {'CANCELLED'}
        # Ensure output reflects the most recent viewport control transforms.
        rebuild(root)
        context.view_layer.update()
        depsgraph = context.evaluated_depsgraph_get()
        coll = bpy.data.collections.new(root.name + ' | BAKED')
        context.scene.collection.children.link(coll)
        baked = []
        for ob in list(root.children):
            if _PART not in ob:
                continue
            evaluated = ob.evaluated_get(depsgraph)
            mesh = bpy.data.meshes.new_from_object(evaluated, preserve_all_data_layers=True,
                                                   depsgraph=depsgraph)
            if not mesh.materials:
                for mat in ob.data.materials:
                    mesh.materials.append(mat)
            baked_ob = bpy.data.objects.new(ob.name + ' | Baked', mesh)
            coll.objects.link(baked_ob)
            baked_ob.matrix_world = ob.matrix_world.copy()
            baked.append(baked_ob)
        if not baked:
            bpy.data.collections.remove(coll)
            self.report({'WARNING'}, 'No generated geometry found')
            return {'CANCELLED'}
        bpy.ops.object.select_all(action='DESELECT')
        for ob in baked:
            ob.select_set(True)
        context.view_layer.objects.active = baked[0]
        self.report({'INFO'},f'Baked {len(baked)} editable meshes; original procedural rig retained')
        return {'FINISHED'}


# --------------------------- UI ---------------------------

class CF_PT_sidebar(bpy.types.Panel):
    bl_label = 'Conduit Forge'
    bl_idname = 'VIEW3D_PT_conduit_forge'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Conduit Forge'

    def draw(self, context):
        layout = self.layout
        root = selected_root(context)
        if root is None:
            layout.label(text='No active conduit rig', icon='INFO')
            layout.operator(CF_OT_create.bl_idname,text='Create Conduit',icon='CURVE_PATH')
            return
        s = root.cf_settings
        layout.label(text=root.name,icon='CURVE_PATH')
        if 'cf_length_m' in root:
            layout.label(text=f"Path length: {root['cf_length_m']:.3f} m",icon='DRIVER_DISTANCE')
        guide = layout.box()
        guide.label(text='VIEWPORT HANDLES',icon='EMPTY_ARROWS')
        row = guide.row(align=True)
        for label, kind in (('A','START'),('Bend','BEND'),('B','END')):
            op = row.operator(CF_OT_select_handle.bl_idname,text=label)
            op.kind = kind
        guide.label(text='G move  •  R direction  •  S tangent')
        col = layout.column(align=True)
        col.prop(s,'style')
        col.prop(s,'colorway')
        col.prop(s,'radius')
        col.prop(s,'tension')
        box = layout.box()
        box.label(text='CONSTRUCTION',icon='MOD_BUILD')
        if s.style == 'BRAID':
            box.prop(s,'strands')
            box.prop(s,'weave_turns')
            box.prop(s,'strand_radius')
        elif s.style == 'CORRUGATED':
            box.prop(s,'rib_turns')
        elif s.style == 'BUNDLE':
            box.prop(s,'wire_count')
            box.prop(s,'bundle_twist')
        else:
            box.prop(s,'bundle_twist',text='Stripe Revolutions')
        box.prop(s,'fittings')
        box.prop(s,'bands')
        quality = layout.box()
        quality.label(text='GEOMETRY QUALITY',icon='MOD_SUBSURF')
        quality.prop(s,'resolution')
        quality.prop(s,'sides')
        row = layout.row(align=True)
        row.operator(CF_OT_refresh.bl_idname,text='Refresh',icon='FILE_REFRESH')
        row.operator(CF_OT_bake.bl_idname,text='Bake Mesh Copy',icon='OUTLINER_OB_MESH')
        layout.label(text='Bake leaves the live rig intact.',icon='INFO')


def draw_add(self, context):
    if context.mode == 'OBJECT':
        self.layout.separator()
        self.layout.operator(CF_OT_create.bl_idname,icon='CURVE_PATH')


CLASSES = (CF_PG_settings, CF_OT_create, CF_OT_select_handle,
           CF_OT_refresh, CF_OT_bake, CF_PT_sidebar)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Object.cf_settings = PointerProperty(type=CF_PG_settings)
    bpy.types.VIEW3D_MT_add.append(draw_add)
    if changes_handler not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(changes_handler)
    if load_handler not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(load_handler)


def unregister():
    global _TIMER_ARMED
    if load_handler in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(load_handler)
    if changes_handler in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(changes_handler)
    if bpy.app.timers.is_registered(_flush_dirty):
        bpy.app.timers.unregister(_flush_dirty)
    _PENDING.clear()
    _TIMER_ARMED = False
    bpy.types.VIEW3D_MT_add.remove(draw_add)
    del bpy.types.Object.cf_settings
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


if __name__ == '__main__':
    register()
