# Multi-Pass Denoiser — v1.0.1

**Author:** Seth McLaughlin  
**Copyright:** © 2026 Seth McLaughlin  
**License:** MIT (`LICENSE`)  
**Supported targets:** Blender **5.2.x** and **5.3.x**.

## Install

This ZIP is a **legacy add-on package** (it uses `bl_info` rather than the
Blender Extensions manifest). Both target versions still support legacy ZIPs.

1. Blender → **Edit → Preferences → Add-ons**.
2. Open the **▼** menu near the top-right → **Install from Disk** (or the
   legacy add-on install command on the Extensions screen).
3. Select the intact `MultiPass_Denoiser_v1.0.1.zip` ZIP.
4. Enable **Multi-Pass Denoiser** in the Add-ons list.
5. In any **3D Viewport**, press **N** → **Denoiser** tab.

## Use

1. Click **Set Up Multi-Pass Denoiser**. If the scene uses EEVEE or Workbench,
   the add-on **switches it to Cycles** and records the previous engine.
2. It enables the active View Layer's **Denoising Data** render passes and
   disables Cycles' built-in *final render* denoising on that layer to avoid
   double denoising. Viewport denoising is not changed.
3. It inserts a named **OpenImageDenoise** compositor node and connects:
   - **Noisy Image → Image**, falling back to the raw **Image** output if
     Blender omits Noisy Image when built-in final denoising is disabled
   - **Denoising Albedo → Albedo**
   - **Denoising Normal → Normal**
4. Render normally with **F12**. Denoising runs as part of final compositing.
   You can open the compositor graph with the panel's **Open Compositor** button.
5. Adjust **HDR**, **Prefilter**, **Quality**, samples and adaptive sampling in
   the N-sidebar. **500 Quality** is a sample-count preset, *not* a minimum or
   a guarantee of better denoising. Other presets: Draft (64) and Balanced (256).
6. Click **Remove Setup** to remove the managed nodes and restore the original
   image connections and recorded engine/view-layer settings, when still valid.

## Existing compositor scenes

- Does **not** clear or rebuild an existing graph. It finds an existing
  **Group Input → …** image path (preferred in 5.3) or **Render Layers → …** path
  (preferred in 5.2) and inserts itself upstream of the existing processing.
- In **Blender 5.3** it modifies the **first scene compositor effect** so later
  effects keep receiving the processed result and retain their order.
- If the graph is shared by multiple users, the add-on makes a per-scene copy
  before editing it, and restores the original data-block on removal.
- If there is no safe image path to splice, setup returns a clear error and
  leaves the original compositor graph unchanged instead of guessing. Manually
  insert the denoise passes in a fully custom image/movie/EXR-based pipeline.
- Don't rename/delete the original shared compositor group, change the effect
  order, or manually delete the managed nodes between Setup and Remove Setup;
  these edits can invalidate automatic restoration.
- The setup is for the **active view layer**; it does not automatically denoise
  separately composited outputs from every view layer or arbitrary image files.

## Fix in v1.0.1

- Explicitly re-query Cycles render passes using `ViewLayer.update_render_passes()`
  after enabling Denoising Data and again after assigning the Render Layers
  node to its scene/view layer. A normal view-layer update is insufficient.
- Allow the original undenoised `Image` output when `Noisy Image` is absent
  **only when built-in render denoising has been disabled**. Denoising Albedo
  and Denoising Normal remain mandatory.
- Restore prior engine, pass settings and compositor state if setup cannot
  find the required guiding pass sockets.

## Verification status

The API migration is based on Blender's documented 5.2 and 5.3 interfaces:
`Scene.compositing_node_group` (5.2), `Scene.compositor_effects` (5.3),
Cycles denoising data, and Blender 5.x Denoise **input sockets** (not old-style
`node.prefilter` / `node.use_hdr` Python attributes).

Ten offline graph structural tests pass, including delayed render-pass refresh,
noisy-image fallback, existing graphs, and safe rollback after a missing pass.
The test environment does **not** contain a Blender executable, so these are
**not runtime-tested in Blender 5.2 or 5.3**. Final verification in those
Blender versions is still recommended before wider distribution.

## Licence note

This package is distributed under the MIT License as requested. Blender's
own official Extensions platform has additional GPL-related submission
requirements; this archive is provided for direct legacy add-on installation.
