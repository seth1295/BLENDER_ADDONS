"""Steel and corrugated cladding materials for Shed Builder.

Blender RNA input sockets are assigned only concrete, correctly typed Python
literals here. A Blender output socket is *always* passed explicitly to
node_tree.links.new. Shader errors never prevent actual shed geometry creation:
there is a basic metallic fallback with an in-sidebar warning.
"""
from pathlib import Path
import traceback
import bpy
from .assets import installed_maps


def cache_root(context=None):
    context = context or bpy.context
    pref = context.preferences.addons.get('corrugated_iron_generator')
    if pref and pref.preferences.cache_directory.strip():
        return str(Path(bpy.path.abspath(pref.preferences.cache_directory)).expanduser())
    return bpy.utils.user_resource('DATAFILES', path='corrugated_iron_generator/ambientCG', create=True)


def get_simple(name, rgba, metallic, roughness):
    mat = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    mat.use_nodes = True
    mat.diffuse_color = tuple(rgba)
    tree = mat.node_tree
    tree.nodes.clear()
    surface = tree.nodes.new('ShaderNodeBsdfPrincipled')
    surface.inputs['Base Color'].default_value = tuple(rgba)
    surface.inputs['Metallic'].default_value = float(metallic)
    surface.inputs['Roughness'].default_value = float(roughness)
    out = tree.nodes.new('ShaderNodeOutputMaterial')
    tree.links.new(surface.outputs['BSDF'], out.inputs['Surface'])
    return mat


def _node(tree, kind, x, y, label=''):
    node = tree.nodes.new(kind)
    node.location = (x, y)
    if label:
        node.label = label
    return node


def _math(tree, op, x, y, a_socket=None, a_value=0.0, b_socket=None, b_value=0.0):
    """Explicit socket versus constant arguments: no ambiguous bpy RNA typing."""
    node = _node(tree, 'ShaderNodeMath', x, y, op)
    node.operation = op
    if a_socket is not None:
        tree.links.new(a_socket, node.inputs[0])
    else:
        node.inputs[0].default_value = float(a_value)
    if b_socket is not None:
        tree.links.new(b_socket, node.inputs[1])
    else:
        node.inputs[1].default_value = float(b_value)
    return node.outputs[0]


def _mix_float(tree, factor, a_socket=None, a_value=0.0,
               b_socket=None, b_value=0.0, x=0, y=0):
    """Mix float PBR channels using arithmetic nodes, not overloaded Mix sockets."""
    inv = _math(tree, 'SUBTRACT', x-400, y, a_value=1., b_socket=factor)
    left = _math(tree, 'MULTIPLY', x-200, y+100,
                 a_socket=a_socket, a_value=a_value, b_socket=inv)
    right = _math(tree, 'MULTIPLY', x-200, y-100,
                  a_socket=b_socket, a_value=b_value, b_socket=factor)
    return _math(tree, 'ADD', x, y, a_socket=left, b_socket=right)


def _color_mix(tree, factor, first_socket, second_socket=None, second_color=None,
               x=0, y=0, label='Colour blend'):
    node = _node(tree, 'ShaderNodeMixRGB', x, y, label)
    node.blend_type = 'MIX'
    tree.links.new(factor, node.inputs[0])
    tree.links.new(first_socket, node.inputs[1])
    if second_socket is not None:
        tree.links.new(second_socket, node.inputs[2])
    else:
        node.inputs[2].default_value = tuple(second_color)
    return node.outputs['Color']


def _image(tree, path, uv_socket, x, y, is_color):
    if not path or not Path(path).is_file():
        return None
    try:
        image = bpy.data.images.load(str(path), check_existing=True)
        if not is_color:
            image.colorspace_settings.name = 'Non-Color'
    except (OSError, ValueError, RuntimeError):
        return None
    node = _node(tree, 'ShaderNodeTexImage', x, y, Path(path).name)
    node.image = image
    tree.links.new(uv_socket, node.inputs['Vector'])
    return node.outputs['Color']


def _asset(tree, asset_id, uv_socket, cache, resolution, y, rusty):
    maps = installed_maps(cache, asset_id, resolution)
    textures = {}
    for idx, key in enumerate(('Color', 'Roughness', 'Metalness', 'NormalGL', 'Displacement')):
        textures[key] = _image(tree, maps.get(key), uv_socket, -1600, y-220*idx, key=='Color')
    noise = _node(tree, 'ShaderNodeTexNoise', -1620, y-1260, 'Fine zinc / corrosion grain')
    noise.inputs['Scale'].default_value = 33.0 if rusty else 55.0
    noise.inputs['Detail'].default_value = 3.0
    tree.links.new(uv_socket, noise.inputs['Vector'])
    ramp = _node(tree, 'ShaderNodeValToRGB', -1400, y-1260, 'Offline steel / rust')
    colors = ((.11, .041, .018, 1), (.48, .19, .075, 1)) if rusty else (
             (.35, .39, .40, 1), (.67, .70, .69, 1))
    ramp.color_ramp.elements[0].color = colors[0]
    ramp.color_ramp.elements[1].color = colors[1]
    tree.links.new(noise.outputs['Fac'], ramp.inputs['Fac'])
    return dict(
        color=textures['Color'] if textures['Color'] is not None else ramp.outputs['Color'],
        rough_socket=textures['Roughness'], rough_value=.89 if rusty else .48,
        metal_socket=textures['Metalness'], metal_value=.05 if rusty else .82,
        height_socket=textures['Displacement'] if textures['Displacement'] is not None else noise.outputs['Fac'],
        normal_socket=textures['NormalGL'],
    )


def _build_cladding(root, context):
    s = root.sb_settings
    uid = root['shed_builder_uuid']
    name = 'SB | Cladding | ' + uid
    mat = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    mat.use_nodes = True
    mat.diffuse_color = (.55, .59, .61, 1)
    tree = mat.node_tree
    tree.nodes.clear()
    out = _node(tree, 'ShaderNodeOutputMaterial', 1500, 300, 'Surface and relief')
    bsdf = _node(tree, 'ShaderNodeBsdfPrincipled', 1270, 300, 'Galvanised sheet')
    tree.links.new(bsdf.outputs['BSDF'], out.inputs['Surface'])
    tex = _node(tree, 'ShaderNodeTexCoord', -2400, 700, 'Sheet UV')
    scale = _node(tree, 'ShaderNodeVectorMath', -2200, 700, 'Metres / tile')
    scale.operation = 'SCALE'
    scale.inputs[3].default_value = float(1.0 / max(.05, s.texture_tile_m))
    tree.links.new(tex.outputs['UV'], scale.inputs[0])
    uv = scale.outputs['Vector']
    cache = cache_root(context)
    base = _asset(tree, s.base_asset, uv, cache, s.texture_resolution, 1200, False)
    rust = _asset(tree, s.rust_asset, uv, cache, s.texture_resolution, -400, True)
    patches = _node(tree, 'ShaderNodeTexNoise', -1280, -2100, 'Oxidation clusters')
    patches.inputs['Scale'].default_value = float(s.rust_patch_size)
    patches.inputs['Detail'].default_value = 5.0
    tree.links.new(tex.outputs['Object'], patches.inputs['Vector'])
    threshold = .90 - .75 * s.rust_amount
    threshold_node = _node(tree, 'ShaderNodeValToRGB', -980, -2100, 'Rust islands')
    threshold_node.color_ramp.elements[0].position = max(0.0, threshold - .12)
    threshold_node.color_ramp.elements[1].position = min(1.0, threshold + .12)
    tree.links.new(patches.outputs['Fac'], threshold_node.inputs['Fac'])
    info = _node(tree, 'ShaderNodeObjectInfo', -970, -2400, 'Per sheet variation')
    variation = _math(tree, 'MULTIPLY', -720, -2400, a_socket=info.outputs['Random'], b_value=.26)
    coverage = _math(tree, 'MULTIPLY', -560, -2100,
                     a_socket=threshold_node.outputs['Color'], b_value=s.rust_amount)
    partial = _math(tree, 'ADD', -370, -2100, a_socket=coverage, b_socket=variation)
    partial = _math(tree, 'SUBTRACT', -180, -2100, a_socket=partial, b_value=.13)
    partial = _math(tree, 'MAXIMUM', 10, -2100, a_socket=partial, b_value=0)
    edge = _node(tree, 'ShaderNodeAttribute', -180, -2450, 'SB_RustEdges')
    edge.attribute_name = 'SB_RustEdges'
    edge_factor = _math(tree, 'MULTIPLY', 60, -2440,
                        a_socket=edge.outputs['Fac'], b_value=s.edge_rust*s.rust_amount)
    mask = _math(tree, 'ADD', 200, -2100, a_socket=partial, b_socket=edge_factor)
    mask = _math(tree, 'MINIMUM', 380, -2100, a_socket=mask, b_value=1)
    color = _color_mix(tree, mask, base['color'], second_socket=rust['color'],
                       x=330, y=980, label='Galvanised metal / rust')
    dust = _node(tree, 'ShaderNodeTexNoise', 130, -540, 'Surface dirt')
    dust.inputs['Scale'].default_value = 4.5
    tree.links.new(tex.outputs['Object'], dust.inputs['Vector'])
    dust_fac = _math(tree, 'MULTIPLY', 340, -540,
                     a_socket=dust.outputs['Fac'], b_value=s.dirt_amount)
    color = _color_mix(tree, dust_fac, color, second_color=(.13, .105, .082, 1),
                       x=600, y=900, label='Dirt deposits')
    tree.links.new(color, bsdf.inputs['Base Color'])
    rough = _mix_float(tree, mask, base['rough_socket'], base['rough_value'],
                       rust['rough_socket'], rust['rough_value'], x=620, y=440)
    rough = _math(tree, 'ADD', 800, 460, a_socket=rough, b_value=s.roughness_bias)
    rough = _math(tree, 'MAXIMUM', 930, 460, a_socket=rough, b_value=.03)
    rough = _math(tree, 'MINIMUM', 1050, 460, a_socket=rough, b_value=1)
    tree.links.new(rough, bsdf.inputs['Roughness'])
    metal = _mix_float(tree, mask, base['metal_socket'], base['metal_value'],
                       rust['metal_socket'], rust['metal_value'], x=700, y=140)
    tree.links.new(metal, bsdf.inputs['Metallic'])
    height = _mix_float(tree, mask, base['height_socket'], 0.,
                        rust['height_socket'], 0., x=680, y=-100)
    bump = _node(tree, 'ShaderNodeBump', 1040, -180, 'Small-scale bump (no geometry)')
    bump.inputs['Strength'].default_value = float(s.bump_strength)
    bump.inputs['Distance'].default_value = float(s.micro_height)
    tree.links.new(height, bump.inputs['Height'])
    normal_src = base['normal_socket'] if base['normal_socket'] is not None else rust['normal_socket']
    if normal_src is not None:
        normal = _node(tree, 'ShaderNodeNormalMap', 820, -380, 'ambientCG OpenGL normals')
        tree.links.new(normal_src, normal.inputs['Color'])
        tree.links.new(normal.outputs['Normal'], bump.inputs['Normal'])
    tree.links.new(bump.outputs['Normal'], bsdf.inputs['Normal'])
    if s.micro_detail == 'TRUE':
        displacement = _node(tree, 'ShaderNodeDisplacement', 1160, -450, 'Cycles surface displacement')
        displacement.inputs['Scale'].default_value = float(s.micro_height)
        displacement.inputs['Midlevel'].default_value = .5
        tree.links.new(height, displacement.inputs['Height'])
        tree.links.new(displacement.outputs[0], out.inputs['Displacement'])
    if hasattr(mat, 'displacement_method'):
        try:
            mat.displacement_method = 'BOTH' if s.micro_detail == 'TRUE' else 'BUMP'
        except (TypeError, ValueError):
            pass
    return mat


def get_cladding_material(root, context):
    """Never fail a geometry build because of a shader/API/texture error."""
    try:
        material = _build_cladding(root, context)
        if 'sb_material_warning' in root:
            del root['sb_material_warning']
        return material
    except Exception as exc:
        traceback.print_exc()
        root['sb_material_warning'] = '{}: {}'.format(type(exc).__name__, str(exc))[:240]
        # Even if a partially built shader exists, reset it to guaranteed
        # native Principled BSDF nodes so the shed remains usable.
        return get_simple('SB | Cladding | '+root['shed_builder_uuid'],
                          (.55, .59, .61, 1), .82, .48)


def get_materials(root, context):
    uid = root['shed_builder_uuid']
    return {
        'frame': get_simple('SB | Portal I-section | '+uid, (.29, .36, .40, 1), .85, .38),
        'secondary': get_simple('SB | Girts & Purlins | '+uid, (.45, .51, .53, 1), .8, .44),
        'brace': get_simple('SB | Bracing | '+uid, (.24, .30, .33, 1), .8, .50),
        'trim': get_simple('SB | Trim & Hinges | '+uid, (.56, .61, .63, 1), .8, .30),
        'cladding': get_cladding_material(root, context),
    }
