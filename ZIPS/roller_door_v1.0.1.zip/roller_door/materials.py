"""Independent shader generation, ambientCG CC0 material import and caching.

No third-party Blender extensions required. Network I/O only from the explicit
'Download selected ambientCG material' operator; no background requests.
"""

import io
import os
import re
import zipfile
from pathlib import Path
from urllib.request import Request, urlopen

import bpy


AMBIENTCG_ASSETS = {
    'Metal026': 'Metal026',
    'Metal062C': 'Metal062C',
    'Metal050C': 'Metal050C',
    'Metal059C': 'Metal059C',
}
URL_TEMPLATE = 'https://ambientcg.com/get?file={asset}_1K-JPG.zip'
MAX_ARCHIVE_BYTES = 100 * 1024 * 1024
SUFFIXES = ('.jpg', '.jpeg', '.png')


def texture_cache():
    return Path(bpy.utils.user_resource('DATAFILES', path='shed_roller_door/ambientcg', create=True))


def cached_files(asset):
    folder = texture_cache() / asset
    return list(folder.iterdir()) if folder.exists() else []


def get_texture_maps(asset):
    """Support multiple naming conventions across ambientCG zip generations."""
    result = {}
    for path in cached_files(asset):
        if not path.is_file() or path.suffix.lower() not in SUFFIXES:
            continue
        name = path.stem.lower().replace('-', '_')
        # New and older ambientCG archives are both accepted.
        if 'normalgl' in name or re.search(r'(?:^|_)normal(?:$|_)', name):
            result['normal'] = path
        elif 'roughness' in name:
            result['roughness'] = path
        elif 'metalness' in name or 'metallic' in name:
            result['metallic'] = path
        elif 'ambientocclusion' in name or re.search(r'(?:^|_)ao(?:$|_)', name):
            result['ao'] = path
        elif 'color' in name or 'albedo' in name or 'basecolor' in name:
            result['color'] = path
    return result


def download_asset(asset):
    if asset not in AMBIENTCG_ASSETS:
        raise ValueError('Unsupported ambientCG material ID')
    url = URL_TEMPLATE.format(asset=asset)
    req = Request(url, headers={
        'User-Agent': 'BlenderShedRollerDoor/1.0 (CC0 PBR material retrieval)',
        'Accept': 'application/zip,application/octet-stream,*/*',
    })
    with urlopen(req, timeout=60) as res:
        chunks = bytearray()
        while True:
            block = res.read(1024 * 512)
            if not block:
                break
            chunks.extend(block)
            if len(chunks) > MAX_ARCHIVE_BYTES:
                raise RuntimeError('ambientCG archive exceeds download size limit')
    with zipfile.ZipFile(io.BytesIO(chunks), 'r') as zf:
        folder = texture_cache() / asset
        folder.mkdir(parents=True, exist_ok=True)
        extracted = 0
        for entry in zf.infolist():
            name = Path(entry.filename).name
            if name.lower().endswith(SUFFIXES) and entry.file_size < 48 * 1024 * 1024:
                target = folder / name
                with zf.open(entry) as src, open(target, 'wb') as dest:
                    while True:
                        part = src.read(1024 * 256)
                        if not part:
                            break
                        dest.write(part)
                extracted += 1
        if extracted == 0:
            raise RuntimeError('No texture maps were found in the ambientCG archive')
    result = get_texture_maps(asset)
    if 'color' not in result and 'roughness' not in result:
        raise RuntimeError('Archive contained no usable base-colour or roughness PBR maps')
    return result


def _nodes(name):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    nodes.clear()
    out = nodes.new('ShaderNodeOutputMaterial')
    out.location = (660, 0)
    p = nodes.new('ShaderNodeBsdfPrincipled')
    p.location = (360, 0)
    mat.node_tree.links.new(p.outputs['BSDF'], out.inputs['Surface'])
    return mat, nodes, mat.node_tree.links, p


def coated_material(root, paint_color, roughness):
    name = root.get('rd_paint_material')
    if not name or name not in bpy.data.materials:
        name = 'RD - Coated Steel - ' + root.name
        root['rd_paint_material'] = name
    mat, nodes, links, p = _nodes(name)
    p.inputs['Base Color'].default_value = tuple(paint_color)
    p.inputs['Metallic'].default_value = 0.03
    p.inputs['Roughness'].default_value = roughness
    noise = nodes.new('ShaderNodeTexNoise')
    noise.location = (-620, -160)
    noise.inputs['Scale'].default_value = 175.0
    noise.inputs['Detail'].default_value = 3.0
    ramp = nodes.new('ShaderNodeValToRGB')
    ramp.location = (-350, -180)
    ramp.color_ramp.elements[0].position = 0.25
    ramp.color_ramp.elements[0].color = (0.25, 0.25, 0.25, 1)
    ramp.color_ramp.elements[1].position = 0.75
    ramp.color_ramp.elements[1].color = (0.62, 0.62, 0.62, 1)
    links.new(noise.outputs['Fac'], ramp.inputs['Fac'])
    bump = nodes.new('ShaderNodeBump')
    bump.location = (150, -220)
    bump.inputs['Strength'].default_value = 0.12
    bump.inputs['Distance'].default_value = 0.0003
    links.new(ramp.outputs['Color'], bump.inputs['Height'])
    links.new(bump.outputs['Normal'], p.inputs['Normal'])
    mat.diffuse_color = tuple(paint_color)
    return mat


def simple_material(name, color, metallic=0.0, roughness=0.45):
    mat = bpy.data.materials.get(name)
    if mat is not None:
        return mat
    mat, nodes, links, p = _nodes(name)
    p.inputs['Base Color'].default_value = color
    p.inputs['Metallic'].default_value = metallic
    p.inputs['Roughness'].default_value = roughness
    mat.diffuse_color = color
    return mat


def find_existing_material(asset):
    """Prefer a material the user has already packed from the Asset Browser."""
    for mat in bpy.data.materials:
        name = mat.name.casefold()
        if name == asset.casefold() or name.startswith(asset.casefold() + '_') or name.startswith(asset.casefold() + '.'):
            return mat
    return None


def _image_node(nodes, label, filepath, x, y, colour=False):
    node = nodes.new('ShaderNodeTexImage')
    node.label = label
    node.location = (x, y)
    image = bpy.data.images.load(os.fspath(filepath), check_existing=True)
    node.image = image
    if not colour:
        image.colorspace_settings.name = 'Non-Color'
    # Blender .blend remains self-contained, equivalent to Asset Browser 'Pack'.
    if not image.packed_file:
        image.pack()
    return node


def ambientcg_material(asset):
    constructed = bpy.data.materials.get('RD - ambientCG ' + asset)
    if constructed is not None:
        return constructed
    existing = find_existing_material(asset)
    if existing is not None:
        return existing
    maps = get_texture_maps(asset)
    if not maps:
        return None
    mat, nodes, links, p = _nodes('RD - ambientCG ' + asset)
    p.inputs['Metallic'].default_value = 0.7
    p.inputs['Roughness'].default_value = 0.55
    if 'color' in maps:
        colour = _image_node(nodes, 'ambientCG Base Color', maps['color'], -730, 300, True)
        if 'ao' in maps:
            ao = _image_node(nodes, 'ambientCG AO', maps['ao'], -730, 70)
            multiply = nodes.new('ShaderNodeMixRGB')
            multiply.blend_type = 'MULTIPLY'
            multiply.inputs['Fac'].default_value = 0.45
            multiply.location = (-240, 250)
            links.new(colour.outputs['Color'], multiply.inputs[1])
            links.new(ao.outputs['Color'], multiply.inputs[2])
            links.new(multiply.outputs['Color'], p.inputs['Base Color'])
        else:
            links.new(colour.outputs['Color'], p.inputs['Base Color'])
    for channel in ('roughness', 'metallic'):
        if channel in maps:
            n = _image_node(nodes, 'ambientCG ' + channel.title(), maps[channel], -650, -130 if channel == 'roughness' else -360)
            links.new(n.outputs['Color'], p.inputs['Roughness' if channel == 'roughness' else 'Metallic'])
    if 'normal' in maps:
        n = _image_node(nodes, 'ambientCG OpenGL Normal', maps['normal'], -680, -550)
        normal = nodes.new('ShaderNodeNormalMap')
        normal.location = (45, -380)
        normal.inputs['Strength'].default_value = 1.0
        links.new(n.outputs['Color'], normal.inputs['Color'])
        links.new(normal.outputs['Normal'], p.inputs['Normal'])
    return mat


def shared_hardware_materials():
    return {
        'steel': simple_material('RD - Galvanised Structural Steel', (0.43, 0.47, 0.47, 1), 0.8, 0.34),
        'black': simple_material('RD - Rubber / Black Seals', (0.028, 0.030, 0.030, 1), 0.0, 0.86),
        'dark': simple_material('RD - Dark Metal', (0.10, 0.12, 0.13, 1), 0.72, 0.38),
    }


def curtain_material(root):
    p = root.roller_door
    if p.material_override is not None:
        return p.material_override
    if p.finish.startswith('Metal'):
        mat = ambientcg_material(p.finish)
        if mat is not None:
            return mat
    if p.finish == 'GALVANISED':
        return simple_material('RD - Zinc Finish', (0.52, 0.56, 0.55, 1), 0.78, 0.42)
    return coated_material(root, p.paint_color, p.paint_roughness)
