"""Pure-Python building layout and clipping. Metres throughout.

Art/visualization only: spacing, section sizes and bracing are not engineering design.
"""
import math


def stations(span, maximum_spacing):
    if span <= 0 or maximum_spacing <= 0:
        raise ValueError('Span and spacing must be positive')
    bays = max(1, math.ceil(span / maximum_spacing))
    return [-span * .5 + span * (i / bays) for i in range(bays + 1)]


def roof_points(s):
    half = s.width / 2
    h = s.eave_height
    if s.roof_type == 'SKILLION':
        return [(-half, h), (half, h + math.tan(s.roof_pitch) * s.width)]
    if s.roof_type == 'GAMBREL':
        a = min(.8, max(.1, s.barn_break)) * half
        rise = math.tan(s.barn_lower_pitch) * a
        peak = h + rise + math.tan(s.roof_pitch) * (half - a)
        return [(-half, h), (-half + a, h + rise), (0, peak),
                (half - a, h + rise), (half, h)]
    rise = math.tan(s.roof_pitch) * half
    return [(-half, h), (0, h + rise), (half, h)]


def interpolate(points, x):
    """Linear interpolation; extrapolate outwards for roof overhang."""
    if x <= points[0][0]:
        a, b = points[0], points[1]
    elif x >= points[-1][0]:
        a, b = points[-2], points[-1]
    else:
        for i in range(len(points) - 1):
            a, b = points[i], points[i+1]
            if a[0] <= x <= b[0]:
                break
    return a[1] + (b[1] - a[1]) * (x - a[0]) / (b[0] - a[0])


def roof_height(s, x):
    return interpolate(roof_points(s), x)


def roof_with_overhang(s):
    pts = roof_points(s)
    x0 = -s.width * .5 - s.overhang
    x1 = s.width * .5 + s.overhang
    return [(x0, interpolate(pts, x0))] + pts[1:-1] + [(x1, interpolate(pts, x1))]


def purlin_points(s):
    pts = roof_with_overhang(s)
    out = []
    for i in range(len(pts) - 1):
        a, b = pts[i], pts[i+1]
        distance = math.hypot(b[0] - a[0], b[1] - a[1])
        intervals = max(1, math.ceil(distance / s.purlin_spacing))
        for j in range(intervals + 1):
            if i and j == 0:
                continue
            t = j / intervals
            out.append((a[0] * (1 - t) + b[0] * t,
                        a[1] * (1 - t) + b[1] * t))
    return out


def panels(a, b, nominal_width, pitch, overlap_waves=1):
    """Physical sheet edges in metres, overlapping integer full waves.

    Last sheet is cut exactly to the boundary (never stretched).
    """
    if b <= a or nominal_width <= pitch or pitch <= 0:
        raise ValueError('Invalid panel dimensions')
    full_waves = max(2, round(nominal_width / pitch))
    width = full_waves * pitch
    pitch_step = (full_waves - max(0, min(overlap_waves, full_waves - 1))) * pitch
    out = []
    start = a
    while start < b - 1e-8:
        end = min(start + width, b)
        out.append((start, end))
        if end >= b - 1e-8:
            break
        start += pitch_step
        if len(out) > 2000:
            raise ValueError('Exceeded 2000 cladding panels')
    return out


def door_geometry(s):
    """Door cutout in the chosen wall's horizontal axis, centered near offset."""
    span = s.width if s.door_wall in ('FRONT', 'BACK') else s.length
    width = min(s.door_width, max(.4, span - .5))
    middle = max(-span / 2 + width / 2 + .15,
                 min(span / 2 - width / 2 - .15, s.door_offset))
    a = middle - width / 2
    b = middle + width / 2
    highest = min(roof_height(s, -s.width/2), roof_height(s, s.width/2))
    height = min(s.door_height, highest - .25)
    return a, b, max(.5, height)


def wall_fragments(a, b, opening=None):
    """Split a horizontal wall sheet interval into unoccluded rectangles.

    Returns (left, right, bottomZ). Height above is supplied by roof function.
    """
    if not opening:
        return [(a, b, 0.0)]
    o0, o1, height = opening
    if b <= o0 or a >= o1:
        return [(a, b, 0.0)]
    out = []
    if a < o0:
        out.append((a, min(b, o0), 0.0))
    if b > o1:
        out.append((max(a, o1), b, 0.0))
    mid0, mid1 = max(a, o0), min(b, o1)
    if mid1 > mid0:
        out.append((mid0, mid1, height))
    return [(x, y, z) for x, y, z in out if y > x + 1e-8]


def profile_samples(a, b, wave_origin, pitch, style, samples=8):
    """Clip corrugations at cuts with coincident wave phase across fragments."""
    if b <= a:
        return []
    n = max(1, math.ceil((b - a) / pitch * samples))
    sampleset = {a + (b-a) * i/n for i in range(n + 1)}
    if style == 'TRAPEZOID':
        first = math.floor((a - wave_origin) / pitch) - 1
        last = math.ceil((b - wave_origin) / pitch) + 1
        for j in range(first, last+1):
            for t in (.15, .35, .65, .85):
                v = wave_origin + (j+t)*pitch
                if a < v < b:
                    sampleset.add(v)
    return sorted(sampleset)


def bounding_dimensions(s):
    roof = roof_with_overhang(s)
    return (s.width + 2*s.overhang, s.length + 2*s.overhang,
            max(z for x,z in roof))
