# Shed Roller Door — Blender add-on

**Free original add-on. No paid dependencies or external Blender extensions.**

## Install

In Blender: **Edit > Preferences > Add-ons > Install from Disk**, select `roller_door_v1.0.1.zip` and enable **Shed Roller Door**. Blender 4.3+ is targeted; geometry code and Blender APIs were checked against 4.5/5.2 documentation.

## Use

1. `Shift+A > Mesh > Roller Door` (or F3 search **Roller Door**).
2. Move, rotate, or scale the selected parent controller using `G`, `R`, `S`.
3. Press `N`, select the **Shed** tab. Select any part of the door to expose the same controller.
4. **Geometry & Mechanics** — adjust opening width/height, corrugation pitch/depth, steel thickness, drum, headroom, hardware and surface sampling. Changes regenerate the door.
5. **Door Animation** — adjust **Open** percentage directly, insert a keyframe or set frame range, interpolation, Open/Close and click **Generate Open/Close Animation**. Scrub the timeline: the curtain physically coils onto the fixed overhead axle.
6. **Steel & ambientCG PBR** — choose an ambientCG Metal preset, then press **Get ambientCG CC0 Textures** once. The add-on downloads 1K PBR maps directly from ambientCG and packs images into the .blend file. There is no separate importer dependency. Alternatively choose a material already imported through Blender's ambientCG Asset Browser in **Existing Material**.

## Animation / geometry

- One continuous corrugated sheet (not garage sectional panels) and double-sided thickness geometry.
- Persistent material-space UVs, sampled rounded ribs and flat pans, adjustable steel gauge.
- Fixed winding axle with growth of the wound outer radius, constant total curtain material length and a feed transition from vertical guides onto the spiral.
- Bottom reinforcement, rubber weather seal, guide channels with liners, bracket assemblies, drum wheels, helical springs, mounting bolts, optional cover, optional drive motor and optional curtain-edge wind-lock tabs.
- Winding shaft and drum wheels rotate in proportion to calculated winding angle. Keyframes drive the *actual mesh geometry*, not a disappearing/hidden curtain trick.
- `Render > Lock Interface` is enabled when a door is created, following Blender's advice for mesh modifications from frame-change handlers.

## Materials

Built-in coated/galvanised procedural materials let doors work offline. For actual ambientCG materials use the listed Metal026, Metal062C, Metal050C or Metal059C presets. These are CC0 assets, downloaded only by clicking the texture operator; the ZIP does **not** contain the material image archives.

The texture downloader uses ambientCG's established `get?file=..._1K-JPG.zip` endpoint and saves a reusable cache to Blender's user-data location, then packs images into the .blend. The add-on recognizes `_Color`, `_Roughness`, `_Metalness`, `_NormalGL` and `_AmbientOcclusion` maps where present.

## Design limitations

This is a kinematic geometric roller-door model, **not** a structural, spring-force or finite-element simulation. Drum/winding geometry is a controlled spiral approximation; it does not simulate plastic bending or contact response. Motor and springs are visual mechanical assemblies rather than force-driven components. Curtain headroom/guide placement can be fine-tuned to suit a shed design.

## Verification

The geometry core has 9 Python unit tests covering material arc-length conservation, coil-radius growth, fixed axle, winding continuity, termination at the drum core, surface topology/UVs, steel thickness, corrugation profile and several door sizes. Those tests passed. Blender was not installed in the build environment, so Blender runtime installation, registration, UI and animated rendering have **not** been executed here.

## Technical source references

- Real roller-door construction: B&D and Steel-Line free installation/technical guides.
- Blender APIs: `bpy.types.Mesh`, `bpy.app.handlers`, `bpy.types.bpy_struct.keyframe_insert`, action channel bags, Blender's add-on registration.
- ambientCG materials and licence: https://ambientcg.com / https://docs.ambientcg.com/license/

The add-on Python code is original. No paid/commercial roller-door generator code, assets or implementations are included.

## v1.0.1 fix

Corrected the builder/animation property mismatch (`open_fraction` was not registered; the defined `open_percentage` is 0–100). The renderer now consistently converts percentages to the 0–1 curve parameter.
