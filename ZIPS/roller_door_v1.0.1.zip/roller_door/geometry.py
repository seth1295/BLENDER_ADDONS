"""Independent geometric core for a continuous-curtain Australian roller door.

Units: metres, radians. Axis X, door vertical Z, coil in the Y/Z plane.
No bpy dependency: geometry and physical invariants can be unit-tested.
"""

from dataclasses import dataclass
import math


@dataclass(frozen=True)
class DoorSpec:
    width: float = 3.0
    height: float = 2.7
    profile_pitch: float = 0.084
    rib_width: float = 0.028
    rib_depth: float = 0.015
    sheet_thickness: float = 0.0005
    core_radius: float = 0.095
    coil_layer_pitch: float = 0.021
    seed_turns: float = 1.4
    headroom: float = 0.38
    opening_clearance: float = 0.06
    transition_length: float = 0.23
    samples_per_pitch: int = 20
    uv_metres_per_tile: float = 1.0


def validate(spec):
    if not (0.5 <= spec.width <= 20.0 and 0.5 <= spec.height <= 15.0):
        raise ValueError('Door width and height must be within supported bounds.')
    if not (0.03 <= spec.profile_pitch <= 0.30):
        raise ValueError('Corrugation pitch out of bounds.')
    if not (0.004 < spec.rib_width < spec.profile_pitch):
        raise ValueError('Rib width must be less than pitch.')
    if spec.coil_layer_pitch < spec.rib_depth + spec.sheet_thickness + 0.001:
        raise ValueError('Winding layer spacing must exceed the corrugation depth plus steel thickness.')
    if spec.core_radius <= 0 or spec.seed_turns < 1 or spec.samples_per_pitch < 6:
        raise ValueError('Invalid drum or sampling specification.')
    if spec.uv_metres_per_tile <= 0:
        raise ValueError('UV tiling must be positive.')


def roller_state(spec, opening):
    """Physical state. A small seed length remains on the drum when closed."""
    opening = max(0.0, min(1.0, float(opening)))
    rise = opening * max(0.0, spec.height - spec.opening_clearance)
    drum_z = spec.height + spec.headroom
    visible_length = drum_z - rise
    seed_length = 2.0 * math.pi * spec.core_radius * spec.seed_turns
    wound_length = seed_length + rise
    total_length = drum_z + seed_length
    outer_radius = math.sqrt(spec.core_radius ** 2 + spec.coil_layer_pitch * wound_length / math.pi)
    fully_open_radius = math.sqrt(
        spec.core_radius ** 2
        + spec.coil_layer_pitch * (seed_length + spec.height - spec.opening_clearance) / math.pi
    )
    # Fixed axle; the feed path bends to meet the variable outer coil radius.
    drum_y = -(fully_open_radius + 0.025)
    first_tangent_y = drum_y + outer_radius
    drum_rotation_angle = 2 * math.pi * (outer_radius - spec.core_radius) / spec.coil_layer_pitch
    return {
        'rise': rise,
        'drum_z': drum_z,
        'drum_y': drum_y,
        'feed_y': first_tangent_y,
        'outer_radius': outer_radius,
        'inner_radius': spec.core_radius,
        'visible_length': visible_length,
        'seed_length': seed_length,
        'wound_length': wound_length,
        'total_length': total_length,
        'drum_angle': drum_rotation_angle,
        'full_outer_radius': fully_open_radius,
    }


def path_point(spec, state, material_arc):
    """Point on the neutral path and positive YZ sheet normal.

    The path is parameterised by material arc from the bottom, not by world Z.
    Winding preserves the material coordinate across animation frames.
    """
    u = max(0.0, min(state['total_length'], material_arc))
    upright = state['visible_length']
    if u <= upright:
        y = 0.0
        slope = 0.0
        transition = min(spec.transition_length, upright * 0.65)
        if transition > 1e-9 and u > upright - transition:
            t = (u - (upright - transition)) / transition
            easing = t * t * (3.0 - 2.0 * t)
            y = state['feed_y'] * easing
            slope = state['feed_y'] * 6.0 * t * (1.0 - t) / transition
        z = state['rise'] + u
        ny, nz = 1.0, -slope
        nlength = math.hypot(ny, nz)
        return y, z, ny / nlength, nz / nlength

    w = u - upright
    r2 = state['outer_radius'] ** 2 - spec.coil_layer_pitch * w / math.pi
    r = math.sqrt(max(spec.core_radius ** 2, r2))
    theta = 2.0 * math.pi * (state['outer_radius'] - r) / spec.coil_layer_pitch
    y = state['drum_y'] + r * math.cos(theta)
    z = state['drum_z'] + r * math.sin(theta)
    # Normal from analytical trajectory tangent; positive points radially outward.
    dr_du = -spec.coil_layer_pitch / (2.0 * math.pi * r)
    dtheta_du = 1.0 / r
    ty = dr_du * math.cos(theta) - math.sin(theta)
    tz = dr_du * math.sin(theta) + math.cos(theta)
    norm = math.hypot(ty, tz)
    return y, z, tz / norm, -ty / norm


def rib_profile(spec, material_arc):
    """Smooth profile with flat pans, a rounded crest, and continuous flanks."""
    phase = ((material_arc / spec.profile_pitch) % 1.0 - 0.5) * spec.profile_pitch
    d = abs(phase)
    if d >= 0.5 * spec.rib_width:
        return 0.0
    return 0.5 * spec.rib_depth * (1.0 + math.cos(2.0 * math.pi * d / spec.rib_width))


def sample_rings(spec, opening):
    """Generate physical surface rings. Every material index remains stable.

    Each ring has four vertices: (front-left, front-right, rear-left, rear-right)
    front/rear are thickness offsets along the instantaneous sheet normal.
    """
    validate(spec)
    st = roller_state(spec, opening)
    pitch_step = spec.profile_pitch / spec.samples_per_pitch
    # At the core, <= 5.5 deg per segment for a smooth wound silhouette.
    angular_step = spec.core_radius * math.tau / 66.0
    count = max(16, math.ceil(st['total_length'] / min(pitch_step, angular_step)))
    verts = []
    uv_for_vertex = []
    half = spec.width * 0.5
    thickness = spec.sheet_thickness
    for i in range(count + 1):
        arc = st['total_length'] * i / count
        y, z, ny, nz = path_point(spec, st, arc)
        offset = rib_profile(spec, arc)
        # Material bump follows the same material coordinate on both sides.
        for side in (0.5 * thickness, -0.5 * thickness):
            surface_y = y + (offset + side) * ny
            surface_z = z + (offset + side) * nz
            verts.append((-half, surface_y, surface_z))
            verts.append((half, surface_y, surface_z))
            uv_for_vertex.append((0.0, arc / spec.uv_metres_per_tile))
            uv_for_vertex.append((spec.width / spec.uv_metres_per_tile, arc / spec.uv_metres_per_tile))
    faces = []
    material_ids = []
    for i in range(count):
        j = 4 * i
        # Correct external normals: front +Y, rear -Y, sides +/-X.
        faces.extend([
            (j, j + 4, j + 5, j + 1),
            (j + 2, j + 3, j + 7, j + 6),
            (j, j + 2, j + 6, j + 4),
            (j + 1, j + 5, j + 7, j + 3),
        ])
        material_ids.extend((0, 0, 1, 1))
    faces.append((0, 1, 3, 2))
    faces.append((4 * count, 4 * count + 2, 4 * count + 3, 4 * count + 1))
    material_ids.extend((1, 1))
    return verts, faces, material_ids, uv_for_vertex, st


def coil_collision_margin(spec):
    return spec.coil_layer_pitch - spec.rib_depth - spec.sheet_thickness
