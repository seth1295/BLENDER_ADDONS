"""PBR material builder: six ambientCG sets, localized rust, optional displacement."""
import os
import bpy

from .assets import installed_maps


def _node(tree, kind, x, y, name=None):
    n = tree.nodes.new(kind)
    n.location = (x, y)
    if name:
        n.label = name
    return n


def _value(tree, amount, x, y, name):
    n = _node(tree, 'ShaderNodeValue', x, y, name)
    n.outputs[0].default_value = amount
    return n.outputs[0]


def _color(tree, rgba, x, y, name):
    n = _node(tree, 'ShaderNodeRGB', x, y, name)
    n.outputs[0].default_value = rgba
    return n.outputs[0]


def _math(tree, op, lhs, rhs=None, x=0, y=0, label=None):
    n = _node(tree, 'ShaderNodeMath', x, y, label or op)
    n.operation = op
    if hasattr(lhs, 'is_output'):
        tree.links.new(lhs, n.inputs[0])
    else:
        n.inputs[0].default_value = lhs
    if rhs is not None:
        if hasattr(rhs, 'is_output'):
            tree.links.new(rhs, n.inputs[1])
        else:
            n.inputs[1].default_value = rhs
    return n.outputs[0]


def _mix(tree, factor, a, b, x, y, label, clamp=True):
    n = _node(tree, 'ShaderNodeMixRGB', x, y, label)
    n.blend_type = 'MIX'
    n.use_clamp = clamp
    for input_socket, value in ((n.inputs[0], factor), (n.inputs[1], a), (n.inputs[2], b)):
        if hasattr(value, 'is_output'):
            tree.links.new(value, input_socket)
        else:
            input_socket.default_value = value
    return n.outputs[0]


def _image(tree, path, vector, x, y, color=False, label=''):
    if not path or not os.path.isfile(path):
        return None
    try:
        image = bpy.data.images.load(path, check_existing=True)
        if not color:
            image.colorspace_settings.name = 'Non-Color'
    except (OSError, RuntimeError, ValueError):
        return None
    tex = _node(tree, 'ShaderNodeTexImage', x, y, label or os.path.basename(path))
    tex.image = image
    tex.extension = 'REPEAT'
    tree.links.new(vector, tex.inputs['Vector'])
    return tex.outputs['Color']


def _fallback_color(tree, tex_vector, x, y, is_rust):
    noise = _node(tree, 'ShaderNodeTexNoise', x, y, 'Procedural fallback (no download needed)')
    noise.inputs['Scale'].default_value = 70.0 if not is_rust else 35.0
    noise.inputs['Detail'].default_value = 3.0
    tree.links.new(tex_vector, noise.inputs['Vector'])
    ramp = _node(tree, 'ShaderNodeValToRGB', x + 240, y, 'Galvanized / rust fallback')
    if is_rust:
        ramp.color_ramp.elements[0].color = (0.105, 0.034, 0.016, 1)
        ramp.color_ramp.elements[1].color = (0.44, 0.135, 0.045, 1)
    else:
        ramp.color_ramp.elements[0].color = (0.37, 0.41, 0.43, 1)
        ramp.color_ramp.elements[1].color = (0.65, 0.68, 0.67, 1)
    tree.links.new(noise.outputs['Fac'], ramp.inputs[0])
    return ramp.outputs['Color'], noise.outputs['Fac']


def _pbr_set(tree, asset_id, vector, x, y, cache_root, is_rust, resolution):
    """Return outputs for colour, roughness, metalness, normal, height."""
    paths = installed_maps(cache_root, asset_id, resolution)
    maps = {}
    offsets = {
        'Color': 0, 'Roughness': -260, 'Metalness': -500,
        'NormalGL': -750, 'Displacement': -1030, 'AmbientOcclusion': -1240,
    }
    for kind, offset in offsets.items():
        maps[kind] = _image(tree, paths.get(kind), vector, x, y + offset,
                            color=(kind == 'Color'), label=asset_id + ' / ' + kind)
    fallback_color, fallback_height = _fallback_color(tree, vector, x, y - 1500, is_rust)
    color = maps['Color'] or fallback_color
    if maps['AmbientOcclusion']:
        ao = _node(tree, 'ShaderNodeMixRGB', x + 450, y - 190, 'Ambient occlusion')
        ao.blend_type = 'MULTIPLY'
        ao.inputs[0].default_value = 0.28
        tree.links.new(color, ao.inputs[1])
        tree.links.new(maps['AmbientOcclusion'], ao.inputs[2])
        color = ao.outputs[0]
    rough = maps['Roughness'] or _value(tree, 0.76 if is_rust else 0.43, x + 250, y - 460, 'Fallback roughness')
    metal = maps['Metalness'] or _value(tree, 0.07 if is_rust else 0.85, x + 250, y - 550, 'Fallback metalness')
    height = maps['Displacement'] or fallback_height
    normal = None
    if maps['NormalGL']:
        normal_node = _node(tree, 'ShaderNodeNormalMap', x + 280, y - 850, asset_id + ' / Tangent normal')
        tree.links.new(maps['NormalGL'], normal_node.inputs['Color'])
        normal = normal_node.outputs['Normal']
    return {'color': color, 'roughness': rough, 'metal': metal, 'normal': normal,
            'height': height, 'installed': bool(paths)}


def _edge_mask(tree, object_coords, width, length, x, y):
    separate = _node(tree, 'ShaderNodeSeparateXYZ', x, y, 'Local sheet coordinates')
    tree.links.new(object_coords, separate.inputs[0])
    abs_x = _math(tree, 'ABSOLUTE', separate.outputs['X'], x=x+210, y=y)
    abs_y = _math(tree, 'ABSOLUTE', separate.outputs['Y'], x=x+210, y=y-170)

    def edge_band(distance, half_size, band, nx, ny):
        mapping = _node(tree, 'ShaderNodeMapRange', nx, ny, 'Cut-edge corrosion band')
        mapping.clamp = True
        mapping.interpolation_type = 'SMOOTHSTEP'
        mapping.inputs['From Min'].default_value = max(0.0, half_size - band)
        mapping.inputs['From Max'].default_value = max(0.00001, half_size)
        mapping.inputs['To Min'].default_value = 0.0
        mapping.inputs['To Max'].default_value = 1.0
        tree.links.new(distance, mapping.inputs['Value'])
        return mapping.outputs['Result']

    x_edge = edge_band(abs_x, width * .5, 0.05, x + 420, y)
    y_edge = edge_band(abs_y, length * .5, 0.08, x + 420, y - 170)
    return _math(tree, 'MAXIMUM', x_edge, y_edge, x=x + 640, y=y-50, label='Sheet perimeter')


def _rust_coverage(tree, p, texcoords, x, y):
    macro = _node(tree, 'ShaderNodeTexNoise', x, y, 'Rust islands / breakup')
    macro.inputs['Scale'].default_value = p.rust_patch_scale
    macro.inputs['Detail'].default_value = 5.0
    macro.inputs['Roughness'].default_value = 0.72
    tree.links.new(texcoords.outputs['Object'], macro.inputs['Vector'])
    ramp = _node(tree, 'ShaderNodeValToRGB', x+230, y, 'Rust coverage threshold')
    threshold = 0.89 - 0.78 * p.rust_amount
    ramp.color_ramp.elements[0].position = max(0.0, threshold - 0.13)
    ramp.color_ramp.elements[1].position = min(1.0, threshold + 0.13)
    tree.links.new(macro.outputs['Fac'], ramp.inputs[0])
    edge = _edge_mask(tree, texcoords.outputs['Object'], p.width, p.length, x, y - 370)
    edge_rust = _math(tree, 'MULTIPLY', edge, p.edge_rust * 0.78, x=x + 880, y=y-360)
    joined = _math(tree, 'ADD', ramp.outputs['Color'], edge_rust, x=x + 1050, y=y-190)
    capped = _math(tree, 'MINIMUM', joined, 1.0, x=x + 1220, y=y-190)
    return _math(tree, 'MULTIPLY', capped, p.rust_amount, x=x + 1390, y=y-190)


def rebuild_material(obj, cache_root):
    p = obj.ci_iron
    if not p.is_sheet or obj.type != 'MESH':
        return
    # Alt+D linked duplicates need their own mesh datablock for per-sheet materials.
    if obj.data.users > 1:
        obj.data = obj.data.copy()
    old = obj.data.materials[0] if obj.data.materials else None
    if old and old.get('ci_generated') and old.users == 1:
        mat = old
    else:
        mat = bpy.data.materials.new('CI / Iron - ' + obj.name)
        mat['ci_generated'] = True
        if obj.data.materials:
            obj.data.materials[0] = mat
        else:
            obj.data.materials.append(mat)
    mat.use_nodes = True
    mat.diffuse_color = (0.52, 0.56, 0.57, 1)
    if hasattr(mat, 'displacement_method'):
        mat.displacement_method = 'BOTH' if p.displacement_mode == 'TRUE' else 'BUMP'
    elif hasattr(mat, 'cycles') and hasattr(mat.cycles, 'displacement_method'):
        mat.cycles.displacement_method = 'BOTH' if p.displacement_mode == 'TRUE' else 'BUMP'
    tree = mat.node_tree
    tree.nodes.clear()
    output = _node(tree, 'ShaderNodeOutputMaterial', 2350, 160, 'Material output')
    shader = _node(tree, 'ShaderNodeBsdfPrincipled', 2040, 260, 'Weathered sheet metal')
    tree.links.new(shader.outputs['BSDF'], output.inputs['Surface'])

    texcoords = _node(tree, 'ShaderNodeTexCoord', -2400, 650, 'Metre-based UVs / local position')
    uvscale = _node(tree, 'ShaderNodeVectorMath', -2160, 720, 'PBR tile scale')
    uvscale.operation = 'SCALE'
    uvscale.inputs[3].default_value = 1.0 / max(p.texture_scale, 0.01)
    tree.links.new(texcoords.outputs['UV'], uvscale.inputs[0])
    uv = uvscale.outputs['Vector']

    # Separate texture sets; can select any curated material for either slot.
    base = _pbr_set(tree, p.base_asset, uv, -1780, 980, cache_root, False, p.download_resolution)
    rust = _pbr_set(tree, p.rust_asset, uv, -1780, -1440, cache_root, True, p.download_resolution)
    mask = _rust_coverage(tree, p, texcoords, -1250, -3200)

    color = _mix(tree, mask, base['color'], rust['color'], 1250, 700, 'Rust albedo blend')
    # Dirt is a separate surface layer, not baked into metal/rust imagery.
    dirt_noise = _node(tree, 'ShaderNodeTexNoise', 350, -900, 'Dirt breakup')
    dirt_noise.inputs['Scale'].default_value = 4.2
    dirt_noise.inputs['Detail'].default_value = 3.0
    tree.links.new(texcoords.outputs['Object'], dirt_noise.inputs['Vector'])
    dirt_strength = _math(tree, 'MULTIPLY', dirt_noise.outputs['Fac'], p.dirt_amount,
                          x=760, y=-800, label='Dirt coverage')
    dust = _color(tree, (0.20, 0.16, 0.115, 1), 1010, -790, 'Dry dirt')
    color = _mix(tree, dirt_strength, color, dust, 1590, 750, 'Dirt tint')
    tree.links.new(color, shader.inputs['Base Color'])

    rough = _mix(tree, mask, base['roughness'], rust['roughness'], 1220, 300, 'Rust roughness blend')
    rough = _math(tree, 'ADD', rough, p.roughness_bias + p.dirt_amount * 0.2,
                  x=1570, y=330, label='Roughness offset')
    rough = _math(tree, 'MAXIMUM', rough, 0.025, x=1740, y=310)
    rough = _math(tree, 'MINIMUM', rough, 1.0, x=1880, y=310)
    tree.links.new(rough, shader.inputs['Roughness'])
    metal = _mix(tree, mask, base['metal'], rust['metal'], 1450, -80, 'Metalness blend')
    tree.links.new(metal, shader.inputs['Metallic'])

    # True geometric displacement requires render tessellation; normal/bump
    # is the cost-effective default and works in Eevee and Cycles.
    height = _mix(tree, mask, base['height'], rust['height'], 1180, -480, 'Combined micro height')
    bump = _node(tree, 'ShaderNodeBump', 1830, -280, 'Sub-millimetre relief (viewport safe)')
    bump.inputs['Strength'].default_value = p.bump_strength
    bump.inputs['Distance'].default_value = p.micro_height
    tree.links.new(height, bump.inputs['Height'])
    if base['normal'] and rust['normal']:
        normal = _mix(tree, mask, base['normal'], rust['normal'], 1490, -620, 'Normal map blend', clamp=False)
    else:
        normal = base['normal'] or rust['normal']
    if normal:
        tree.links.new(normal, bump.inputs['Normal'])
    tree.links.new(bump.outputs['Normal'], shader.inputs['Normal'])

    if p.displacement_mode == 'TRUE':
        disp = _node(tree, 'ShaderNodeDisplacement', 2020, -470, 'Cycles true height displacement')
        disp.inputs['Midlevel'].default_value = 0.5
        disp.inputs['Scale'].default_value = p.micro_height
        tree.links.new(height, disp.inputs['Height'])
        tree.links.new(disp.outputs[0], output.inputs['Displacement'])
    mat['ci_base_asset'] = p.base_asset
    mat['ci_rust_asset'] = p.rust_asset
    return mat
