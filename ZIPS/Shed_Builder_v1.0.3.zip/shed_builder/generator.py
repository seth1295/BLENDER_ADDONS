"""Non-destructive shed assembly in Blender collections, with independent door hinges.

All coordinates below are *shed root local*. Root can be moved/rotated using G/R,
without consulting the viewport or camera. Each rebuild affects tagged children only.
"""
import math
import uuid

import bpy
from mathutils import Vector

from .profile import profile_height
from .spec import (
    roof_points, roof_with_overhang, roof_height, purlin_points, stations,
    panels, wall_fragments, door_geometry, profile_samples,
)
from .materials import get_materials


ROOT_ID = 'shed_builder_uuid'
GEN_ID = 'shed_builder_generated'
ROLE_ID = 'shed_builder_role'
HINGE_ID = 'shed_builder_hinge'


def owner_root(obj):
    while obj:
        try:
            if obj.get(ROOT_ID) and obj.sb_settings.is_root:
                return obj
        except (AttributeError, ReferenceError):
            pass
        obj = obj.parent
    return None


def associated_objects(root):
    token = root.get(ROOT_ID)
    if not token:
        return []
    return [ob for ob in bpy.data.objects if ob.get('shed_builder_owner') == token]


def remove_object(ob):
    data = ob.data if ob.type == 'MESH' else None
    bpy.data.objects.remove(ob, do_unlink=True)
    if data and data.users == 0:
        bpy.data.meshes.remove(data)


def clean_generated(root):
    for ob in list(associated_objects(root)):
        if ob.get(GEN_ID):
            remove_object(ob)


def delete_shed(root):
    for ob in list(associated_objects(root)):
        if ob.get(GEN_ID):
            remove_object(ob)
    # Re-query instead of accessing invalid RNA pointers removed above.
    for ob in list(associated_objects(root)):
        remove_object(ob)
    groups = list(root.users_collection)
    bpy.data.objects.remove(root, do_unlink=True)
    for col in groups:
        if col.name in bpy.data.collections and not col.objects and col.users <= 1:
            bpy.data.collections.remove(col)


class ShedBuilder:
    def __init__(self, root, context):
        self.root = root
        self.s = root.sb_settings
        self.token = root[ROOT_ID]
        self.collection = root.users_collection[0]
        self.materials = get_materials(root, context)
        self.parts = 0
        self.sheet_count = 0
        self.tris = 0

    def new_obj(self, name, verts, faces, uv=None, mat='frame', role='FRAME',
                parent=None, smooth=False, edge_mask=None):
        if not verts or not faces:
            return None
        mesh = bpy.data.meshes.new('SB | ' + name)
        mesh.from_pydata(verts, [], faces)
        mesh.update()
        if uv:
            layer = mesh.uv_layers.new(name='Metre UV')
            for face in mesh.polygons:
                for li in face.loop_indices:
                    layer.data[li].uv = uv[mesh.loops[li].vertex_index]
        if edge_mask and len(edge_mask)==len(verts):
            attribute=mesh.attributes.new(name='SB_RustEdges', type='FLOAT', domain='POINT')
            for i,value in enumerate(edge_mask):
                attribute.data[i].value=value
        for face in mesh.polygons:
            face.use_smooth = smooth
        material = self.materials.get(mat)
        if material:
            mesh.materials.append(material)
        ob = bpy.data.objects.new(name, mesh)
        self.collection.objects.link(ob)
        ob.parent = parent or self.root
        ob[GEN_ID] = True
        ob['shed_builder_owner'] = self.token
        ob[ROLE_ID] = role
        self.parts += 1
        self.tris += len(faces) * 2
        if role in ('CLADDING', 'DOOR_PANEL'):
            if self.s.micro_detail == 'TRUE':
                # Render subdivision happens on the sheet SURFACE, then Solidify.
                # For dense roofs true displacement costs memory; bump is default.
                subdiv = ob.modifiers.new('Render-only micro tessellation', 'SUBSURF')
                subdiv.subdivision_type = 'SIMPLE'
                subdiv.levels = 0
                subdiv.render_levels = self.s.render_subdivision
                subdiv.show_viewport = False
                subdiv.show_render = True
            if self.s.sheet_thickness > 0:
                solid = ob.modifiers.new('Sheet gauge', 'SOLIDIFY')
                solid.thickness = self.s.sheet_thickness
                solid.offset = -1.0
                solid.show_viewport = True
            if role == 'CLADDING':
                ob.hide_set(not self.s.show_cladding)
            self.sheet_count += 1
        return ob

    @staticmethod
    def crosssection(section, width, height):
        w, h = width*.5, height*.5
        thickness = max(.005, min(width, height) * .16)
        t = thickness
        if section == 'I':
            return [(-w,-h),(w,-h),(w,-h+t),(t/2,-h+t),
                    (t/2,h-t),(w,h-t),(w,h),(-w,h),
                    (-w,h-t),(-t/2,h-t),(-t/2,-h+t),(-w,-h+t)]
        if section == 'C':
            return [(-w,-h),(w,-h),(w,-h+t),(-w+t,-h+t),
                    (-w+t,h-t),(w,h-t),(w,h),(-w,h)]
        return [(-w,-h),(w,-h),(w,h),(-w,h)]

    def member(self, name, a, b, width, height, section='BOX', mat='frame', parent=None, role='FRAME'):
        a, b = Vector(a), Vector(b)
        delta = b - a
        dist = delta.length
        if dist < .001:
            return None
        section_points = self.crosssection(section, width, height)
        n = len(section_points)
        verts = [(x,y,-dist*.5) for x,y in section_points] + [(x,y,dist*.5) for x,y in section_points]
        faces = [tuple(reversed(range(n))), tuple(range(n, 2*n))]
        faces += [(i, (i+1)%n, (i+1)%n+n, i+n) for i in range(n)]
        ob = self.new_obj(name, verts, faces, mat=mat, role=role, parent=parent)
        if ob:
            ob.location = (a+b)*.5
            ob.rotation_mode = 'QUATERNION'
            ob.rotation_quaternion = delta.to_track_quat('Z','Y')
        return ob

    @staticmethod
    def wall_point(s, wall, u, z=0, out=0.0):
        if wall == 'FRONT':
            return (u, -s.length*.5 - out, z)
        if wall == 'BACK':
            return (u, s.length*.5 + out, z)
        if wall == 'LEFT':
            return (-s.width*.5 - out, u, z)
        return (s.width*.5 + out, u, z)

    @staticmethod
    def wall_dir(wall):
        return (1,0,0) if wall in ('FRONT','BACK') else (0,1,0)

    @staticmethod
    def wall_normal(wall):
        return {'FRONT':(0,-1,0),'BACK':(0,1,0),
                'LEFT':(-1,0,0),'RIGHT':(1,0,0)}[wall]

    def wall_cladding(self, wall, u0, u1, wave_origin, zbottom, ztop_fn,
                      name, parent=None, hinge_origin=None):
        s = self.s
        samples = profile_samples(u0, u1, wave_origin, s.sheet_pitch, s.sheet_profile, s.samples_per_wave)
        vertices, faces, uv, rust_edges = [], [], [], []
        travel = 0.0
        last = None
        outward = self.wall_normal(wall)
        for u in samples:
            wave = profile_height((u - wave_origin) / s.sheet_pitch, s.sheet_depth, s.sheet_profile)
            # External face is outside the primary frame. Thickness projects inwards.
            base = self.wall_point(s, wall, u, 0, .115 + wave)
            ztop = max(zbottom + .001, ztop_fn(u))
            if last:
                travel += math.hypot(u-last[0],wave-last[1])
            for z in (zbottom, ztop):
                pt = (base[0],base[1],z)
                if hinge_origin is not None:
                    pt = tuple(pt[i]-hinge_origin[i] for i in range(3))
                vertices.append(pt)
                uv.append((travel,z))
                rust_edges.append(max(0.,1. - min(u-u0,u1-u)/.06))
            last=(u,wave)
        flipped = wall in ('BACK','LEFT')
        for i in range(len(samples)-1):
            j=i*2
            quad = (j,j+2,j+3,j+1)
            faces.append(tuple(reversed(quad)) if flipped else quad)
        return self.new_obj(name,vertices,faces,uv,mat='cladding',role='DOOR_PANEL' if parent else 'CLADDING',
                            parent=parent, smooth=s.sheet_profile=='ROUND', edge_mask=rust_edges)

    def roof_cladding(self, start, end, y0, y1, sheet_origin, name):
        s=self.s
        (x0,z0),(x1,z1)=start,end
        dx,dz=x1-x0,z1-z0
        length=math.hypot(dx,dz)
        # Outward roof normal, perpendicular to x-z roof segment.
        nx,nz=-dz/length,dx/length
        ys=profile_samples(y0,y1,sheet_origin,s.sheet_pitch,s.sheet_profile,s.samples_per_wave)
        vertices,faces,uv,rust_edges=[],[],[],[]
        travel=0
        previous=None
        for y in ys:
            w=profile_height((y-sheet_origin)/s.sheet_pitch,s.sheet_depth,s.sheet_profile)
            if previous:
                travel+=math.hypot(y-previous[0],w-previous[1])
            for t in (0,1):
                x=x0+dx*t+nx*(.10+w)
                z=z0+dz*t+nz*(.10+w)
                vertices.append((x,y,z))
                uv.append((travel,length*t))
                rust_edges.append(max(0.,1.-min(y-y0,y1-y)/.06))
            previous=(y,w)
        for i in range(len(ys)-1):
            j=2*i
            faces.append((j+1,j+3,j+2,j)) # y cross x yields negative z; flip upwards.
        return self.new_obj(name,vertices,faces,uv,mat='cladding',role='CLADDING',smooth=s.sheet_profile=='ROUND',edge_mask=rust_edges)

    def _roof_frame(self):
        s=self.s
        ys=stations(s.length,s.bay_spacing)
        points=roof_points(s)
        for bi,y in enumerate(ys):
            for side,x in (('Left',-s.width*.5),('Right',s.width*.5)):
                self.member(f'Portal {bi+1:02} | {side} column', (x,y,.02), (x,y,roof_height(s,x)-.02),
                            .22,.18,'I')
            for ri in range(len(points)-1):
                a,b=points[ri],points[ri+1]
                self.member(f'Portal {bi+1:02} | Rafter {ri+1}',(a[0],y,a[1]-.07),(b[0],y,b[1]-.07),
                            .20,.17,'I')
            if s.bracing:
                # Decorative knee braces, attached to columns and rafters.
                for x, sign in ((-s.width*.5,1),(s.width*.5,-1)):
                    inward=x + sign*min(.75,s.width*.16)
                    top=roof_height(s,inward)-.08
                    self.member(f'Portal {bi+1:02} | Knee brace',
                                (x,y,s.eave_height-.85),(inward,y,top-.02),
                                .065,.07,'BOX',mat='brace')
        for pi,(x,z) in enumerate(purlin_points(s)):
            self.member(f'Roof purlin {pi+1:02}',(x,-s.length*.5,z+.025),
                        (x,s.length*.5,z+.025),.11,.085,'C',mat='secondary')
        if s.bracing and len(ys)>1:
            # First roof bay has two longitudinal-plane diagonal ties.
            y0,y1=ys[0],ys[1]
            xspan=min(2.4,s.width*.3)
            xL=-s.width*.5+.7
            xR=min(s.width*.5-.7,xL+xspan)
            self.member('Roof plane wind brace 1',(xL,y0,roof_height(s,xL)+.015),
                        (xR,y1,roof_height(s,xR)+.015),.03,.03,'BOX',mat='brace')
            self.member('Roof plane wind brace 2',(xR,y0,roof_height(s,xR)+.015),
                        (xL,y1,roof_height(s,xL)+.015),.03,.03,'BOX',mat='brace')

    def _wall_frame(self, wall, opening):
        s=self.s
        span=s.width if wall in ('FRONT','BACK') else s.length
        umin,umax=-span*.5,span*.5
        top_fn=(lambda u: roof_height(s,u)) if wall in ('FRONT','BACK') else (
            lambda u: roof_height(s, -s.width*.5 if wall=='LEFT' else s.width*.5))
        max_height=min(top_fn(umin),top_fn(umax))
        count=max(1,math.ceil(max_height/s.girt_spacing))
        heights=[max_height*i/count for i in range(1,count)]
        for z in heights:
            intervals=[(umin,umax)]
            if opening and z < opening[2]:
                a,b,_=opening
                intervals=[(umin,a),(b,umax)]
            for start,end in intervals:
                if end > start+.03:
                    self.member(f'{wall} | Girt z{z:.2f}',
                                self.wall_point(s,wall,start,z,.035),
                                self.wall_point(s,wall,end,z,.035),
                                .10,.085,'C',mat='secondary')
        if wall in ('FRONT','BACK'):
            # Light infill studs on gable walls. Do not block the doorway.
            for i,u in enumerate(stations(span,1.8)):
                if abs(u) >= span/2-.05:
                    continue
                z0=0.0
                if opening and opening[0]-.04 <= u <= opening[1]+.04:
                    z0=opening[2]+.06
                z1=top_fn(u)-.08
                if z1>z0+.08:
                    self.member(f'{wall} | End stud {i+1}',
                                self.wall_point(s,wall,u,z0,.03),
                                self.wall_point(s,wall,u,z1,.03),
                                .085,.075,'C',mat='secondary')
        if opening:
            a,b,h=opening
            for u,name in ((a,'Left jamb'),(b,'Right jamb')):
                self.member(f'{wall} | Door {name}',
                            self.wall_point(s,wall,u,.02,.05),
                            self.wall_point(s,wall,u,h+.15,.05),.10,.09,'BOX')
            self.member(f'{wall} | Door header',
                        self.wall_point(s,wall,a,h+.09,.05),
                        self.wall_point(s,wall,b,h+.09,.05),.12,.10,'BOX')
        if s.bracing and wall in ('LEFT','RIGHT') and not opening:
            ys=stations(s.length,s.bay_spacing)
            if len(ys)>1:
                a,b=ys[0],ys[1]
                zhigh=min(roof_height(s,-s.width*.5 if wall=='LEFT' else s.width*.5)-.3,3.2)
                for u0,z0,u1,z1 in ((a,.30,b,zhigh),(a,zhigh,b,.30)):
                    self.member(f'{wall} | X brace',self.wall_point(s,wall,u0,z0,.013),
                                self.wall_point(s,wall,u1,z1,.013),.034,.034,'BOX',mat='brace')

    def _wall_sheets(self,wall,opening):
        s=self.s
        span=s.width if wall in ('FRONT','BACK') else s.length
        if wall in ('FRONT','BACK'):
            top=lambda u: roof_height(s,u)-.01
        else:
            x=-s.width*.5 if wall=='LEFT' else s.width*.5
            top=lambda u: roof_height(s,x)-.01
        for pi,(start,end) in enumerate(panels(-span*.5,span*.5,s.sheet_width,s.sheet_pitch,s.overlap_waves)):
            for fi,(a,b,z0) in enumerate(wall_fragments(start,end,opening)):
                if min(top(a),top(b)) <= z0 + .01:
                    continue
                self.wall_cladding(wall,a,b,start,z0,top,
                                   f'{wall} | Sheet {pi+1:02} / part {fi+1}')

    def _roof_sheets(self):
        s=self.s
        r=roof_with_overhang(s)
        sheet_bands=panels(-s.length*.5-s.overhang,s.length*.5+s.overhang,
                           s.sheet_width,s.sheet_pitch,s.overlap_waves)
        for ri in range(len(r)-1):
            for pi,(y0,y1) in enumerate(sheet_bands):
                self.roof_cladding(r[ri],r[ri+1],y0,y1,y0,
                                   f'Roof face {ri+1} | Sheet {pi+1:02}')
        if len(r)>2:
            for i,(x,z) in enumerate(r[1:-1]):
                self.member(f'Roof ridge / fold cap {i+1}',(x,-s.length*.5-s.overhang,z+.11),
                            (x,s.length*.5+s.overhang,z+.11),.15,.035,'BOX',mat='trim')
        for x,z in (r[0],r[-1]):
            self.member('Eave edge trim',(x,-s.length*.5-s.overhang,z+.09),
                        (x,s.length*.5+s.overhang,z+.09),.08,.04,'BOX',mat='trim')

    def _hinge(self,hinge_key,location):
        for ob in associated_objects(self.root):
            if ob.get(HINGE_ID) == hinge_key:
                ob.location=location
                return ob
        ob=bpy.data.objects.new(f'Door hinge pivot | {hinge_key}',None)
        self.collection.objects.link(ob)
        ob.parent=self.root
        ob.location=location
        ob.empty_display_type='ARROWS'
        ob.empty_display_size=.28
        ob.show_in_front=True
        ob[HINGE_ID]=hinge_key
        ob['shed_builder_owner']=self.token
        return ob

    def _door_leaf(self,wall, a,b,h,hinge_key,hinge_at,reverse=False):
        s=self.s
        hinge_origin=self.wall_point(s,wall,hinge_at,0,.128)
        hinge=self._hinge(hinge_key,hinge_origin)
        self.wall_cladding(wall,a,b,a,.08,lambda u:h-.06,
                           f'Door | {hinge_key} corrugated leaf',parent=hinge,hinge_origin=hinge_origin)
        def pt(u,z,dist=.12):
            base=self.wall_point(s,wall,u,z,dist)
            return tuple(base[i]-hinge_origin[i] for i in range(3))
        for u,label in ((a,'Left'),(b,'Right')):
            self.member(f'Door | {hinge_key} {label} stile',pt(u,.04),pt(u,h-.04),
                        .07,.06,'BOX',mat='secondary',parent=hinge,role='DOOR_FRAME')
        for z,label in ((.05,'Bottom'),(h-.05,'Top')):
            self.member(f'Door | {hinge_key} {label} rail',pt(a,z),pt(b,z),
                        .075,.06,'BOX',mat='secondary',parent=hinge,role='DOOR_FRAME')
        self.member(f'Door | {hinge_key} diagonal',pt(a,.15),pt(b,h-.15),
                    .047,.042,'BOX',mat='brace',parent=hinge,role='DOOR_FRAME')
        for z in (.25,h*.5,h-.25):
            # Hinge barrel / pin is centered on the actual pivot axis.
            self.member(f'Door | {hinge_key} hinge barrel',(.0,.0,z-.07),(.0,.0,z+.07),
                        .065,.065,'BOX',mat='trim',parent=hinge,role='HINGE_PART')
        handle_u=b-.12 if hinge_at==a else a+.12
        self.member(f'Door | {hinge_key} pull handle',pt(handle_u,h*.5-.10,.20),
                    pt(handle_u,h*.5+.10,.20),.045,.045,'BOX',mat='trim',parent=hinge,role='HINGE_PART')
        # An unmodified hinge stays shut. Its actual Blender Z rotation can be
        # keyframed or moved manually, and is retained through root regeneration.
        return hinge

    def _doors(self):
        s=self.s
        if s.door_mode == 'NONE':
            self._remove_unused_hinges(set())
            return
        a,b,h=door_geometry(s)
        wall=s.door_wall
        if s.door_mode=='DOUBLE':
            middle=(a+b)*.5
            self._door_leaf(wall,a,middle,h,'LEFT',a)
            self._door_leaf(wall,middle,b,h,'RIGHT',b)
            valid={'LEFT','RIGHT'}
        else:
            key=s.hinge_side
            self._door_leaf(wall,a,b,h,key,a if key=='LEFT' else b)
            valid={key}
        self._remove_unused_hinges(valid)

    def _remove_unused_hinges(self,valid):
        for ob in list(associated_objects(self.root)):
            if ob.get(HINGE_ID) and ob.get(HINGE_ID) not in valid:
                # Generated children were already deleted by clean_generated.
                remove_object(ob)

    def build(self):
        s=self.s
        clean_generated(self.root)
        self._roof_frame()
        enabled={
            'FRONT':s.front_wall, 'BACK':s.back_wall,
            'LEFT':s.left_wall, 'RIGHT':s.right_wall,
        }
        wall_of_door=s.door_wall if s.door_mode!='NONE' else None
        for wall,on in enabled.items():
            # Do not cut panels for door if cladding on this wall is disabled.
            opening=door_geometry(s) if wall==wall_of_door else None
            if on:
                self._wall_frame(wall,opening)
                self._wall_sheets(wall,opening)
        self._roof_sheets()
        if enabled.get(wall_of_door,False):
            self._doors()
        else:
            self._remove_unused_hinges(set())
        self.root['sb_parts']=self.parts
        self.root['sb_sheets']=self.sheet_count
        self.root['sb_base_tris_approx']=self.tris
        return self.parts


def rebuild(root,context=None):
    if not root or not root.get(ROOT_ID):
        return 0
    return ShedBuilder(root,context or bpy.context).build()


def toggle_cladding(root):
    for ob in associated_objects(root):
        if ob.get(ROLE_ID)=='CLADDING':
            try:
                ob.hide_set(not root.sb_settings.show_cladding)
            except RuntimeError:
                pass


def swing_doors(root,amount):
    """amount: signed opening in radians, positive means swing outside."""
    s=root.sb_settings
    outward={ 'FRONT':(0,-1), 'BACK':(0,1), 'LEFT':(-1,0), 'RIGHT':(1,0) }[s.door_wall]
    tangent=(1,0) if s.door_wall in ('FRONT','BACK') else (0,1)
    # 90 deg rotation maps tangent to (-ty,tx). Dot with outward.
    sign=1 if (-tangent[1]*outward[0]+tangent[0]*outward[1])>=0 else -1
    for ob in associated_objects(root):
        side=ob.get(HINGE_ID)
        if side:
            ob.rotation_mode='XYZ'
            ob.rotation_euler.z=amount * sign * (1 if side=='LEFT' else -1)


def create_root(context,preset='GABLE'):
    uid=uuid.uuid4().hex[:12]
    col=bpy.data.collections.new('Shed | '+uid)
    context.scene.collection.children.link(col)
    root=bpy.data.objects.new('Shed Builder | Main Controller',None)
    col.objects.link(root)
    root.empty_display_type='CUBE'
    root.empty_display_size=.45
    root.show_in_front=True
    root[ROOT_ID]=uid
    root['sb_initializing']=True
    root.sb_settings.is_root=True
    root.matrix_world=context.scene.cursor.matrix.copy()
    s=root.sb_settings
    if preset=='OPEN':
        s.front_wall=False
        s.left_wall=False
        s.back_wall=True
        s.right_wall=True
        s.door_mode='NONE'
        s.width=12
        s.length=18
        s.eave_height=5
    elif preset=='SKILLION':
        s.roof_type='SKILLION'
        s.width=6
        s.length=9
    elif preset=='BARN':
        s.roof_type='GAMBREL'
        s.width=9
        s.length=12
    if 'sb_initializing' in root:
        del root['sb_initializing']
    for ob in context.selected_objects:
        ob.select_set(False)
    root.select_set(True)
    context.view_layer.objects.active=root
    try:
        rebuild(root,context)
    except Exception:
        # An add operator must be atomic. Before v1.0.1, material failures left
        # a fresh empty shed and an orphaned collection on each failed attempt.
        try:
            delete_shed(root)
        except Exception:
            pass  # Preserve the original build exception and traceback.
        raise
    return root
