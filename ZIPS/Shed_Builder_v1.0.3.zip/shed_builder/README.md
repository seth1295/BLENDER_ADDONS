# Shed Builder — Steel Portal Frames & Corrugated Cladding

**Blender 4.2+** · v1.0.3 · legacy-compatible Python add-on (ZIP install)

## Install

1. In Blender, open Preferences → Add-ons / Extensions → **Install from Disk** (wording differs by version).
2. Select `Shed_Builder_v1.0.3.zip` and enable **Shed Builder - Portal Frames & Corrugated Cladding**.
3. In the 3D View, press **Shift+A → Shed Builder → Enclosed gable shed**.
4. Press **N**, open the **Shed Builder** tab. The controller is the small cube-shaped Empty at the 3D cursor. Move it with **G** or rotate with **R**, independent of camera orientation.

The selected controller **or any of its child components** displays the controls in the N-sidebar.

## Presets

- **Enclosed gable shed**: two-slope roof, all four walls, large double swinging doors.
- **Open-bay farm shed**: exposed portal frames, two walls, no doors. Toggle any wall on or off.
- **Mono-pitch shed**: single-slope roof and fully enclosed sides.
- **Barn / gambrel shed**: four roof slopes, enclosed sides and hinged doors.

All use the same procedural system. Change design, span, length, roof pitch, overhang, portal-bay spacing, wall-girt and roof-purlin spacing, or wall visibility in the N-sidebar. **Disable automatic updates** for very large buildings, then click **Rebuild Shed**.

## Steel framework

Individual frame objects include I-section columns and rafters, C-section secondary purlins/girts, portal knee braces, optional side X bracing and simple ridge/eave trims. Framing is separate from cladding. **Show cladding in viewport** toggles the enclosing sheets off without hiding the frame or changing renders.

**Important**: Sections, connections, bracing positions, spacing and dimensions are illustrative for *3D modelling only*. The generator does not calculate loads, verify Australian Standards or produce buildable structural engineering plans.

## Corrugated steel sheets

Low-polygon round or trapezoidal corrugations have real silhouettes. Sheets repeat by a **whole number of wave pitches** with a configurable side-lap; last sheets are clipped, never stretched. Wall sheets follow the gable/barn rake and are split around door openings. Roof ridges/folds and overhangs follow the chosen roof profile.

The default material uses bump/normal relief for scratches and rust pitting, so microdetail **does not require thousands of surface triangles**. `True Cycles displacement` is optional; it adds render-only subdivision and increases render-time polygon counts.

## Hinged doors

Set **Single / Double**, door wall, width, height and horizontal offset. The cladding and girts are cut around the opening and jamb/header framing is added automatically.

Each door leaf is parented to a separate named **Door hinge pivot** Empty. Click **Closed / 45° / 90° / 120°** in the sidebar, or **Select Hinge → R Z** to swing the door. Animate the hinge Empty's Z rotation with Blender's native keyframes. Hinge pivots and their animation data survive rebuilding the generated frame and cladding. Generated door-panel/frame meshes are replaced when rebuilding.

## ambientCG textures

Six selectable CC0 assets: `Metal026`, `Metal062C`, `Metal050C`, `Metal059C`, `Metal020`, `Rust002`. Base and corrosion textures can be chosen independently. Rust coverage, cut-edge weathering, dirt, roughness, texture size, bump and detail height are adjustable.

The Blender shader is usable offline with its procedural galvanized/rust fallback. For photographs and genuine scanned materials, use the **Download** buttons in the sidebar or **Import ambientCG ZIP**. The materials use the same default texture cache as the separate Corrugated Iron Generator v1.0 add-on, so previously downloaded assets are reused. If that add-on uses a custom cache folder, Shed Builder reads it where possible.

Textures are not bundled in the add-on ZIP. Official source: https://ambientcg.com and https://ambientcg.com/license (CC0).

## Scope and constraints

- The generated sheets, frame members and door parts are ordinary Blender meshes, organized under a root Empty in a dedicated collection. You can select and inspect them individually.
- Changes to generator settings rebuild tagged components and overwrite manual edits *to those generated components*. Duplicate to an independent mesh before hand-modelling permanent custom parts.
- Supports one hinged door assembly per shed (single or double), placed on one wall. Multi-opening/window tools, floor slabs, engineered bolts/plates, gutters and opening-specific structural analysis are not part of v1.0.
- Hinges are functional transforms for animation, **not** rigid-body physics, actuator simulation or collision-resolved hardware.
- The displayed “components” count includes separate objects, not reusable linked instances. Profile meshes remain relatively light but whole buildings still cost triangles and draw calls.
- No Python source files or textures in this ZIP are copied from third-party CAD repositories. Referenced published guides informed the component names and layout, not any engineering certification.

## Research and verification

- Steel frame construction parts and door headers/girts: https://www.tassiesheds.com.au/wp-content/uploads/2021/11/Portal-Shed-Construction-Guide.pdf
- Typical Australian portal frames: https://www.sydneysheds.com.au/assets/files/downloads/installation-guide_frame-first-sept2011.pdf
- Blender properties: https://docs.blender.org/api/4.5/bpy.props.html
- Blender material displacement: https://docs.blender.org/manual/en/5.0/render/cycles/material_settings.html

**Validation**: Python syntax compilation and simulated layout, shader and object-generation integration tests pass. Blender itself is not installed in the build environment, so real Blender RNA/runtime execution remains untested.

## v1.0.1 — Blender 5.2 material compatibility patch

The original v1.0 shader mistakenly passed scalar roughness/metalness fallback values
into RGBA MixRGB sockets, causing `TypeError: bpy_struct: item.attr = val:` before
any frames were generated. Scalar PBR channels now use `ShaderNodeMix` configured
for float inputs; albedo/dirt continue to use colour mixing. This is based on
Blender 5.2's published ShaderNodeMix API.

The create operator now removes its controller and collection if generation
throws an exception. Previously failed attempts can be removed with the
**Remove Empty Failed Controllers** button in **N → Shed Builder**. It only
removes empty incomplete controllers, leaving completed sheds and unrelated
scene objects untouched.

**Validation level:** syntax, geometry suites, and Blender-like node-socket type
contract tests pass. An actual Blender 5.2 background run is not available in
this build environment.

## v1.0.2 — Blender 5.2 shader socket patch

Fixes the second runtime traceback originating at `materials.py:47` while
calling `_math()` for the rust mask. Blender node outputs are sockets, but
`NodeSocket` does not supply an `is_output` property. The previous `_link()`
checked `hasattr(value, 'is_output')` and incorrectly treated the socket as a
constant, attempting to assign the socket to `default_value` and raising
`TypeError: bpy_struct: item.attr = val:`.

The helper now treats Python numeric and colour tuple/list values as literal
constants and connects all node-socket values with `tree.links.new()`.
Regression tests explicitly use fake Blender 5.2 sockets without an
`is_output` property, with both no-texture and downloaded-PBR shader paths.

ZIP filename now includes the add-on version.

**Validation**: 28 Python tests pass (geometry, presets, shader contracts),
plus syntax compilation. In-editor testing with Blender 5.2 is still pending.

## v1.0.3 — resilient shader paths and full prefab creation checks

- The shared `_link()` helper has been removed. Literal numeric properties and
  Blender output-socket links are now handled by different explicit code paths.
  Scalar roughness, metallic and height blending uses `ShaderNodeMath` nodes;
  colour blending uses `ShaderNodeMixRGB` with actual colour inputs.
- An unavailable/unsupported PBR shader now produces a basic native Principled
  steel material instead of blocking framing, walls, roofing and hinged doors.
  The **Shed Builder** panel shows a warning when the fallback is active.
- The sidebar displays **Build 1.0.3** so you can confirm which code Blender
  actually loaded. Restart Blender after replacing the installed ZIP; replacing
  Python files while Blender is running can leave old modules in memory.
- Automated tests check materials with and without downloaded textures, injected
  shader API exceptions, and full object creation/rebuild/removal for all four
  presets using a simulated bpy data model, including door-angle preservation.

**Validation boundary**: these tests are not a live Blender 5.2 runtime run.
