"""Shed Roller Door - procedural continuous curtain roller door for Blender."""

bl_info = {
    'name': 'Shed Roller Door',
    'author': 'Seth McLaughlin',
    'version': (1, 0, 1),
    'blender': (4, 3, 0),
    'location': 'Shift+A > Mesh > Roller Door | N sidebar > Shed',
    'description': 'Corrugated shed roller doors with real coiling mesh, hardware, animation and ambientCG PBR',
    'category': 'Add Mesh',
    'license': 'MIT',
}

import bpy
from bpy.app.handlers import persistent
from bpy.props import (
    BoolProperty, EnumProperty, FloatProperty, FloatVectorProperty,
    IntProperty, PointerProperty,
)
from bpy.types import Operator, Panel, PropertyGroup

from . import rig, materials


def _root_from_data(prop):
    try:
        ob = prop.id_data
        if rig.is_controller(ob) and ob.roller_door.enabled:
            return ob
    except (AttributeError, ReferenceError):
        pass
    return None


def _geometry_changed(self, context):
    root = _root_from_data(self)
    if root is not None:
        rig.rebuild_complete(root)


def _motion_changed(self, context):
    root = _root_from_data(self)
    if root is not None:
        rig.rebuild_motion(root, force=True)


def _material_changed(self, context):
    root = _root_from_data(self)
    if root is not None:
        rig.update_material_only(root)


class ROLLERDOOR_PG_properties(PropertyGroup):
    enabled: BoolProperty(default=False, options={'HIDDEN'})

    width: FloatProperty(name='Opening Width', description='Clear opening width in metres',
                         default=3.0, min=0.5, max=20.0, unit='LENGTH', update=_geometry_changed)
    height: FloatProperty(name='Opening Height', description='Opening height, from floor to lintel',
                          default=2.7, min=0.5, max=15.0, unit='LENGTH', update=_geometry_changed)
    rib_pitch: FloatProperty(name='Rib Spacing', description='Centre-to-centre pitch of horizontal corrugations',
                             default=0.084, min=0.03, max=0.30, unit='LENGTH', update=_geometry_changed)
    rib_width: FloatProperty(name='Rib Width', description='Width of the raised part of each corrugation',
                             default=0.028, min=0.004, max=0.075, unit='LENGTH', update=_geometry_changed)
    rib_depth: FloatProperty(name='Rib Depth', description='Formed corrugation depth; independent of steel gauge',
                             default=0.015, min=0.002, max=0.04, unit='LENGTH', update=_geometry_changed)
    sheet_thickness: FloatProperty(name='Steel Thickness', description='Actual steel gauge; default 0.5mm',
                                   default=0.0005, min=0.0003, max=0.003, precision=4,
                                   unit='LENGTH', update=_geometry_changed)
    quality: EnumProperty(name='Surface Sampling', items=[
        ('12', 'Preview', '12 stations per rib'),
        ('20', 'Detailed', '20 stations per rib'),
        ('32', 'Hero', '32 stations per rib'),
    ], default='20', update=_geometry_changed)
    core_radius: FloatProperty(name='Drum Core Radius', default=0.095, min=0.05, max=0.30,
                               unit='LENGTH', update=_geometry_changed)
    coil_layer_pitch: FloatProperty(name='Winding Clearance', description='Radial separation between successive curtain wraps',
                                    default=0.021, min=0.005, max=0.08,
                                    unit='LENGTH', update=_geometry_changed)
    seed_turns: FloatProperty(name='Seed Wraps', description='Equivalent curtain length pre-wrapped when fully shut',
                              default=1.4, min=1.0, max=4.0, update=_geometry_changed)
    headroom: FloatProperty(name='Headroom', description='Height of drum centre above the doorway lintel',
                            default=0.38, min=0.15, max=1.2, unit='LENGTH', update=_geometry_changed)
    opening_clearance: FloatProperty(name='Fully Open Rail Drop', description='Bottom rail remains below the lintel when fully raised',
                                     default=0.06, min=0.01, max=0.25, unit='LENGTH', update=_geometry_changed)
    transition_length: FloatProperty(name='Feed Transition', description='Length of curve bending the curtain back into the coil',
                                     default=0.23, min=0.06, max=0.60, unit='LENGTH', update=_geometry_changed)
    include_hood: BoolProperty(name='Steel Drum Hood', default=False, update=_geometry_changed)
    include_motor: BoolProperty(name='Motor Assembly', default=True, update=_geometry_changed)
    include_wind_locks: BoolProperty(name='Edge Wind-Locks', default=False, update=_motion_changed)

    finish: EnumProperty(name='Finish', items=[
        ('PAINT', 'Painted COLORBOND-style', 'Procedural coated steel with adjustable colour (not a branded colour sample)'),
        ('GALVANISED', 'Galvanised Steel', 'Procedural zinc-finish steel'),
        ('Metal026', 'ambientCG Metal026', 'Use this CC0 ambientCG material, if present or downloaded'),
        ('Metal062C', 'ambientCG Metal062C', 'Use this CC0 ambientCG material, if present or downloaded'),
        ('Metal050C', 'ambientCG Metal050C', 'Use this CC0 ambientCG material, if present or downloaded'),
        ('Metal059C', 'ambientCG Metal059C', 'Use this CC0 ambientCG material, if present or downloaded'),
    ], default='PAINT', update=_material_changed)
    paint_color: FloatVectorProperty(name='Paint Colour', subtype='COLOR', size=4,
                                     default=(0.31, 0.38, 0.34, 1), min=0, max=1,
                                     update=_material_changed)
    paint_roughness: FloatProperty(name='Paint Roughness', default=0.41,
                                   min=0.05, max=0.95, update=_material_changed)
    material_override: PointerProperty(name='Existing Material', type=bpy.types.Material,
                                       description='Use a material already imported from the ambientCG Asset Browser',
                                       update=_material_changed)
    texture_scale: FloatProperty(name='PBR UV Tile Size', description='Metres of material per UV tile',
                                 default=1.0, min=0.1, max=5.0, unit='LENGTH', update=_geometry_changed)

    open_percentage: FloatProperty(name='Open', description='Kinematic opening position, 0% shut / 100% open',
                                   default=0.0, min=0.0, max=100.0, subtype='PERCENTAGE',
                                   update=_motion_changed)
    start_frame: IntProperty(name='Start Frame', default=1, min=0, max=100000)
    end_frame: IntProperty(name='End Frame', default=80, min=1, max=100000)
    animation_direction: EnumProperty(name='Direction', items=[
        ('OPEN', 'Open', 'Animate closed to open'),
        ('CLOSE', 'Close', 'Animate open to closed'),
    ], default='OPEN')
    animation_ease: EnumProperty(name='Interpolation', items=[
        ('BEZIER', 'Ease In / Out', 'Smooth animation'),
        ('LINEAR', 'Constant Speed', 'Linear time interpolation'),
    ], default='BEZIER')


class ROLLERDOOR_OT_add(Operator):
    bl_idname = 'mesh.add_shed_roller_door'
    bl_label = 'Roller Door'
    bl_description = 'Create an editable corrugated roller door with physically coiling steel curtain'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.object and context.object.mode != 'OBJECT':
            self.report({'WARNING'}, 'Switch to Object Mode to create a roller door')
            return {'CANCELLED'}
        root = bpy.data.objects.new('Roller Door', None)
        context.collection.objects.link(root)
        root.empty_display_type = 'PLAIN_AXES'
        root.empty_display_size = 0.17
        root.location = context.scene.cursor.location.copy()
        root['rd_controller'] = True
        # Link before enabling property callbacks.
        root.roller_door.enabled = True
        try:
            rig.rebuild_complete(root)
        except Exception as ex:
            bpy.data.objects.remove(root, do_unlink=True)
            self.report({'ERROR'}, f'Failed to build door: {ex}')
            return {'CANCELLED'}
        # Live mesh evaluation also occurs for renders; Blender advises Lock Interface.
        if hasattr(context.scene.render, 'use_lock_interface'):
            context.scene.render.use_lock_interface = True
        for ob in list(context.selected_objects):
            ob.select_set(False)
        root.select_set(True)
        context.view_layer.objects.active = root
        self.report({'INFO'}, 'Roller door created. N > Shed to edit; G/R/S transforms the complete rig.')
        return {'FINISHED'}


class ROLLERDOOR_OT_rebuild(Operator):
    bl_idname = 'rollerdoor.rebuild'
    bl_label = 'Rebuild Roller Door'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        root = rig.get_controller(context.object)
        if root is None:
            return {'CANCELLED'}
        rig.rebuild_complete(root)
        return {'FINISHED'}


class ROLLERDOOR_OT_download_texture(Operator):
    bl_idname = 'rollerdoor.download_texture'
    bl_label = 'Download Selected ambientCG PBR'
    bl_description = 'Download the selected free CC0 ambientCG 1K-JPG maps and pack them into the blend; no additional add-on'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        root = rig.get_controller(context.object)
        if root is None:
            return {'CANCELLED'}
        asset = root.roller_door.finish
        if asset not in materials.AMBIENTCG_ASSETS:
            self.report({'WARNING'}, 'Select an ambientCG finish first')
            return {'CANCELLED'}
        try:
            maps = materials.download_asset(asset)
            mat = materials.ambientcg_material(asset)
            if mat is None:
                raise RuntimeError('Texture maps downloaded but Blender could not create material')
            rig.update_material_only(root)
        except Exception as ex:
            self.report({'ERROR'}, f'ambientCG download failed: {ex}')
            return {'CANCELLED'}
        self.report({'INFO'}, f'{asset} loaded: {", ".join(sorted(maps))}. Images packed into .blend.')
        return {'FINISHED'}


class ROLLERDOOR_OT_insert_keyframe(Operator):
    bl_idname = 'rollerdoor.insert_open_keyframe'
    bl_label = 'Keyframe Current Opening'
    bl_description = 'Keyframe the current opening percent at the current timeline frame'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        root = rig.get_controller(context.object)
        if root is None:
            return {'CANCELLED'}
        root.keyframe_insert(data_path='roller_door.open_percentage', frame=context.scene.frame_current,
                             group='Roller Door')
        return {'FINISHED'}


def _action_curves(action):
    if action is None:
        return []
    curves = []
    legacy = getattr(action, 'fcurves', None)
    if legacy is not None:
        try:
            curves.extend(legacy)
        except TypeError:
            pass
    for layer in getattr(action, 'layers', []):
        for strip in getattr(layer, 'strips', []):
            for bag in getattr(strip, 'channelbags', []):
                curves.extend(getattr(bag, 'fcurves', []))
    return curves


class ROLLERDOOR_OT_create_animation(Operator):
    bl_idname = 'rollerdoor.create_animation'
    bl_label = 'Generate Open/Close Animation'
    bl_description = 'Insert opening keyframes at specified frames and set interpolation'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        root = rig.get_controller(context.object)
        if root is None:
            return {'CANCELLED'}
        p = root.roller_door
        a, b = p.start_frame, p.end_frame
        if a >= b:
            self.report({'ERROR'}, 'End frame must be greater than start frame')
            return {'CANCELLED'}
        closed_first = p.animation_direction == 'OPEN'
        values = ((a, 0.0 if closed_first else 100.0),
                  (b, 100.0 if closed_first else 0.0))
        for frame, position in values:
            p.open_percentage = position
            root.keyframe_insert(data_path='roller_door.open_percentage', frame=frame,
                                 group='Roller Door')
        if root.animation_data:
            for curve in _action_curves(root.animation_data.action):
                if curve.data_path != 'roller_door.open_percentage':
                    continue
                for key in curve.keyframe_points:
                    if a <= key.co.x <= b:
                        key.interpolation = p.animation_ease
                        if p.animation_ease == 'BEZIER':
                            key.handle_left_type = 'AUTO_CLAMPED'
                            key.handle_right_type = 'AUTO_CLAMPED'
        # Blender's documented precaution for live mesh-updating frame handlers.
        if hasattr(context.scene.render, 'use_lock_interface'):
            context.scene.render.use_lock_interface = True
        context.scene.frame_set(a)
        rig.rebuild_motion(root, force=True)
        self.report({'INFO'}, f'Roller door animated over frames {a}-{b}.')
        return {'FINISHED'}


class ROLLERDOOR_OT_delete_animation(Operator):
    bl_idname = 'rollerdoor.delete_animation'
    bl_label = 'Clear Opening Keyframes'
    bl_description = 'Remove only the opening property animation, not transforms or unrelated actions'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        root = rig.get_controller(context.object)
        if root is None:
            return {'CANCELLED'}
        # Clear targeted property curve keys (and preserve unrelated channels).
        if root.animation_data and root.animation_data.action:
            for curve in _action_curves(root.animation_data.action):
                if curve.data_path == 'roller_door.open_percentage':
                    for key in list(curve.keyframe_points):
                        curve.keyframe_points.remove(key)
        root.roller_door.open_percentage = 0
        rig.rebuild_motion(root, force=True)
        return {'FINISHED'}


def _active_controller(context):
    return rig.get_controller(context.object)


class VIEW3D_PT_shed_rollerdoor(Panel):
    bl_label = 'Roller Door'
    bl_idname = 'VIEW3D_PT_shed_rollerdoor'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Shed'

    def draw(self, context):
        layout = self.layout
        root = _active_controller(context)
        if root is None:
            layout.operator('mesh.add_shed_roller_door', text='Add Roller Door', icon='MESH_GRID')
            layout.label(text='Shift+A > Mesh > Roller Door')
            return
        layout.label(text=root.name, icon='MOD_SCREW')
        layout.prop(root.roller_door, 'open_percentage', slider=True)
        row = layout.row(align=True)
        row.operator('rollerdoor.insert_open_keyframe', text='Keyframe', icon='KEY_HLT')
        row.operator('rollerdoor.rebuild', text='Rebuild', icon='FILE_REFRESH')
        layout.label(text='Move / rotate / scale with G R S', icon='ORIENTATION_LOCAL')


class VIEW3D_PT_shed_rollerdoor_shape(Panel):
    bl_label = 'Geometry & Mechanics'
    bl_parent_id = 'VIEW3D_PT_shed_rollerdoor'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _active_controller(context) is not None

    def draw(self, context):
        p = _active_controller(context).roller_door
        layout = self.layout
        layout.prop(p, 'width')
        layout.prop(p, 'height')
        layout.prop(p, 'rib_pitch')
        layout.prop(p, 'rib_width')
        layout.prop(p, 'rib_depth')
        layout.prop(p, 'sheet_thickness')
        layout.prop(p, 'quality')
        sub = layout.column(align=True)
        sub.label(text='Drum & Feed')
        sub.prop(p, 'core_radius')
        sub.prop(p, 'coil_layer_pitch')
        sub.prop(p, 'seed_turns')
        sub.prop(p, 'headroom')
        sub.prop(p, 'transition_length')
        sub.prop(p, 'opening_clearance')
        layout.prop(p, 'include_hood')
        layout.prop(p, 'include_motor')
        layout.prop(p, 'include_wind_locks')
        if p.coil_layer_pitch < p.rib_depth + p.sheet_thickness + 0.002:
            layout.label(text='Layer pitch raised to prevent overlap', icon='INFO')


class VIEW3D_PT_shed_rollerdoor_material(Panel):
    bl_label = 'Steel & ambientCG PBR'
    bl_parent_id = 'VIEW3D_PT_shed_rollerdoor'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'

    @classmethod
    def poll(cls, context):
        return _active_controller(context) is not None

    def draw(self, context):
        p = _active_controller(context).roller_door
        layout = self.layout
        layout.prop(p, 'finish')
        if p.finish == 'PAINT':
            layout.prop(p, 'paint_color')
            layout.prop(p, 'paint_roughness')
        if p.finish in materials.AMBIENTCG_ASSETS:
            if materials.find_existing_material(p.finish):
                layout.label(text='Using existing Blender material', icon='CHECKMARK')
            elif materials.get_texture_maps(p.finish):
                layout.label(text='ambientCG PBR cached', icon='CHECKMARK')
            else:
                layout.label(text='PBR maps not yet downloaded', icon='INFO')
            layout.operator('rollerdoor.download_texture', text='Get ambientCG CC0 Textures', icon='IMPORT')
        layout.prop(p, 'material_override')
        layout.prop(p, 'texture_scale')
        layout.label(text='Material textures packed in .blend')


class VIEW3D_PT_shed_rollerdoor_animation(Panel):
    bl_label = 'Door Animation'
    bl_parent_id = 'VIEW3D_PT_shed_rollerdoor'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'

    @classmethod
    def poll(cls, context):
        return _active_controller(context) is not None

    def draw(self, context):
        p = _active_controller(context).roller_door
        layout = self.layout
        layout.prop(p, 'open_percentage', slider=True)
        row = layout.row(align=True)
        row.prop(p, 'start_frame')
        row.prop(p, 'end_frame')
        layout.prop(p, 'animation_direction', expand=True)
        layout.prop(p, 'animation_ease')
        layout.operator('rollerdoor.create_animation', icon='ACTION')
        layout.operator('rollerdoor.insert_open_keyframe', icon='KEY_HLT')
        layout.operator('rollerdoor.delete_animation', icon='X')
        layout.label(text='Scrub timeline to wind / unwind curtain')


def _menu_mesh_add(self, context):
    self.layout.separator()
    self.layout.operator('mesh.add_shed_roller_door', text='Roller Door', icon='MESH_GRID')


@persistent
def _on_frame_change(scene, depsgraph=None):
    for ob in scene.objects:
        if rig.is_controller(ob):
            rig.rebuild_motion(ob)


@persistent
def _on_load(_):
    rig.forget_runtime_cache()


_CLASSES = (
    ROLLERDOOR_PG_properties,
    ROLLERDOOR_OT_add,
    ROLLERDOOR_OT_rebuild,
    ROLLERDOOR_OT_download_texture,
    ROLLERDOOR_OT_insert_keyframe,
    ROLLERDOOR_OT_create_animation,
    ROLLERDOOR_OT_delete_animation,
    VIEW3D_PT_shed_rollerdoor,
    VIEW3D_PT_shed_rollerdoor_shape,
    VIEW3D_PT_shed_rollerdoor_material,
    VIEW3D_PT_shed_rollerdoor_animation,
)


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Object.roller_door = PointerProperty(type=ROLLERDOOR_PG_properties)
    bpy.types.VIEW3D_MT_mesh_add.append(_menu_mesh_add)
    if _on_frame_change not in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.append(_on_frame_change)
    if _on_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load)


def unregister():
    if _on_frame_change in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.remove(_on_frame_change)
    if _on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load)
    bpy.types.VIEW3D_MT_mesh_add.remove(_menu_mesh_add)
    del bpy.types.Object.roller_door
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
    rig.forget_runtime_cache()
