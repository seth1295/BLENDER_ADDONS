"""Blender interface for the v0.4.3 independent terrain chunk system.

Earlier v0.3 terrain and river operators are intentionally retained unedited.
"""
import bpy
from bpy.types import Operator, Panel, PropertyGroup
from bpy.props import IntProperty, PointerProperty
from . import chunk_core as cc
from . import terrain as legacy

TERRAIN_COLLECTION = 'TB_Chunked_Terrain'
WATER_COLLECTION = 'TB_Chunked_Water'
ROOT_COLLECTION = 'TB_Chunked_World'
PREFIX_LAND = 'TB_Land_'
PREFIX_WATER = 'TB_Water_'


def _collection(name, parent):
    result = bpy.data.collections.get(name)
    if result is None:
        result = bpy.data.collections.new(name)
    if parent.children.get(name) is None:
        parent.children.link(result)
    return result


def _ensure_collections(scene):
    root = _collection(ROOT_COLLECTION, scene.collection)
    return _collection(TERRAIN_COLLECTION, root), _collection(WATER_COLLECTION, root)


def _material_for(is_water):
    # Debug-only colours. Production PBR textures come from ambientCG.
    if is_water:
        return legacy._material('TB_Water_Debug', (0.08, 0.29, 0.47, 1.0), 0.18)
    return legacy._material('TB_Terrain_Debug', (0.42, 0.49, 0.31, 1.0), 0.9)


def _owned_objects():
    for obj in bpy.data.objects:
        if obj.get('tb_generated') == 'town_builder_chunk' and obj.type == 'MESH':
            yield obj


def _mesh_update(data, tile, is_water, collection):
    prefix = PREFIX_WATER if is_water else PREFIX_LAND
    name = prefix + tile.key
    obj = bpy.data.objects.get(name)
    if obj is not None and obj.get('tb_generated') != 'town_builder_chunk':
        raise ValueError(f'Object named {name} exists and is not a Town Builder chunk')
    is_new = obj is None
    if is_new:
        obj = bpy.data.objects.new(name, bpy.data.meshes.new(name+'_Mesh'))
        collection.objects.link(obj)
    elif collection.objects.get(name) is None:
        collection.objects.link(obj)
    mesh = bpy.data.meshes.new(name+'_Mesh')
    x0,y0,_,_ = tile.bounds
    world_verts = data.water_vertices if is_water else data.vertices
    faces = data.water_faces if is_water else data.faces
    mesh.from_pydata([(x-x0,y-y0,z) for x,y,z in world_verts], [], faces)
    mesh.update()
    mesh.materials.append(_material_for(is_water))
    if len(mesh.polygons):
        mesh.polygons.foreach_set('use_smooth', [True]*len(mesh.polygons))
    old = obj.data
    obj.data = mesh
    if old and old.users == 0:
        bpy.data.meshes.remove(old)
    obj.location = (x0,y0,0.0)
    obj['tb_generated'] = 'town_builder_chunk'
    obj['tb_type'] = 'water' if is_water else 'terrain'
    obj['tb_generator'] = 'chunked_terrain'
    obj['tb_generator_version'] = '0.4.3'
    obj['tb_chunk_id'] = tile.key
    obj['tb_depth'] = tile.depth
    obj['tb_ix'] = tile.ix
    obj['tb_iy'] = tile.iy
    obj['tb_lod'] = tile.lod
    obj['tb_root_ix'] = tile.root_xy[0]
    obj['tb_root_iy'] = tile.root_xy[1]
    obj['tb_chunk_size_m'] = tile.size
    obj['tb_world_origin_x_m'] = x0
    obj['tb_world_origin_y_m'] = y0
    obj['tb_height_source'] = 'Town Builder terrain_math v0.3.0'
    return obj


def _hide_legacy():
    for name in ('TB_BasicTerrain','TB_RiverWater'):
        obj=bpy.data.objects.get(name)
        if obj is not None and 'tb_chunk_previous_hidden' not in obj:
            obj['tb_chunk_previous_hidden']=bool(obj.hide_get())
            obj['tb_chunk_previous_render_hidden']=bool(obj.hide_render)
            obj.hide_set(True)
            obj.hide_render=True


def _restore_legacy():
    for name in ('TB_BasicTerrain','TB_RiverWater'):
        obj=bpy.data.objects.get(name)
        if obj is not None and 'tb_chunk_previous_hidden' in obj:
            obj.hide_set(bool(obj['tb_chunk_previous_hidden']))
            obj.hide_render=bool(obj.get('tb_chunk_previous_render_hidden',False))
            del obj['tb_chunk_previous_hidden']
            if 'tb_chunk_previous_render_hidden' in obj:
                del obj['tb_chunk_previous_render_hidden']


def _validate_scene(scene):
    s=scene.tb_terrain_settings
    if abs(s.width - cc.WORLD_SIZE_M)>0.01 or abs(s.length - cc.WORLD_SIZE_M)>0.01:
        raise ValueError('Chunk mode requires 4,000 x 4,000 m map: apply 4 km preset')
    if not s.world_space:
        raise ValueError('Chunk mode requires Stable World-Space Terrain')
    err=cc.tm.validate_corridor(s)
    if err:
        raise ValueError(err)


def _build_tiles(scene, leaves, tiles):
    _validate_scene(scene)
    land_collection,water_collection = _ensure_collections(scene)
    expected={t.key for t in tiles}
    affected_roots={t.root_xy for t in tiles}
    # Bound peak memory for one operation; extreme LODs are built regionally.
    estimate=sum((t.segments+1)**2 for t in tiles)
    if estimate > 2_500_000:
        raise ValueError(f'{estimate:,} estimated vertices exceeds the 2.5M-vertex per-operation safety limit; reduce LOD/depth or work in a smaller region')
    # Build the requested set first. Unaffected objects are never deleted.
    count_terrain=count_water=0
    for tile in tiles:
        data=cc.generate_tile(tile,leaves,scene.tb_terrain_settings)
        _mesh_update(data,tile,False,land_collection)
        count_terrain+=1
        if data.water_faces:
            _mesh_update(data,tile,True,water_collection)
            count_water+=1
        else:
            stale=bpy.data.objects.get(PREFIX_WATER+tile.key)
            if stale is not None and stale.get('tb_generated')=='town_builder_chunk':
                bpy.data.objects.remove(stale,do_unlink=True)
        del data
    # Prune superseded parent/children within requested roots only.
    for obj in list(_owned_objects()):
        root=(int(obj.get('tb_root_ix',-1)),int(obj.get('tb_root_iy',-1)))
        if root in affected_roots and obj.get('tb_chunk_id') not in expected:
            bpy.data.objects.remove(obj,do_unlink=True)
    _hide_legacy()
    scene['tb_chunk_generation_version']='0.4.3'
    scene['tb_chunk_map_size_m']=4000.0
    return count_terrain,count_water


class TB_ChunkSettings(PropertyGroup):
    center_x: IntProperty(name='Centre X (0-15)',default=8,min=0,max=15)
    center_y: IntProperty(name='Centre Y (0-15)',default=8,min=0,max=15)
    radius: IntProperty(name='Region Radius',default=1,min=0,max=3,
                        description='1 generates a 3 x 3 tile test area')
    far_lod: IntProperty(name='Outer LOD',default=0,min=0,max=2)
    near_lod: IntProperty(name='Adjacent LOD',default=1,min=0,max=3)
    focus_lod: IntProperty(name='Focus LOD',default=2,min=0,max=4)
    focus_depth: IntProperty(name='Focus Quadtree Depth',default=0,min=0,max=2,
                            description='0: one 250 m chunk, 1: four 125 m chunks, 2: sixteen 62.5 m chunks')


class TB_OT_generate_chunk_region(Operator):
    bl_idname='tb.generate_chunk_region'
    bl_label='Generate Chunk Region'
    bl_description='Generate only the selected region; reuses object identities and preserves other chunks'
    bl_options={'REGISTER','UNDO'}

    def execute(self,context):
        sc=context.scene
        cs=sc.tb_chunk_settings
        try:
            _validate_scene(sc)
            leaves,targets=cc.build_plan(cs.center_x,cs.center_y,cs.radius,
                                         cs.far_lod,cs.near_lod,cs.focus_lod,
                                         cs.focus_depth)
            # Existing neighbouring chunk LODs must not be overwritten. The
            # canonical seam heights are independent of any plan changes.
            counts=_build_tiles(sc,leaves,targets)
        except (ValueError,MemoryError) as exc:
            self.report({'ERROR'},str(exc))
            return {'CANCELLED'}
        self.report({'INFO'},f'Generated {counts[0]} terrain chunks and {counts[1]} water chunks')
        return {'FINISHED'}


class TB_OT_generate_full_base(Operator):
    bl_idname='tb.generate_full_base'
    bl_label='Generate Full Map at LOD 0'
    bl_description='Generate all 256 base chunks; replaces existing high-LOD chunks (use region control to refine again)'
    bl_options={'REGISTER','UNDO'}

    def execute(self,context):
        try:
            _validate_scene(context.scene)
            plan=cc.whole_map_plan(lod=0)
            counts=_build_tiles(context.scene,plan,plan)
        except (ValueError,MemoryError) as exc:
            self.report({'ERROR'},str(exc))
            return {'CANCELLED'}
        self.report({'INFO'},f'Full 4 x 4 km map: {counts[0]} terrain chunks, {counts[1]} water chunks')
        return {'FINISHED'}


class TB_OT_regenerate_selected_chunk(Operator):
    bl_idname='tb.regenerate_selected_chunk'
    bl_label='Regenerate Selected Chunk'
    bl_description='Update only the selected terrain or water tile using its stored depth, indices and LOD'
    bl_options={'REGISTER','UNDO'}

    @classmethod
    def poll(cls,context):
        o=context.active_object
        return bool(o and o.get('tb_generated')=='town_builder_chunk')

    def execute(self,context):
        obj=context.active_object
        t=cc.Tile(int(obj['tb_depth']),int(obj['tb_ix']),int(obj['tb_iy']),int(obj['tb_lod']))
        try:
            _validate_scene(context.scene)
            _build_tiles(context.scene,[t],[t])
        except (ValueError,MemoryError) as exc:
            self.report({'ERROR'},str(exc))
            return {'CANCELLED'}
        self.report({'INFO'},'Regenerated '+t.key+'; other chunks untouched')
        return {'FINISHED'}


class TB_OT_clear_chunks(Operator):
    bl_idname='tb.clear_chunks'
    bl_label='Clear Generated Chunks'
    bl_description='Remove only Town Builder chunk objects; retain the v0.3 terrain and restore its visibility'
    bl_options={'REGISTER','UNDO'}

    def execute(self,context):
        count=0
        for obj in list(_owned_objects()):
            bpy.data.objects.remove(obj,do_unlink=True)
            count+=1
        _restore_legacy()
        self.report({'INFO'},f'Cleared {count} generated chunk objects')
        return {'FINISHED'}


class TB_PT_chunk_panel(Panel):
    bl_label='Chunked Terrain (v0.4)'
    bl_idname='TB_PT_chunk_panel'
    bl_space_type='VIEW_3D'
    bl_region_type='UI'
    bl_category='Town Builder'

    def draw(self,context):
        layout=self.layout
        cs=context.scene.tb_chunk_settings
        layout.label(text='4 km x 4 km | 16 x 16 | 250 m tiles')
        layout.label(text='LOD 0 = 3.906 m; LOD 4 = 0.244 m')
        box=layout.box()
        box.label(text='3x3 Mixed LOD / Local Refinement')
        row=box.row(align=True)
        row.prop(cs,'center_x')
        row.prop(cs,'center_y')
        box.prop(cs,'radius')
        box.prop(cs,'far_lod')
        box.prop(cs,'near_lod')
        box.prop(cs,'focus_lod')
        box.prop(cs,'focus_depth')
        box.operator('tb.generate_chunk_region',text='Generate / Update Region',icon='MESH_GRID')
        layout.separator()
        layout.operator('tb.generate_full_base',text='Generate Entire Map (LOD 0)',icon='WORLD')
        layout.operator('tb.regenerate_selected_chunk',text='Regenerate Selected Chunk',icon='FILE_REFRESH')
        layout.operator('tb.clear_chunks',text='Clear Chunked Terrain',icon='TRASH')
        layout.label(text='River water is an independent mesh.')
        layout.label(text='Legacy v0.3 generator remains available.')


def chunk_add_menu(self,context):
    self.layout.operator('tb.generate_chunk_region',text='Chunked Town Terrain Region',icon='MESH_GRID')


classes=(TB_ChunkSettings,TB_OT_generate_chunk_region,TB_OT_generate_full_base,
         TB_OT_regenerate_selected_chunk,TB_OT_clear_chunks,TB_PT_chunk_panel)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.tb_chunk_settings=PointerProperty(type=TB_ChunkSettings)
    bpy.types.VIEW3D_MT_mesh_add.append(chunk_add_menu)


def unregister():
    bpy.types.VIEW3D_MT_mesh_add.remove(chunk_add_menu)
    if hasattr(bpy.types.Scene,'tb_chunk_settings'):
        del bpy.types.Scene.tb_chunk_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
