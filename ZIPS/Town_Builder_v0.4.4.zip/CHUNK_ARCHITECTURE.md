# Chunk-system engineering notes (v0.4.3)

**Authoritative source:** The `terrain_math.py` functions are used for all elevation, riverbank and water-height calculations. World-space terrain is deterministic and independent of chunk identity.

**Chunk addresses:** `Tile(depth, ix, iy, lod)`. Depth 0 addresses the 250 m grid `(0..15, 0..15)`. Depth 1 splits one root into four 125 m child tiles. Depth 2 splits one root into 16 child tiles of 62.5 m. Child coordinates use a world-anchored dyadic lattice.

**LOD:** 64 × 2^LOD cells per tile edge (LOD 0..4). Root chunks at LOD 4 have >1 million sample vertices and should be used sparingly. All chunks are physically sized in metres.

**River geometry:** Within each X grid strip, riverbank coordinates are evaluated at both strip endpoints and treated as a piecewise linear analytic boundary. Each regular grid cell is clipped into below-bank / in-channel / above-bank convex polygons, which share exact geometric points. The separate water surface is constructed from the in-channel polygons with the same 2D coordinates and a continuous water-height function. At a shoreline vertex, terrain Z is forced to water Z; there is no elevation-threshold water mask.

**LOD seam constraints:** The baseline world lattice is 250 / 64 = 3.90625 m. All tile-edge vertices are projected to the same canonical boundary polyline, which additionally contains analytic crossings where shorelines, internal riverbed sections, and bank faces intersect the edge. This prevents T-junction cracks even when two adjacent chunks are generated in separate sessions at different LOD. Terrain interiors still use the requested resolution. The canonical profile is intentionally frozen at base LOD: neighbour edits cannot silently move previously generated seams.

**Persistent Blender identity:** Terrain names use `TB_Land_d{depth}_x{ix}_y{iy}` and water names use `TB_Water_d{depth}_x{ix}_y{iy}`. Existing Blender objects are reused when their tile is regenerated; only their Mesh datablocks are replaced. Tile indices, LOD, dimensions and generator version are stored as custom properties. Replacing a root tile by quadtree children removes only the superseded meshes in that root.

**Known future work:** view-dependent LOD selection; actual runtime streaming; cached height tiles; terrain-specific sub-metre detail (erosion, drainage, road cut/fill); large-world mesh benchmarks in Blender; full ambientCG PBR materials and textures; multiresolution normal treatment; camera-driven chunk disposal and reload.

**v0.4.3 cross-section sampling:** A semi-elliptical bed is sampled at 33 signed profile stations; additional lateral bank stations preserve the 7m crest rise over a 2m horizontal run. These profile contours are cut into polygons in each X strip independent of LOD. Both Blender and Three.js implement the same geometric clipping and match analytically at sampled terrain points.
