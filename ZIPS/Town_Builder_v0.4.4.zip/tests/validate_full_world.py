"""Optional full-world geometry sweep; ~256 base chunks and ~1.1M vertices.
Run as `python tests/validate_full_world.py` outside Blender (stdlib only).
"""
import importlib.util
from pathlib import Path
import sys
p=Path(__file__).with_name('validate_chunks.py')
spec=importlib.util.spec_from_file_location('_tb_validation',p)
module=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=module
spec.loader.exec_module(module)
cc=module.cc
s=module.config()
verts=faces=water_verts=water_faces=water_chunks=0
for tile in cc.whole_map_plan(0):
    mesh=cc.generate_tile(tile,[],s)
    verts+=len(mesh.vertices)
    faces+=len(mesh.faces)
    water_verts+=len(mesh.water_vertices)
    water_faces+=len(mesh.water_faces)
    water_chunks+=bool(mesh.water_faces)
print(f'PASS: 256/256 root chunks, {verts:,} terrain verts, {faces:,} terrain faces, '
      f'{water_verts:,} water verts, {water_faces:,} water faces across {water_chunks} water chunks')
